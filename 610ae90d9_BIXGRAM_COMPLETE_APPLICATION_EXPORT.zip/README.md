# BIXGRAM — Frontend Source & Migration Guide

**Connect. Share. Live.**

BIXGRAM is a dark-navy social platform built with React + Vite + Tailwind CSS. This README documents how to run the frontend locally, how to build it, what it currently depends on inside Base44, and exactly what must be replaced to run it against an independently owned backend.

---

## 1. Current product structure

Primary navigation (bottom bar, 5 tabs):

| Tab | Route | Purpose |
|---|---|---|
| Home | `/` | Text and photo posts, reactions, comments, shares, saves, follow feed |
| Community | `/communities` | Community discovery, categories, join/leave, community posts |
| Live | `/live` | Live discovery, viewing, comments, reactions, gifts, scheduling |
| Messenger | `/messenger` | Private conversations |
| More | `/menu` | Trending, Suggested, Popular Words, Marketplace, Premium, Settings, Creator Studio |

Additional routes: `/communities/:id`, `/live/studio`, `/trending`, `/profile`, `/profile/:username`,
`/post/:id`, `/channels`, `/channels/:id`, `/search`, `/notifications`, `/marketplace`, `/premium`,
`/settings`, `/creator-score`, `/choose-feed`, `/bix-ai`, `/admin`, plus the four auth routes.

**Removed in this revision:** the former `World` and `Pulse` sections, including their routes, pages,
components and menu entries. The underlying `World` / `WorldMembership` entity data was **not deleted** —
it now backs Community, so no genuine community data was lost. The `NewsStory` entity remains in
`base44/entities/` with its data intact but is no longer referenced by any UI.

---

## 2. Install

```bash
npm install
```

Requires Node 18+ (Vite 8).

---

## 3. Run locally

```bash
npm run dev          # frontend only — no backend behind it
npm run dev -- --host # to test on a phone on the same network
```

> Running the frontend alone means every `base44.*` data call fails. To run the frontend against the
> hosted Base44 backend, use the Base44 CLI (`base44 dev --remote`) — see section 4.

### Build

```bash
npm run build
npm run preview
```

Output is written to `dist/`.

### Lint / typecheck

```bash
npm run lint
npm run typecheck
```

---

## 4. Environment variables

There is **no `.env` file checked in, and no secret is stored in frontend code.** Configuration is read by
`src/api/base44Client.js` through the Base44 SDK and the Base44 Vite plugin.

| Variable | Purpose | Status |
|---|---|---|
| `VITE_BASE44_APP_ID` | Identifies the backend app to the SDK | Currently supplied by the Base44 runtime / Vite plugin |
| `VITE_BASE44_BACKEND_URL` | Base URL of the API the SDK calls | Currently supplied by the Base44 runtime / Vite plugin |

Verify the exact names against `src/api/base44Client.js` and `vite.config.js` before deploying — the
platform injects these today, so they are not declared in this repository. **Never commit real secrets.**
Any future backend must expose a public base URL only; service keys belong on the server.

---

## 5. Base44 dependencies that must be replaced

Everything below is Base44-managed. None of it is portable as-is.

| Dependency | Where it is used | Replacement needed |
|---|---|---|
| `base44.entities.<Name>` CRUD (`list`, `filter`, `get`, `create`, `update`, `updateMany`, `delete`, `bulkCreate`, `subscribe`) | Every page and most components | A typed REST or GraphQL client with the same method surface. **This is the single biggest migration surface.** |
| `base44.auth.*` (`me`, `isAuthenticated`, `logout`, `loginWithMfa`, OAuth helpers, `register`, `verifyOtp`, `resetPassword*`) | `src/lib/AuthContext.jsx`, `src/lib/authMfa.js`, the four auth pages, `ProtectedRoute` | Your own identity provider (Auth0/Clerk/Cognito) or a JWT backend |
| `base44.integrations.Core.UploadPublicFile` / `UploadPrivateFile` / `CreateFileSignedUrl` | `src/lib/social.js`, `src/lib/live.js`, `PostComposer`, `Community*` | Object storage (S3/R2) with presigned uploads and signed reads |
| `base44.integrations.Core.InvokeLLM` | `src/pages/BixAI.jsx` | Your own LLM proxy |
| `base44.integrations.Core.SendEmail` | notification helpers | Transactional email provider |
| `base44.users.inviteUser` | admin flows | Your invite endpoint |
| Row-Level Security (`rls` in `base44/entities/*.jsonc`) | Data authorization | **Server-side authorization.** RLS is enforced by Base44; your backend must re-implement every rule as real checks. Do not rely on the client. |
| Realtime `entity.subscribe(...)` | Messenger, Live comments/reactions/viewers | WebSocket or SSE channel service |
| Base44 CLI / hosting | `base44 dev`, publish | Your own CI + static hosting |

`src/api/base44Client.js` is the one import point for the SDK. It is the natural place to swap in a
different client, but be aware that pages currently call `base44.entities.*` directly rather than through
a repository/service layer.

### Frontend / data-access separation — honest status

The UI is organized into pages and focused components, but **data access is not yet fully abstracted**:
many pages call `base44.entities.*` inline. A complete separation would introduce
`src/services/<domain>.js` modules (posts, comments, communities, live, messenger, profiles) and repoint
every page at them. That refactor has **not** been done; it is the recommended first task in the new repo,
because it is what allows the backend to be swapped without touching UI code.

---

## 6. Backend API surface you will need

Minimum endpoints implied by the current screens:

**Auth** — `POST /auth/register`, `POST /auth/verify-otp`, `POST /auth/login`, `POST /auth/refresh`,
`POST /auth/logout`, `GET /users/me`, `POST /auth/forgot-password`, `POST /auth/reset-password`,
OAuth callback routes.

**Posts** — list (cursor paginated, sortable), create, get, update, delete, react, comment, share, save.

**Comments** — list by target, create, update, delete, react.

**Profiles & social graph** — get by username, update, follow, unfollow, friends, block, report.

**Communities** — list/search by category, get, create, join, leave, member count, community posts,
moderation (remove post/member).

**Live** — list active, get, create/schedule, start, end, viewer presence, comments, reactions, gifts,
creator stats and earnings, guest invites.

**Messenger** — conversations, messages, read receipts, attachments (signed URLs).

**Notifications** — list, mark read, unread count.

**Marketplace, Premium, Promotions, Creator Score, Admin** — see the entity schemas.

---

## 7. Database entities (from `base44/entities/*.jsonc`)

Every entity below is defined in this repository as a JSON schema. Relationships are by string ID
(`author_name` / `created_by_id`, `post_id`, `conversation_id`, `world_id`, `stream_id`, …).

**Core content:** `Post`, `Comment`, `Reaction`, `Share`, `SavedItem`, `Draft`, `Story`, `TrendingTopic`
**People:** `Profile`, `Follow`, `Friendship`, `BlockedUser`, `UserVerification`, `CreatorScore`
**Community:** `World`, `WorldMembership`, `Channel`, `ChannelPost`, `ChannelSubscriber`,
`ChannelApplication`, `ChannelMonetization`, `ChannelAudit`
**Live:** `LiveStream`, `LiveComment`, `LiveReaction`, `LiveViewer`, `LiveGift`, `LiveGuest`
**Messaging:** `Conversation`, `Message`
**Commerce & trust:** `MarketplaceListing`, `Promotion`, `PremiumSubscription`, `Report`, `ModerationFlag`
**Platform:** `Notification`, `AIUsage`, `Call`
**Unused but retained:** `Reel` (legacy), `NewsStory` (Pulse, removed from the UI)

> Note on naming: `World` / `WorldMembership` are the storage tables behind the **Community** feature.
> Renaming them is optional; the UI no longer uses the word "World".

---

## 8. Authentication & storage — what is incomplete

- **Auth is Base44-managed.** The four auth pages (`Login`, `Register`, `ForgotPassword`, `ResetPassword`)
  and `src/lib/authMfa.js` call Base44 SDK methods. They will not work against a new backend until
  those calls are replaced. No fake auth has been added.
- **Storage is Base44-managed.** Public uploads return a permanent public URL; private uploads return a
  private URI rendered through short-lived signed URLs (`src/hooks/use-signed-url.js`). Both need replacing.
- **No end-to-end encryption is implemented.** Messenger stores message text via the standard entity API.
  There is a key field on `Profile` and a `src/lib/e2ee.js` helper, but **E2EE is not production-ready** and
  no claim should be made that messages are end-to-end encrypted.
- **No payment processing is connected.** Premium and coin top-ups show plan UI only; no charge is taken.
- **No live video broadcasting.** There is no camera capture, ingest, transcoding or streaming transport.
  `LiveStream.video_url` plays a URL if one exists. Scheduling, discovery, comments, reactions, gifts and
  creator stats are data-driven features only.

---

## 9. Known limitations

1. `src/services/` does not exist yet — see section 5.
2. Entity authorization currently lives in Base44 RLS rules. **Reproduce it server-side**; do not ship the
   JSON rules as your only protection.
3. Pagination is cursor-based on Home only; several lists load a fixed page (50–100 rows).
4. Realtime depends on `entity.subscribe`; there is no fallback polling strategy.
5. `AdminStudio` routes are gated by role on the client and by RLS on the server. A new backend must
   enforce admin role server-side.
6. The `Reel` and `NewsStory` entities are retained for data preservation but are unused by the UI.
7. No automated tests are included.
8. `npm run typecheck` runs `tsc` over a JS project with `checkJs` off — it catches little.

---

## 10. Exporting the source

Use the Base44 editor: **three-dots menu (top bar) → More actions → “Export project as ZIP”.**

That produces the full project, preserving this structure:

```
index.html · package.json · vite.config.js · tailwind.config.js · postcss.config.js
jsconfig.json · components.json · eslint.config.js · README.md
src/            pages, components, lib, hooks, api, index.css, App.jsx, main.jsx
base44/         entities/*.jsonc, config.jsonc
public/         static assets
```

**Not included in a source archive:** the hosted database contents, uploaded media, app users,
Base44-managed auth sessions, server-side integration credentials, and Base44's backend runtime. Those
must be exported separately (data export) or rebuilt.

---

## 11. Suggested next steps in the new repository

1. Create `src/services/*` and move every `base44.entities.*` call behind it.
2. Define an OpenAPI spec from section 6 and generate a typed client.
3. Re-implement the RLS rules as server-side authorization tests.
4. Replace auth with your provider; keep the existing page layouts.
5. Replace file storage with presigned S3/R2 uploads.
6. Build the Live streaming transport (WebRTC or RTMP ingest) if broadcasting is required.