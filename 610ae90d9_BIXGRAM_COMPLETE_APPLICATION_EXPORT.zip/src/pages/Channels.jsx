import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Plus, Users, ArrowLeft } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getMe } from "@/lib/social";
import { getMySubscriptionIds, toggleChannelSubscription, getMyChannelAllowance } from "@/lib/channels";
import ChannelCard from "@/components/channels/ChannelCard";
import CreateChannelSheet from "@/components/channels/CreateChannelSheet";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export default function Channels() {
  const [channels, setChannels] = useState([]);
  const [subs, setSubs] = useState([]);
  const [verifiedNames, setVerifiedNames] = useState(new Set());
  const [me, setMe] = useState(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [allowance, setAllowance] = useState(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  const load = async () => {
    try {
      const [all, mySubs, verifications, m] = await Promise.all([
        base44.entities.Channel.list("-created_date", 60).catch(() => []),
        getMySubscriptionIds().catch(() => []),
        base44.entities.UserVerification.list(500).catch(() => []),
        getMe(),
      ]);
      setChannels(all);
      setSubs(mySubs);
      // A channel's badge reflects its OWNER's verification, never the channel name.
      setVerifiedNames(new Set(verifications.filter(v => v.is_verified).map(v => v.user_name)));
      setMe(m);
      setAllowance(await getMyChannelAllowance().catch(() => null));
    } catch {}
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const toggle = async (channel) => {
    try {
      const now = await toggleChannelSubscription(channel);
      setSubs(s => (now ? [...s, String(channel.id)] : s.filter(id => id !== String(channel.id))));
      setChannels(cs => cs.map(c => (c.id === channel.id
        ? { ...c, subscribers_count: Math.max(0, (c.subscribers_count || 0) + (now ? 1 : -1)) }
        : c)));
    } catch {
      toast({ title: "Could not update subscription", variant: "destructive" });
    }
  };

  const q = query.trim().toLowerCase();
  const matches = (c) =>
    (category === "All" || c.category === category) &&
    (!q || String(c.name || "").toLowerCase().includes(q) || String(c.username || "").toLowerCase().includes(q));

  // Category chips come from the categories real channels actually use.
  const categories = ["All", ...new Set(channels.map(c => c.category).filter(Boolean))];

  const mine = channels.filter(c => me && c.owner_id === me.id);
  const followed = channels.filter(c => subs.includes(String(c.id)) && !(me && c.owner_id === me.id));
  const discover = channels.filter(c => !subs.includes(String(c.id)) && !(me && c.owner_id === me.id));

  const atLimit = allowance && allowance.remaining <= 0;

  return (
    <div className="max-w-2xl mx-auto min-h-screen">
      <header className="sticky top-0 z-40 bg-background/85 backdrop-blur-xl border-b border-border px-4 py-3">
        <div className="flex items-center gap-2 mb-3">
          <button onClick={() => navigate(-1)} aria-label="Back" className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-secondary/60 shrink-0">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-extrabold bix-gradient-text flex-1 min-w-0 truncate">Channel</h1>
          <button
            onClick={() => (atLimit
              ? toast({
                  title: "You've reached your Channel limit.",
                  description: "Free accounts can create up to 2 Channels. Upgrade to Premium for unlimited Channels.",
                })
              : setCreating(true))}
            aria-label="Create channel"
            className="w-9 h-9 rounded-full bix-gradient flex items-center justify-center bix-glow shrink-0 bix-press"
          >
            <Plus className="w-5 h-5 text-white" />
          </button>
        </div>
        <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2.5">
          <Search className="w-[18px] h-[18px] text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search channels"
            className="flex-1 min-w-0 bg-transparent outline-none text-sm"
          />
        </div>
        {categories.length > 2 && (
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar mt-2.5">
            {categories.map(c => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-medium shrink-0 border transition",
                  category === c ? "bix-gradient text-white border-transparent" : "border-border text-muted-foreground"
                )}
              >
                {c}
              </button>
            ))}
          </div>
        )}
      </header>

      <div className="p-3 pb-[calc(5rem+env(safe-area-inset-bottom))]">
        {loading ? (
          <div className="space-y-2">
            {[0, 1, 2, 3].map(i => <div key={i} className="h-[76px] rounded-2xl bix-skeleton" />)}
          </div>
        ) : channels.length === 0 ? (
          <div className="text-center py-16 px-6">
            <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
              <Users className="w-6 h-6 text-muted-foreground" />
            </div>
            <p className="font-semibold text-sm">No channels yet</p>
            <p className="text-xs text-muted-foreground mt-1">Be the first to start one.</p>
            <button onClick={() => setCreating(true)} className="mt-4 px-5 py-2.5 rounded-full bix-gradient text-white text-sm font-semibold bix-press">
              Create channel
            </button>
          </div>
        ) : (
          <>
            {allowance && (
              <p className="text-[11px] text-muted-foreground px-1 mb-2">
                {allowance.limit === Infinity
                  ? `${allowance.used} channel${allowance.used === 1 ? "" : "s"} · unlimited on your plan`
                  : `${allowance.used} of ${allowance.limit} channels used`}
              </p>
            )}

            {mine.filter(matches).length > 0 && (
              <>
                <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground mt-2 mb-2 px-1">My channels</h2>
                <div className="space-y-2">
                  {mine.filter(matches).map(c => (
                    <ChannelCard key={c.id} channel={c} verified={verifiedNames.has(c.name)} onOpen={() => navigate(`/channels/${c.id}`)} />
                  ))}
                </div>
              </>
            )}

            {followed.filter(matches).length > 0 && (
              <>
                <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground mt-5 mb-2 px-1">Following</h2>
                <div className="space-y-2">
                  {followed.filter(matches).map(c => (
                    <ChannelCard key={c.id} channel={c} verified={verifiedNames.has(c.name)} subscribed onToggle={toggle} onOpen={() => navigate(`/channels/${c.id}`)} />
                  ))}
                </div>
              </>
            )}

            {discover.filter(matches).length > 0 && (
              <>
                <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground mt-5 mb-2 px-1">Discover</h2>
                <div className="space-y-2">
                  {discover.filter(matches).map(c => (
                    <ChannelCard key={c.id} channel={c} verified={verifiedNames.has(c.name)} onToggle={toggle} onOpen={() => navigate(`/channels/${c.id}`)} />
                  ))}
                </div>
              </>
            )}

            {mine.filter(matches).length === 0 && followed.filter(matches).length === 0 && discover.filter(matches).length === 0 && (
              <div className="text-center py-16 px-6">
                <p className="font-semibold text-sm">No channels match "{query}"</p>
                <p className="text-xs text-muted-foreground mt-1">Try a different name or handle.</p>
              </div>
            )}
          </>
        )}
      </div>

      <CreateChannelSheet
        open={creating}
        onClose={() => setCreating(false)}
        onCreated={(c) => {
          load();
          if (c?.id) navigate(`/channels/${c.id}`);
        }}
      />
    </div>
  );
}