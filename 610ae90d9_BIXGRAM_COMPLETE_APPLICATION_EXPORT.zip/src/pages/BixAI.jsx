import React, { useState, useEffect, useRef } from "react";
import { Bot, Send, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getAiUsage, recordAiUsage } from "@/lib/social";
import { cn } from "@/lib/utils";

const SUGGESTIONS = [
  "Write a fire caption for a sunset post 🌅",
  "Give me 5 trending hashtags today",
  "How do I grow my following on BIXGRAM?",
  "Explain my Creator Score",
];

const SYSTEM = "You are BIX AI, the friendly built-in assistant of BIXGRAM — a social platform with Community, Live and messaging. Its main areas are Home (written and photo posts), Community (groups, topics and discussions), Live (creator streams), Messenger, Search, Notifications, Trending, Marketplace, Premium and Creator Studio. Its tagline is 'Connect. Share. Live.' Keep answers short, practical and factual — help people write posts, start communities, set up a live, and use app features. Never present uncertain information as confirmed fact, and never claim Bixgram has live video broadcasting or a connected payment backend.";

export default function BixAI() {
  const [messages, setMessages] = useState([
    { role: "ai", text: "Hey! I'm BIX AI ✨ — your creative co-pilot on BIXGRAM. Ask me for captions, hashtags, trend ideas, or tips to grow your Creator Score." },
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [usage, setUsage] = useState({ plan: "free", limit: 20, used: 0, remaining: 20 });
  const scrollRef = useRef(null);

  useEffect(() => {
    getAiUsage().then(setUsage).catch(() => {});
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  const send = async (text) => {
    const prompt = (text || input).trim();
    if (!prompt || thinking) return;
    if (usage.remaining <= 0) {
      setMessages(m => [...m, { role: "user", text: prompt }, { role: "ai", text: "You've reached your BIX AI limit for this month ✨ Head to Menu → Premium for a plan with way more uses." }]);
      return;
    }
    setInput("");
    setMessages(m => [...m, { role: "user", text: prompt }]);
    setThinking(true);
    try {
      const history = messages
        .slice(-8)
        .map(m => `${m.role === "user" ? "User" : "BIX AI"}: ${m.text}`)
        .join("\n");
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `${SYSTEM}\n\nConversation so far:\n${history}\n\nUser: ${prompt}\n\nBIX AI:`,
      });
      setMessages(m => [...m, { role: "ai", text: typeof res === "string" ? res : res?.text || "Hmm, try that again ✨" }]);
      await recordAiUsage("chat").catch(() => {});
      setUsage(u => ({ ...u, used: u.used + 1, remaining: Math.max(0, u.remaining - 1) }));
    } catch {
      setMessages(m => [...m, { role: "ai", text: "I hit a snag reaching my brain — try again in a moment 🙏" }]);
    } finally {
      setThinking(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto flex flex-col h-[calc(100vh-5rem)]">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border px-4 py-3 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bix-gradient flex items-center justify-center bix-glow">
          <Bot className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-extrabold bix-gradient-text leading-tight">BIX AI</h1>
          <p className="text-[11px] text-muted-foreground flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> {usage.used}/{usage.limit} uses this month · {usage.plan} plan
          </p>
        </div>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((m, i) => (
          <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
            <div className={cn(
              "max-w-[85%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed",
              m.role === "user"
                ? "bix-gradient text-white rounded-br-md"
                : "bix-card rounded-bl-md"
            )}>
              {m.text}
            </div>
          </div>
        ))}
        {thinking && (
          <div className="flex justify-start">
            <div className="bix-card px-4 py-3 rounded-2xl rounded-bl-md flex gap-1.5">
              <span className="w-2 h-2 rounded-full bg-primary animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:0.15s]" />
              <span className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:0.3s]" />
            </div>
          </div>
        )}
      </div>

      {messages.length <= 2 && (
        <div className="px-4 pb-2 flex flex-wrap gap-2">
          {SUGGESTIONS.map(s => (
            <button
              key={s}
              onClick={() => send(s)}
              className="px-3 py-1.5 rounded-full bg-secondary/60 text-xs font-medium hover:bg-secondary transition"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      <div className="p-3 border-t border-border">
        <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2.5">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()}
            placeholder="Ask BIX AI anything…"
            className="flex-1 bg-transparent outline-none text-sm"
          />
          <button
            onClick={() => send()}
            disabled={!input.trim() || thinking}
            className="w-9 h-9 rounded-full bix-gradient flex items-center justify-center disabled:opacity-40"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}