import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Search, Heart, MapPin, BadgeCheck, X, Loader2, MoreHorizontal } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { formatCount } from "@/lib/bixgram-data";
import { getMe, getProfile, defaultAvatar, uploadFile, toggleSave, isSavedByMe } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import ListingActionsSheet from "@/components/marketplace/ListingActionsSheet";
import { cn } from "@/lib/utils";

const CATEGORIES = ["All", "Electronics", "Fashion", "Home", "Vehicles", "Other"];

export default function Marketplace() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [cat, setCat] = useState("All");
  const [query, setQuery] = useState("");
  const [listings, setListings] = useState([]);
  const [saved, setSaved] = useState({});
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ title: "", price: "", location: "", description: "", category: "electronics", image_url: null });
  const [uploading, setUploading] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [myName, setMyName] = useState("");
  const [actionsFor, setActionsFor] = useState(null);
  const fileRef = useRef(null);

  const load = async () => {
    setLoading(true);
    try {
      setListings(await base44.entities.MarketplaceListing.list("-created_date", 30));
    } catch {} finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); getMe().then(m => setMyName(m.name)).catch(() => {}); }, []);

  useEffect(() => {
    (async () => {
      const states = {};
      for (const l of listings) {
        if (l.id) states[l.id] = await isSavedByMe("listing", l.id).catch(() => false);
      }
      setSaved(states);
    })();
  }, [listings.length]);

  const q = query.toLowerCase();
  const filtered = listings.filter(l =>
    (cat === "All" || l.category === cat.toLowerCase()) &&
    (!q || l.title?.toLowerCase().includes(q) || l.description?.toLowerCase().includes(q))
  );

  const onSave = async (l) => {
    const res = await toggleSave("listing", l.id).catch(() => null);
    if (res) {
      setSaved(s => ({ ...s, [l.id]: res.saved }));
      toast({ title: res.saved ? "Listing saved" : "Removed from saved" });
    }
  };

  const onImage = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setUploading(true);
    try {
      const url = await uploadFile(file);
      setForm(f => ({ ...f, image_url: url }));
    } catch {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const publish = async () => {
    const price = parseFloat(form.price);
    if (!form.title.trim()) { toast({ title: "Add a title", variant: "destructive" }); return; }
    if (!form.price || isNaN(price) || price <= 0) { toast({ title: "Enter a valid price", variant: "destructive" }); return; }
    setPublishing(true);
    try {
      const me = await getMe();
      let avatar = defaultAvatar(me.name);
      try { avatar = (await getProfile(me.name)).avatar_url || avatar; } catch {}
      const created = await base44.entities.MarketplaceListing.create({
        title: form.title.trim(),
        description: form.description.trim(),
        price,
        category: form.category,
        image_url: form.image_url || "",
        location: form.location.trim(),
        seller_name: me.name,
        seller_avatar: avatar,
        is_saved: false,
      });
      setListings(ls => [created, ...ls]);
      setCreating(false);
      setForm({ title: "", price: "", location: "", description: "", category: "electronics", image_url: null });
      toast({ title: "Listing published 🛍️" });
    } catch {
      toast({ title: "Could not publish listing", variant: "destructive" });
    } finally {
      setPublishing(false);
    }
  };

  const contact = (l) => navigate("/messenger", { state: { openWith: l.seller_name } });

  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-2xl font-extrabold bix-gradient-text">Marketplace</h1>
          <button onClick={() => setCreating(true)} className="w-9 h-9 rounded-full bix-gradient flex items-center justify-center bix-glow">
            <Plus className="w-5 h-5 text-white" />
          </button>
        </div>
        <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2">
          <Search className="w-4.5 h-4.5 text-muted-foreground" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search listings"
            className="flex-1 bg-transparent outline-none text-sm"
          />
          {query && <button onClick={() => setQuery("")}><X className="w-4 h-4 text-muted-foreground" /></button>}
        </div>
      </header>

      <div className="px-3 pt-3 flex gap-1.5 overflow-x-auto no-scrollbar">
        {CATEGORIES.map(c => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={cn(
              "px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition",
              cat === c ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground"
            )}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="p-3 grid grid-cols-2 gap-3">
        {loading ? (
          <div className="col-span-2 flex justify-center py-20">
            <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="col-span-2 text-center py-16 text-sm text-muted-foreground">
            No listings found{query && ` for "${query}"`} — create one! 🛍️
          </div>
        ) : filtered.map((l, i) => (
          <div key={l.id || i} className="bix-card overflow-hidden">
            <div className="relative">
              <img src={l.image_url} alt="" className="w-full h-36 object-cover" />
              {l.status === "sold" && (
                <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-emerald-500 text-white text-[10px] font-bold uppercase">Sold</span>
              )}
              {l.id && (
                <button
                  onClick={() => onSave(l)}
                  className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/40 backdrop-blur flex items-center justify-center"
                >
                  <Heart className={cn("w-4 h-4 text-white", saved[l.id] && "fill-rose-500 text-rose-500")} />
                </button>
              )}
            </div>
            <div className="p-2.5">
              <div className="font-bold text-base">${formatCount(l.price)}</div>
              <div className="text-xs font-medium truncate">{l.title}</div>
              <div className="flex items-center gap-1 text-[10px] text-muted-foreground mt-1">
                <MapPin className="w-3 h-3" /> {l.location}
              </div>
              <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-border">
                <img src={l.seller_avatar} alt="" className="w-5 h-5 rounded-full" />
                <span className="text-[10px] text-muted-foreground truncate flex items-center gap-0.5">
                  {l.seller_name} <BadgeCheck className="w-2.5 h-2.5 text-primary" />
                </span>
                <button onClick={() => contact(l)} className="ml-auto px-2.5 py-1 rounded-full bg-secondary/60 text-[10px] font-semibold hover:bg-secondary transition">Contact</button>
                {l.id && (
                  <button onClick={() => setActionsFor(l)} className="shrink-0">
                    <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {actionsFor && (
          <ListingActionsSheet
            listing={actionsFor}
            isMine={actionsFor.seller_name === myName}
            open={!!actionsFor}
            onClose={() => setActionsFor(null)}
            onUpdated={(u) => { setListings(ls => ls.map(x => (x.id === u.id ? u : x))); setActionsFor(null); }}
            onDeleted={(d) => { setListings(ls => ls.filter(x => x.id !== d.id)); setActionsFor(null); }}
          />
        )}
        </div>

        {creating && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur flex items-end justify-center" onClick={() => setCreating(false)}>
          <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-3 max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg">Create Listing</h3>
              <button onClick={() => setCreating(false)} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
                <X className="w-4 h-4" />
              </button>
            </div>
            <button onClick={() => fileRef.current?.click()} className="w-full aspect-video rounded-xl bg-secondary/50 border-2 border-dashed border-border flex items-center justify-center overflow-hidden">
              {uploading ? (
                <Loader2 className="w-8 h-8 text-muted-foreground animate-spin" />
              ) : form.image_url ? (
                <img src={form.image_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <Plus className="w-8 h-8 text-muted-foreground" />
              )}
            </button>
            <input ref={fileRef} type="file" accept="image/*" hidden onChange={onImage} />
            <input
              value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="Title *"
              className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none"
            />
            <input
              value={form.price}
              onChange={e => setForm(f => ({ ...f, price: e.target.value }))}
              placeholder="Price ($) *"
              inputMode="decimal"
              className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none"
            />
            <input
              value={form.location}
              onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
              placeholder="Location"
              className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none"
            />
            <textarea
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              placeholder="Description"
              rows={2}
              className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none resize-none"
            />
            <div className="flex gap-1.5 flex-wrap">
              {CATEGORIES.slice(1).map(c => (
                <button
                  key={c}
                  onClick={() => setForm(f => ({ ...f, category: c.toLowerCase() }))}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-xs font-semibold transition",
                    form.category === c.toLowerCase() ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground"
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
            <button
              onClick={publish}
              disabled={publishing}
              className="w-full py-3 rounded-xl bix-gradient text-white font-semibold disabled:opacity-50"
            >
              {publishing ? "Publishing…" : "Publish Listing"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}