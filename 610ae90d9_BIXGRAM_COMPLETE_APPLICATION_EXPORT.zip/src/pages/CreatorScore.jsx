import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { formatCount } from "@/lib/bixgram-data";
import { getMe, getProfile } from "@/lib/social";
import { cn } from "@/lib/utils";

const metrics = [
  { key: "originality", label: "Originality", color: "from-cyan-500 to-blue-600", hint: "Unique media, collabs and creative posts" },
  { key: "engagement", label: "Engagement", color: "from-purple-500 to-indigo-600", hint: "Likes, comments and shares your content earns" },
  { key: "consistency", label: "Consistency", color: "from-rose-500 to-pink-600", hint: "How often you publish new content" },
  { key: "community", label: "Community", color: "from-emerald-500 to-teal-600", hint: "Followers and friends you've built" },
];

export default function CreatorScore() {
  const [scores, setScores] = useState([]);
  const [selected, setSelected] = useState(0);
  const [myScore, setMyScore] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        setScores(await base44.entities.CreatorScore.list("-overall_score", 10));
      } catch {
        setScores([]);
      }

      // compute my own score from my real activity
      try {
        const me = await getMe();
        const profile = await getProfile(me.name);
        const posts = await base44.entities.Post.filter({ author_name: me.name }, "-created_date", 100);

        const postCount = posts.length;
        const totalLikes = posts.reduce((s, p) => s + (p.likes_count || 0), 0);
        const totalComments = posts.reduce((s, p) => s + (p.comments_count || 0), 0);
        const mediaCount = posts.filter(p => p.image_url).length;

        const originality = Math.min(100, 40 + Math.round((postCount ? mediaCount / postCount : 0) * 60));
        const engagement = postCount ? Math.min(100, Math.round(((totalLikes / postCount) * 2 + totalComments / postCount) / 2)) : 0;
        const consistency = Math.min(100, postCount * 10);
        const community = Math.min(100, Math.round((profile.followers_count || 0) / 5 + (profile.friends_count || 0) * 2));
        const overall = Math.round((originality + engagement + consistency + community) / 4);

        setMyScore({ originality, engagement, consistency, community, overall, postCount, profile });
      } catch {}
    })();
  }, []);

  const me = scores[selected];

  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border px-4 py-3">
        <h1 className="text-2xl font-extrabold bix-gradient-text">Creator Score</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Your creator performance & leaderboard.</p>
      </header>

      {myScore && (
        <div className="p-3">
          <div className="bix-card p-5 bg-gradient-to-br from-card to-secondary/30">
            <div className="flex items-center gap-4 mb-4">
              <img src={myScore.profile.avatar_url} alt="" className="w-16 h-16 rounded-full object-cover ring-2 ring-primary/40" />
              <div>
                <div className="font-bold text-lg">Your Score</div>
                <div className="text-xs text-muted-foreground">{myScore.postCount} posts · {formatCount(myScore.profile.followers_count || 0)} followers</div>
              </div>
              <div className="ml-auto text-center">
                <div className="text-3xl font-extrabold bix-gradient-text">{myScore.overall}</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Overall Score</div>
              </div>
            </div>
            <div className="space-y-3">
              {metrics.map(m => (
                <div key={m.key}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-muted-foreground">{m.label}</span>
                    <span className="font-bold">{myScore[m.key]}/100</span>
                  </div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <div className={cn("h-full rounded-full bg-gradient-to-r", m.color)} style={{ width: `${myScore[m.key]}%` }} />
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1">{m.hint}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="px-3 pb-4">
        <h2 className="font-bold text-sm mb-2 px-1">🏆 Top Creators Leaderboard</h2>
        <div className="bix-card overflow-hidden">
          {scores.length === 0 ? (
            <div className="text-center py-8 text-sm text-muted-foreground">No creators on the leaderboard yet</div>
          ) : scores.map((s, i) => (
            <button
              key={s.id || i}
              onClick={() => setSelected(i)}
              className={cn("w-full flex items-center gap-3 p-3 border-b border-border last:border-0 transition", selected === i ? "bg-primary/10" : "hover:bg-secondary/40")}
            >
              <div className={cn("w-7 h-7 rounded-full flex items-center justify-center text-xs font-extrabold shrink-0", i < 3 ? "bix-gradient text-white" : "bg-secondary text-muted-foreground")}>
                {i + 1}
              </div>
              <img src={s.creator_avatar} alt="" className="w-9 h-9 rounded-full object-cover" />
              <span className="flex-1 text-left font-semibold text-sm">{s.creator_name}</span>
              <span className="font-bold text-sm bix-gradient-text">{s.overall_score}</span>
            </button>
          ))}
        </div>
      </div>

      {me && (
        <div className="px-3 pb-6">
          <div className="bix-card p-4">
            <div className="flex items-center gap-3">
              <img src={me.creator_avatar} alt="" className="w-12 h-12 rounded-full object-cover" />
              <div className="flex-1">
                <div className="font-bold">{me.creator_name}</div>
                <div className="text-xs text-muted-foreground">{formatCount(me.followers)} followers · score {me.overall_score}/100</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-3">
              {metrics.map(m => (
                <div key={m.key} className="rounded-xl bg-secondary/40 p-2.5">
                  <div className="text-[10px] text-muted-foreground uppercase font-bold">{m.label}</div>
                  <div className="text-sm font-bold">{me[m.key]}/100</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}