import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Users, MessageSquare, Search, X, UsersRound } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { WORLD_CATEGORIES, formatCount } from "@/lib/bixgram-data";
import { getMe } from "@/lib/social";
import { WORLD_ICONS } from "@/lib/world-icons";
import { cn } from "@/lib/utils";

export default function Community() {
  const navigate = useNavigate();
  const [communities, setCommunities] = useState([]);
  const [myIds, setMyIds] = useState([]);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState("All");
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", category: WORLD_CATEGORIES[0].name });
  const [creating, setCreating] = useState(false);

  const load = async () => {
    try {
      setCommunities(await base44.entities.World.list());
      const me = await getMe();
      const memberships = await base44.entities.WorldMembership.filter({ user_name: me.name });
      setMyIds(memberships.map(m => String(m.world_id)));
    } catch {}
  };

  useEffect(() => { load(); }, []);

  const toggleJoin = async (c) => {
    const me = await getMe();
    const joined = myIds.includes(String(c.id));
    if (joined) {
      await base44.entities.WorldMembership.deleteMany({ world_id: c.id, user_name: me.name });
      await base44.entities.World.updateMany({ id: c.id }, { $inc: { members_count: -1 } });
      setMyIds(ids => ids.filter(x => x !== String(c.id)));
      setCommunities(cs => cs.map(x => x.id === c.id ? { ...x, members_count: Math.max(0, (x.members_count || 0) - 1) } : x));
    } else {
      await base44.entities.WorldMembership.create({ world_id: c.id, world_name: c.name, user_name: me.name });
      await base44.entities.World.updateMany({ id: c.id }, { $inc: { members_count: 1 } });
      setMyIds(ids => [...ids, String(c.id)]);
      setCommunities(cs => cs.map(x => x.id === c.id ? { ...x, members_count: (x.members_count || 0) + 1 } : x));
    }
  };

  const createCommunity = async () => {
    if (!form.name.trim()) return;
    setCreating(true);
    try {
      const category = WORLD_CATEGORIES.find(c => c.name === form.category) || WORLD_CATEGORIES[0];
      const created = await base44.entities.World.create({
        name: form.name.trim(),
        icon: category.icon,
        color: category.color,
        description: form.description.trim(),
        members_count: 1,
        posts_count: 0,
        category: category.name,
      });
      const me = await getMe();
      await base44.entities.WorldMembership.create({ world_id: created.id, world_name: created.name, user_name: me.name });
      setCreateOpen(false);
      setForm({ name: "", description: "", category: WORLD_CATEGORIES[0].name });
      navigate(`/communities/${created.id}`);
    } catch {} finally {
      setCreating(false);
    }
  };

  const filtered = communities.filter(c =>
    (cat === "All" || c.category === cat) &&
    c.name?.toLowerCase().includes(query.toLowerCase())
  );
  const categories = ["All", ...new Set(communities.map(c => c.category).filter(Boolean))];

  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/85 backdrop-blur-xl border-b border-border px-4 py-3">
        <div className="mb-3">
          <h1 className="text-xl font-extrabold bix-gradient-text">Community</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Find your people, join the conversation.</p>
        </div>
        <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2.5">
          <Search className="w-[18px] h-[18px] text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search communities"
            className="flex-1 min-w-0 bg-transparent outline-none text-sm"
          />
          {query && (
            <button onClick={() => setQuery("")} aria-label="Clear search">
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          )}
        </div>
        {categories.length > 2 && (
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar mt-2.5">
            {categories.map(c => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-medium shrink-0 border transition",
                  cat === c ? "bix-gradient text-white border-transparent" : "border-border text-muted-foreground"
                )}
              >
                {c}
              </button>
            ))}
          </div>
        )}
      </header>

      <div className="p-3 space-y-3 pb-[calc(5rem+env(safe-area-inset-bottom))]">
        <button onClick={() => setCreateOpen(true)} className="w-full bix-card p-4 flex items-center gap-3 bix-press">
          <div className="w-12 h-12 rounded-xl bix-gradient flex items-center justify-center bix-glow shrink-0">
            <Plus className="w-6 h-6 text-white" />
          </div>
          <div className="text-left">
            <div className="font-semibold text-sm">Create a Community</div>
            <div className="text-xs text-muted-foreground">Start a space around what you care about</div>
          </div>
        </button>

        {filtered.map(c => {
          const Icon = WORLD_ICONS[c.icon] || UsersRound;
          const isJoined = myIds.includes(String(c.id));
          return (
            <div key={c.id} className="bix-card overflow-hidden">
              <button onClick={() => c.id && navigate(`/communities/${c.id}`)} className="block w-full text-left">
                <div className="relative h-24">
                  {c.cover_url && <img src={c.cover_url} alt="" className="w-full h-full object-cover" />}
                  <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
                  <div className={cn("absolute -bottom-6 left-4 w-14 h-14 rounded-2xl bg-gradient-to-br flex items-center justify-center shadow-lg border-2 border-card", c.color)}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                </div>
              </button>
              <div className="px-4 pt-8 pb-3">
                <div className="flex items-center justify-between gap-2">
                  <button onClick={() => c.id && navigate(`/communities/${c.id}`)} className="text-left min-w-0">
                    <h3 className="font-bold text-base truncate">{c.name}</h3>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                      <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{formatCount(c.members_count || 0)}</span>
                      <span className="flex items-center gap-1"><MessageSquare className="w-3.5 h-3.5" />{formatCount(c.posts_count || 0)} posts</span>
                    </div>
                  </button>
                  {c.id && (
                    <button
                      onClick={() => toggleJoin(c)}
                      className={cn(
                        "px-5 py-2 rounded-full text-xs font-semibold transition shrink-0",
                        isJoined ? "bg-secondary text-muted-foreground" : "bix-gradient text-white"
                      )}
                    >
                      {isJoined ? "Joined" : "Join"}
                    </button>
                  )}
                </div>
                {c.description && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{c.description}</p>}
              </div>
            </div>
          );
        })}

        {filtered.length === 0 && (
          <div className="text-center py-16 px-6">
            <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
              <UsersRound className="w-6 h-6 text-muted-foreground" />
            </div>
            <p className="font-semibold text-sm">
              {query ? `No communities match "${query}"` : "No communities yet"}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {query ? "Try another name or category." : "Create the first one and invite people in."}
            </p>
          </div>
        )}
      </div>

      {createOpen && (
        <div className="fixed inset-0 z-[70] bg-black/60 backdrop-blur flex items-end justify-center" onClick={() => setCreateOpen(false)}>
          <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg">Create a Community</h3>
              <button onClick={() => setCreateOpen(false)} aria-label="Close" className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Community name</label>
              <input
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="e.g. Afrobeats Fans"
                className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none mt-1"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Description</label>
              <textarea
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                rows={3}
                placeholder="What is this community about?"
                className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none mt-1 resize-none"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Category</label>
              <div className="flex gap-2 flex-wrap mt-1.5">
                {WORLD_CATEGORIES.map(c => (
                  <button
                    key={c.name}
                    onClick={() => setForm(f => ({ ...f, category: c.name }))}
                    className={cn(
                      "px-3 py-1.5 rounded-full text-xs font-medium transition",
                      form.category === c.name ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground"
                    )}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            </div>
            <button
              onClick={createCommunity}
              disabled={!form.name.trim() || creating}
              className="w-full py-3 rounded-full bix-gradient text-white font-semibold disabled:opacity-50 bix-press"
            >
              {creating ? "Creating…" : "Create Community"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}