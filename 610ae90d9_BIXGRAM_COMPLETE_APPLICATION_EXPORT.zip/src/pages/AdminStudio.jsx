import React, { useState, useEffect } from "react";
import { LayoutDashboard, Users, FileText, Newspaper, Flag, Shield, Globe2, ShoppingBag, Crown, DollarSign, TrendingUp, Settings, Ban, BarChart3, Bot, ShieldAlert, Radio, BadgeCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { formatCount } from "@/lib/bixgram-data";
import { cn } from "@/lib/utils";
import BixLogo from "@/components/BixLogo";
import EntityPanel from "@/components/admin/EntityPanel";
import ModerationQueue from "@/components/admin/ModerationQueue";
import MonetizationPanel from "@/components/admin/MonetizationPanel";
import VerificationPanel from "@/components/admin/VerificationPanel";

const NAV = [
  { label: "Dashboard", icon: LayoutDashboard },
  { label: "Users", icon: Users },
  { label: "Posts", icon: FileText },
  { label: "Reports", icon: Flag },
  { label: "Moderation", icon: Shield },
  { label: "Communities", icon: Globe2 },
  { label: "Channels", icon: Radio },
  { label: "Monetization", icon: DollarSign },
  { label: "Verification", icon: BadgeCheck },
  { label: "Marketplace", icon: ShoppingBag },
  { label: "Premium", icon: Crown },
  { label: "Promotions", icon: TrendingUp },
  { label: "Revenue", icon: DollarSign },
  { label: "Analytics", icon: BarChart3 },
  { label: "BIX AI Moderation", icon: Bot },
  { label: "Banned Accounts", icon: Ban },
  { label: "Settings", icon: Settings },
];

export default function AdminStudio() {
  const [active, setActive] = useState("Dashboard");
  const [denied, setDenied] = useState(false);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({});
  const [refreshKey, setRefreshKey] = useState(0);

  // Access control: only platform admins may open the Admin Studio.
  // The platform also enforces admin-only access server-side (e.g. user listing).
  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        // Server-side RLS independently restricts admin data to the "admin" role;
        // this gate only hides the UI for accounts without admin/owner access.
        if (me?.role !== "admin" && me?.role !== "owner") setDenied(true);
      } catch {
        setDenied(true);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (denied || loading) return;
    (async () => {
      const d = {};
      const safe = async (k, fn) => { try { d[k] = await fn(); } catch { d[k] = []; } };
      await safe("users", () => base44.entities.User.list(50));
      await safe("posts", () => base44.entities.Post.list("-created_date", 50));
      await safe("worlds", () => base44.entities.World.list(50));
      await safe("channels", () => base44.entities.Channel.list("-created_date", 50));
      await safe("listings", () => base44.entities.MarketplaceListing.list(50));
      await safe("promotions", () => base44.entities.Promotion.list("-created_date", 50));
      await safe("flags", () => base44.entities.ModerationFlag.filter({ status: "flagged" }));
      await safe("reports", () => base44.entities.Report.filter({ status: "open" }));
      setData(d);
    })();
  }, [denied, loading, refreshKey, active]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-10 h-10 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (denied) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-6">
        <div className="bix-card p-8 max-w-sm text-center">
          <ShieldAlert className="w-12 h-12 text-rose-400 mx-auto mb-4" />
          <h1 className="text-xl font-extrabold">Restricted Area</h1>
          <p className="text-sm text-muted-foreground mt-2">
            The Admin Studio is for BIXGRAM administrators only. Your account doesn't have admin access.
          </p>
        </div>
      </div>
    );
  }

  const promoRevenue = (data.promotions || []).reduce((s, p) => s + (p.price || 0), 0);

  const resolveReport = async (r, status) => {
    await base44.entities.Report.update(r.id, { status }).catch(() => {});
    setData(d => ({ ...d, reports: (d.reports || []).filter(x => x.id !== r.id) }));
  };
  const STATS = [
    { label: "Total Users", value: formatCount((data.users || []).length), icon: Users, color: "from-cyan-500 to-blue-600" },
    { label: "Posts", value: formatCount((data.posts || []).length), icon: FileText, color: "from-purple-500 to-indigo-600" },
    { label: "Promo Revenue", value: `$${formatCount(promoRevenue)}`, icon: DollarSign, color: "from-amber-500 to-orange-600" },
    { label: "Open Reports", value: formatCount((data.flags || []).length), icon: Flag, color: "from-red-500 to-rose-600" },
    { label: "Promotions", value: formatCount((data.promotions || []).length), icon: TrendingUp, color: "from-sky-500 to-cyan-600" },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col lg:flex-row">
      <aside className="lg:w-64 lg:min-h-screen border-r border-border bg-sidebar/50 lg:fixed lg:left-0 lg:top-0 lg:bottom-0 overflow-y-auto">
        <div className="p-4 border-b border-border flex items-center gap-2">
          <BixLogo size={32} />
          <div className="lg:ml-2">
            <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">Admin Studio</div>
          </div>
        </div>
        <nav className="p-2 flex lg:flex-col gap-1 overflow-x-auto no-scrollbar">
          {NAV.map(n => (
            <button
              key={n.label}
              onClick={() => setActive(n.label)}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition w-full text-left",
                active === n.label ? "bix-gradient text-white" : "text-muted-foreground hover:bg-secondary/50"
              )}
            >
              <n.icon className="w-5 h-5 shrink-0" /> {n.label}
            </button>
          ))}
        </nav>
      </aside>

      <main className="flex-1 lg:ml-64 p-4 lg:p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-extrabold">{active}</h1>
          <p className="text-sm text-muted-foreground">BIXGRAM Admin Studio — restricted access</p>
        </div>

        {active === "Dashboard" && (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
              {STATS.map(s => (
                <div key={s.label} className="bix-card p-4">
                  <div className={cn("w-10 h-10 rounded-xl bg-gradient-to-br flex items-center justify-center mb-3", s.color)}>
                    <s.icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-2xl font-extrabold">{s.value}</div>
                  <span className="text-xs text-muted-foreground">{s.label}</span>
                </div>
              ))}
            </div>
            <ModerationQueue refreshKey={refreshKey} onHandled={() => setRefreshKey(k => k + 1)} />
          </>
        )}

        {active === "Users" && (
          <EntityPanel
            icon={Users}
            title="Users"
            emptyText="No users found — the platform only lists users for admins."
            rows={(data.users || []).map(u => ({
              id: u.id,
              avatar: u.image_url,
              primary: u.full_name || u.username || "Unnamed user",
              secondary: u.email,
              meta: u.role,
            }))}
          />
        )}

        {active === "Posts" && (
          <EntityPanel
            icon={FileText}
            title="Posts"
            rows={(data.posts || []).map(p => ({
              id: p.id,
              primary: (p.text || "(media post)").slice(0, 60),
              secondary: `@${p.author_name}${p.world_name ? ` · ${p.world_name}` : ""}`,
              meta: `❤️ ${formatCount(p.likes_count || 0)}`,
            }))}
          />
        )}

        {active === "Reports" && (
          <div className="bix-card p-4">
            <div className="flex items-center gap-2 mb-3">
              <Flag className="w-5 h-5 text-primary" />
              <h3 className="font-bold">User Reports</h3>
              <span className="ml-auto text-xs text-muted-foreground">{(data.reports || []).length} open</span>
            </div>
            {(data.reports || []).length === 0 ? (
              <div className="text-center py-10 text-sm text-muted-foreground">No open reports — all clear ✨</div>
            ) : (data.reports || []).map(r => (
              <div key={r.id} className="border-b border-border last:border-0 py-3 first:pt-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 capitalize">{r.reason?.replace("_", " ")}</span>
                  <span className="text-[10px] text-muted-foreground">{r.target_type} · reported by @{r.reporter_name}</span>
                </div>
                {r.target_label && <p className="text-sm mb-1 line-clamp-2">"{r.target_label.slice(0, 80)}"</p>}
                {r.details && <p className="text-xs text-muted-foreground mb-2">{r.details}</p>}
                <div className="flex gap-2">
                  <button onClick={() => resolveReport(r, "resolved")} className="px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold">Resolve</button>
                  <button onClick={() => resolveReport(r, "dismissed")} className="px-3 py-1.5 rounded-lg bg-secondary text-muted-foreground text-xs font-semibold">Dismiss</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {(active === "Moderation" || active === "BIX AI Moderation") && (
          <ModerationQueue refreshKey={refreshKey} onHandled={() => setRefreshKey(k => k + 1)} />
        )}

        {active === "Worlds" && (
          <EntityPanel
            icon={Globe2}
            title="Communities"
            rows={(data.worlds || []).map(w => ({
              id: w.id,
              primary: w.name,
              secondary: w.description,
              meta: `${formatCount(w.members_count || 0)} members`,
            }))}
          />
        )}

        {active === "Channels" && (
          <EntityPanel
            icon={Radio}
            title="Channels"
            emptyText="No channels yet."
            rows={(data.channels || []).map(c => ({
              id: c.id,
              primary: c.name,
              secondary: `@${c.username} · ${c.category || "General"}`,
              meta: `${formatCount(c.subscribers_count || 0)} subs`,
            }))}
          />
        )}

        {active === "Monetization" && <MonetizationPanel />}

        {active === "Verification" && <VerificationPanel />}

        {active === "Marketplace" && (
          <EntityPanel
            icon={ShoppingBag}
            title="Marketplace Listings"
            rows={(data.listings || []).map(l => ({
              id: l.id,
              primary: l.title,
              secondary: `@${l.seller_name} · ${l.location}`,
              meta: `$${l.price}`,
            }))}
          />
        )}

        {active === "Premium" && (
          <div className="grid gap-3 lg:grid-cols-3">
            {["Basic — $2/mo", "Top — $6/mo", "Pro — $10/mo"].map(p => (
              <div key={p} className="bix-card p-4">
                <Crown className="w-6 h-6 text-amber-400 mb-2" />
                <div className="font-bold text-sm">{p}</div>
                <p className="text-xs text-muted-foreground mt-1">Subscriber counts sync once payments are connected.</p>
              </div>
            ))}
          </div>
        )}

        {active === "Promotions" && (
          <EntityPanel
            icon={TrendingUp}
            title="Promotions"
            rows={(data.promotions || []).map(p => ({
              id: p.id,
              primary: `${p.package?.toUpperCase()} package · ${p.duration_days} days`,
              secondary: `@${p.user_name} · post ${String(p.post_id).slice(-6)}`,
              meta: `$${p.price} · ~${formatCount(p.estimated_views || 0)} views`,
            }))}
          />
        )}

        {active === "Revenue" && (
          <div className="bix-card p-5">
            <h3 className="font-bold mb-1">Promotion Revenue</h3>
            <div className="text-3xl font-extrabold bix-gradient-text my-2">${formatCount(promoRevenue)}</div>
            <p className="text-xs text-muted-foreground">
              Real-time revenue from post promotions. Subscription revenue appears here once payments are connected.
            </p>
          </div>
        )}

        {active === "Analytics" && (
          <>
            <div className="bix-card p-5 mb-4">
              <h3 className="font-bold mb-3">Content Overview</h3>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                {[
                  ["Posts", (data.posts || []).length],
                  ["Communities", (data.worlds || []).length],
                  ["Listings", (data.listings || []).length],
                ].map(([l, v]) => (
                  <div key={l} className="rounded-xl bg-secondary/40 p-3 text-center">
                    <div className="text-xl font-extrabold">{formatCount(v)}</div>
                    <div className="text-[10px] text-muted-foreground uppercase">{l}</div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {active === "Banned Accounts" && (
          <>
            <div className="bix-card p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Bans are enforced through the platform's user management — banned users lose app access entirely. Review flagged accounts below.
              </p>
            </div>
            <ModerationQueue refreshKey={refreshKey} onHandled={() => setRefreshKey(k => k + 1)} />
          </>
        )}

        {active === "Settings" && (
          <div className="bix-card p-6 text-sm text-muted-foreground">
            Admin settings — platform-level configuration is managed in the workspace dashboard.
          </div>
        )}
      </main>
    </div>
  );
}