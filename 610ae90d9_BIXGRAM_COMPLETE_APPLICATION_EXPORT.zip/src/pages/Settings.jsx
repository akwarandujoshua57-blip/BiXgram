import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { User, Lock, Shield, Bell, Sliders, Ban, Languages, Palette, Crown, LifeBuoy, LogOut, ChevronRight, Moon, Sun, X, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { getMe, getProfile, clearMeCache } from "@/lib/social";
import BlockedUsersSheet from "@/components/settings/BlockedUsersSheet";
import { useToast } from "@/components/ui/use-toast";

export default function Settings() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [dark, setDark] = useState(true);
  const [sheet, setSheet] = useState(null); // "account" | "privacy" | "security" | "notifications" | "language" | "help"
  const [account, setAccount] = useState(null);
  const [privacy, setPrivacy] = useState({ privateAccount: false, messages: "Everyone" });
  const [notif, setNotif] = useState({ push: true, likes: true, comments: true, follows: true, messages: true });
  const [lang, setLang] = useState("English (US)");

  const openAccount = async () => {
    try {
      const me = await getMe();
      setAccount({ name: me.name, email: me.email });
    } catch {}
    setSheet("account");
  };

  const openPrivacy = async () => {
    try {
      const me = await getMe();
      const p = await getProfile(me.name);
      setPrivacy({
        privateAccount: p?.privacy?.account_visibility === "private",
        messages: p?.privacy?.who_can_message === "followers" ? "Friends" : p?.privacy?.who_can_message === "no_one" ? "No one" : "Everyone",
      });
    } catch {}
    setSheet("privacy");
  };

  // Privacy settings persist on the account's own profile record — they are
  // enforced by the app when new conversations start (see Messenger).
  const savePrivacy = async () => {
    try {
      const me = await getMe();
      const p = await getProfile(me.name);
      const who = privacy.messages === "Friends" ? "followers" : privacy.messages === "No one" ? "no_one" : "everyone";
      if (p?.id) {
        await base44.entities.Profile.update(p.id, {
          privacy: { account_visibility: privacy.privateAccount ? "private" : "public", who_can_message: who },
        });
      }
      toast({ title: "Privacy settings saved" });
      setSheet(null);
    } catch {
      toast({ title: "Could not save privacy settings", variant: "destructive" });
    }
  };

  const Toggle = ({ on, onClick }) => (
    <button onClick={onClick} className={cn("w-12 h-6 rounded-full transition relative shrink-0", on ? "bix-gradient" : "bg-secondary")}>
      <span className={cn("absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all", on ? "left-6" : "left-0.5")} />
    </button>
  );

  const Sheet = ({ title, children }) => (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur flex items-end justify-center" onClick={() => setSheet(null)}>
      <div className="w-full max-w-md bg-card rounded-t-3xl p-5 max-h-[75vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-lg">{title}</h3>
          <button onClick={() => setSheet(null)} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );

  const row = (label, value, action) => (
    <div className="flex items-center justify-between py-3 border-b border-border last:border-0">
      <span className="text-sm">{label}</span>
      {action || <span className="text-sm text-muted-foreground">{value}</span>}
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border px-4 py-3">
        <h1 className="text-2xl font-extrabold bix-gradient-text">Settings</h1>
      </header>

      <div className="p-3 space-y-4">
        <div className="bix-card overflow-hidden">
          <button onClick={openAccount} className="w-full flex items-center gap-3 p-3 hover:bg-secondary/40 transition border-b border-border">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center"><User className="w-5 h-5 text-primary" /></div>
            <div className="flex-1 text-left"><div className="font-medium text-sm">Account</div><div className="text-xs text-muted-foreground">Username, phone, email</div></div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={openPrivacy} className="w-full flex items-center gap-3 p-3 hover:bg-secondary/40 transition border-b border-border">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center"><Lock className="w-5 h-5 text-primary" /></div>
            <div className="flex-1 text-left"><div className="font-medium text-sm">Privacy</div><div className="text-xs text-muted-foreground">Who can see your content</div></div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => setSheet("security")} className="w-full flex items-center gap-3 p-3 hover:bg-secondary/40 transition border-b border-border">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center"><Shield className="w-5 h-5 text-primary" /></div>
            <div className="flex-1 text-left"><div className="font-medium text-sm">Security</div><div className="text-xs text-muted-foreground">Password, 2FA, login activity</div></div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => setSheet("notifications")} className="w-full flex items-center gap-3 p-3 hover:bg-secondary/40 transition border-b border-border">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center"><Bell className="w-5 h-5 text-primary" /></div>
            <div className="flex-1 text-left"><div className="font-medium text-sm">Notifications</div><div className="text-xs text-muted-foreground">Push, email, in-app</div></div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => navigate("/choose-feed")} className="w-full flex items-center gap-3 p-3 hover:bg-secondary/40 transition border-b border-border">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center"><Sliders className="w-5 h-5 text-primary" /></div>
            <div className="flex-1 text-left"><div className="font-medium text-sm">Content Preferences</div><div className="text-xs text-muted-foreground">Feed, sensitive content</div></div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => setSheet("blocked")} className="w-full flex items-center gap-3 p-3 hover:bg-secondary/40 transition border-b border-border">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center"><Ban className="w-5 h-5 text-primary" /></div>
            <div className="flex-1 text-left"><div className="font-medium text-sm">Blocked Users</div><div className="text-xs text-muted-foreground">Manage blocked accounts</div></div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => setSheet("language")} className="w-full flex items-center gap-3 p-3 hover:bg-secondary/40 transition border-b border-border">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center"><Languages className="w-5 h-5 text-primary" /></div>
            <div className="flex-1 text-left"><div className="font-medium text-sm">Language</div><div className="text-xs text-muted-foreground">{lang}</div></div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => navigate("/premium")} className="w-full flex items-center gap-3 p-3 hover:bg-secondary/40 transition">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center"><Crown className="w-5 h-5 text-primary" /></div>
            <div className="flex-1 text-left"><div className="font-medium text-sm">Premium</div><div className="text-xs text-muted-foreground">Manage subscription</div></div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => setSheet("help")} className="w-full flex items-center gap-3 p-3 hover:bg-secondary/40 transition">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center"><LifeBuoy className="w-5 h-5 text-primary" /></div>
            <div className="flex-1 text-left"><div className="font-medium text-sm">Help & Support</div><div className="text-xs text-muted-foreground">Support center, FAQ</div></div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="bix-card p-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-secondary/60 flex items-center justify-center">
              {dark ? <Moon className="w-5 h-5 text-primary" /> : <Sun className="w-5 h-5 text-amber-400" />}
            </div>
            <div>
              <div className="font-medium text-sm">Appearance</div>
              <div className="text-xs text-muted-foreground">Dark mode — BIXGRAM dark navy theme</div>
            </div>
          </div>
          <Toggle on={dark} onClick={() => setDark(!dark)} />
        </div>

        <button
          onClick={() => { clearMeCache(); base44.auth.logout(); }}
          className="w-full bix-card p-3 flex items-center justify-center gap-2 text-rose-400 font-semibold text-sm hover:bg-rose-500/10 transition"
        >
          <LogOut className="w-5 h-5" /> Logout
        </button>
      </div>

      {sheet === "account" && (
        <Sheet title="Account">
          {row("Username", account?.name)}
          {row("Email", account?.email)}
          {row("Phone", "Not added yet")}
          <button onClick={() => navigate("/profile")} className="w-full mt-4 py-3 rounded-xl bix-gradient text-white font-semibold">
            Edit Profile
          </button>
        </Sheet>
      )}

      {sheet === "privacy" && (
        <Sheet title="Privacy">
          {row("Private account", null, <Toggle on={privacy.privateAccount} onClick={() => setPrivacy(p => ({ ...p, privateAccount: !p.privateAccount }))} />)}
          <div className="py-3 border-b border-border">
            <div className="text-sm mb-2">Who can message you</div>
            <div className="flex gap-2">
              {["Everyone", "Friends", "No one"].map(v => (
                <button key={v} onClick={() => setPrivacy(p => ({ ...p, messages: v }))} className={cn("flex-1 py-2 rounded-xl text-xs font-semibold", privacy.messages === v ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground")}>
                  {v}
                </button>
              ))}
            </div>
          </div>
          <button onClick={savePrivacy} className="w-full mt-4 py-3 rounded-xl bix-gradient text-white font-semibold">
            Save
          </button>
        </Sheet>
      )}

      {sheet === "security" && (
        <Sheet title="Security">
          {row("Password", "••••••••")}
          {row("Two-factor auth", "Off", <Toggle on={false} onClick={() => toast({ title: "2FA coming soon" })} />)}
          {row("Login activity", "1 active session")}
          <button onClick={() => navigate("/forgot-password")} className="w-full mt-4 py-3 rounded-xl bg-secondary font-semibold text-sm">
            Change Password
          </button>
        </Sheet>
      )}

      {sheet === "notifications" && (
        <Sheet title="Notifications">
          {row("Push notifications", null, <Toggle on={notif.push} onClick={() => setNotif(n => ({ ...n, push: !n.push }))} />)}
          {row("Likes", null, <Toggle on={notif.likes} onClick={() => setNotif(n => ({ ...n, likes: !n.likes }))} />)}
          {row("Comments", null, <Toggle on={notif.comments} onClick={() => setNotif(n => ({ ...n, comments: !n.comments }))} />)}
          {row("New followers", null, <Toggle on={notif.follows} onClick={() => setNotif(n => ({ ...n, follows: !n.follows }))} />)}
          {row("Messages", null, <Toggle on={notif.messages} onClick={() => setNotif(n => ({ ...n, messages: !n.messages }))} />)}
        </Sheet>
      )}

      {sheet === "blocked" && <BlockedUsersSheet open onClose={() => setSheet(null)} />}

      {sheet === "language" && (
        <Sheet title="Language">
          {["English (US)", "English (UK)", "Français", "Português"].map(v => (
            <button key={v} onClick={() => { setLang(v); toast({ title: `Language set to ${v}` }); }} className="w-full flex items-center justify-between py-3 border-b border-border last:border-0">
              <span className="text-sm">{v}</span>
              {lang === v && <Check className="w-4 h-4 text-primary" />}
            </button>
          ))}
        </Sheet>
      )}

      {sheet === "help" && (
        <Sheet title="Help & Support">
          {[
            ["How do I post a photo?", "Tap the Photo button in the composer, pick an image, and hit Post."],
            ["How do I join a Community?", "Open Community, find one you like, and tap Join."],
            ["How do Promotions work?", "Pick a package — estimated views are targets, not guarantees."],
            ["How do I go Live?", "Open Live and tap Go Live. Add a title and start streaming."],
          ].map(([q, a]) => (
            <div key={q} className="py-3 border-b border-border last:border-0">
              <div className="font-semibold text-sm">{q}</div>
              <p className="text-xs text-muted-foreground mt-1">{a}</p>
            </div>
          ))}
        </Sheet>
      )}
    </div>
  );
}