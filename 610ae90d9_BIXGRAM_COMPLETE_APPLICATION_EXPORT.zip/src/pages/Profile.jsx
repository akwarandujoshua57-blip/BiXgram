import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { BadgeCheck, MapPin, Grid3x3, Film, Bookmark, Image as ImageIcon, UserPlus, MessageCircle, Check, CheckCheck, Ban, Flag, Crown, Heart, Menu as MenuIcon } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { formatCount } from "@/lib/bixgram-data";
import {
  getMe, getProfile, isFollowing, toggleFollow, defaultAvatar,
  getFriendship, sendFriendRequest, getMySavedIds,
  toggleBlock, isBlockedByMe,
} from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import ReportSheet from "@/components/shared/ReportSheet";
import { isUserVerified } from "@/lib/channels";
import { cn } from "@/lib/utils";
import PostCard from "@/components/feed/PostCard";
import EditProfileSheet from "@/components/profile/EditProfileSheet";

const TAB_ICONS = {
  Posts: Grid3x3, Photos: ImageIcon, Likes: Heart, Saved: Bookmark,
};

export default function Profile() {
  const { username: paramUser } = useParams();
  const navigate = useNavigate();
  const [me, setMe] = useState(null);
  const [profile, setProfile] = useState(null);
  const [verified, setVerified] = useState(false);
  const [isMe, setIsMe] = useState(true);
  const [posts, setPosts] = useState([]);
  const [savedPosts, setSavedPosts] = useState([]);
  const [following, setFollowing] = useState(false);
  const [friendship, setFriendship] = useState(null);
  const [blocked, setBlocked] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [likedPosts, setLikedPosts] = useState([]);
  const [tab, setTab] = useState(() => new URLSearchParams(window.location.search).get("tab") || "Posts");
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const m = await getMe();
      setMe(m);
      const uname = paramUser ? decodeURIComponent(paramUser) : m.name;
      const mine = uname === m.name;
      setIsMe(mine);
      const p = await getProfile(uname);
      setProfile(p);
      // Collab posts appear on BOTH creators' profiles
      const allPosts = await base44.entities.Post.list("-created_date", 200).catch(() => []);
      setPosts(allPosts.filter(p => p.author_name === uname || p.collab_partner_name === uname));
      if (mine) {
        const ids = await getMySavedIds("post").catch(() => []);
        setSavedPosts(allPosts.filter(pp => ids.includes(String(pp.id))));
        const reactionIds = (await base44.entities.Reaction.filter({ target_type: "post", user_name: m.name }).catch(() => [])).map(r => String(r.target_id));
        setLikedPosts(allPosts.filter(pp => reactionIds.includes(String(pp.id))));
      } else {
        setFollowing(await isFollowing(uname).catch(() => false));
        setFriendship(await getFriendship(m.name, uname).catch(() => null));
        setBlocked(await isBlockedByMe(uname).catch(() => false));
      }
    } catch {} finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [paramUser]);

  // The verification badge reflects the admin-controlled record, so an account
  // can't award itself a badge by editing its own profile.
  useEffect(() => {
    if (!profile) return;
    let alive = true;
    (async () => {
      const names = [profile.full_name, profile.username].filter(Boolean);
      for (const n of names) {
        if (await isUserVerified(n)) { if (alive) setVerified(true); return; }
      }
      if (alive) setVerified(false);
    })();
    return () => { alive = false; };
  }, [profile?.full_name, profile?.username]);

  if (loading || !profile) {
    return (
      <div className="flex justify-center py-24">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const photos = posts.filter(p => p.image_url);
  const tabs = isMe ? ["Posts", "Photos", "Likes", "Saved"] : ["Posts", "Photos"];
  const handle = "@" + profile.username.replace(/\s+/g, "").toLowerCase();

  const handleFollow = async () => {
    setFollowing(await toggleFollow(profile.username));
    setProfile(p => ({ ...p, followers_count: Math.max(0, (p.followers_count || 0) + (following ? -1 : 1)) }));
  };

  const handleFriend = async () => {
    if (!friendship) {
      await sendFriendRequest(profile.username);
      setFriendship({ status: "pending", requester_name: me.name });
    }
  };

  const handleMessage = () => navigate("/messenger", { state: { openWith: profile.username } });

  const grid = (items, kind) => (
    <div className="grid grid-cols-3 gap-1 mt-3">
      {items.length === 0 ? (
        <div className="col-span-3 text-center py-10 text-sm text-muted-foreground">Nothing here yet</div>
      ) : items.map((it, i) => (
        <div key={it.id || i} className="aspect-square rounded-lg overflow-hidden bg-secondary">
          <img src={it.image_url} alt="" className="w-full h-full object-cover" />
        </div>
      ))}
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto pb-4">
      <div className="relative h-44">
        {profile.cover_url ? (
          <img src={profile.cover_url} alt="" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bix-gradient opacity-30" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
      </div>

      <div className="px-4 -mt-16 relative">
        <div className="flex items-end justify-between">
          <div className="relative">
            <img src={profile.avatar_url || defaultAvatar(profile.username)} alt="" className="w-28 h-28 rounded-full object-cover border-4 border-background" />
          </div>
          <div className="flex gap-2 mb-2">
            {isMe ? (
              <>
                <button onClick={() => setEditing(true)} className="px-5 py-2 rounded-full bix-gradient text-white text-sm font-semibold hover:scale-105 transition">
                  Edit Profile
                </button>
                <button onClick={() => navigate("/menu")} aria-label="Menu and settings" className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
                  <MenuIcon className="w-4 h-4 text-primary" />
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={handleFollow}
                  className={cn("px-5 py-2 rounded-full text-sm font-semibold transition", following ? "bg-secondary text-muted-foreground" : "bix-gradient text-white hover:scale-105")}
                >
                  {following ? "Following" : "Follow"}
                </button>
                {friendship?.status === "accepted" ? (
                  <span className="px-4 py-2 rounded-full bg-secondary text-sm font-semibold text-primary flex items-center gap-1">
                    <CheckCheck className="w-4 h-4" /> Friends
                  </span>
                ) : friendship?.status === "pending" ? (
                  <span className="px-4 py-2 rounded-full bg-secondary text-sm font-semibold text-muted-foreground flex items-center gap-1">
                    <Check className="w-4 h-4" /> Requested
                  </span>
                ) : (
                  <button onClick={handleFriend} className="px-4 py-2 rounded-full bg-secondary text-sm font-semibold hover:bg-secondary/80 transition flex items-center gap-1">
                    <UserPlus className="w-4 h-4 text-primary" /> Add Friend
                  </button>
                )}
                <button
                  onClick={handleMessage}
                  disabled={blocked}
                  title={blocked ? "Unblock to message" : "Message"}
                  className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center disabled:opacity-40"
                >
                  <MessageCircle className="w-4 h-4 text-primary" />
                </button>
                <button
                  onClick={async () => {
                    const blockedNow = await toggleBlock(profile.username).catch(() => blocked);
                    setBlocked(blockedNow);
                    toast({ title: blockedNow ? "User blocked" : "User unblocked" });
                  }}
                  className={cn("w-10 h-10 rounded-full flex items-center justify-center", blocked ? "bg-rose-500/20" : "bg-secondary")}
                >
                  <Ban className={cn("w-4 h-4", blocked ? "text-rose-400" : "text-muted-foreground")} />
                </button>
                <button onClick={() => setReportOpen(true)} className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
                  <Flag className="w-4 h-4 text-muted-foreground" />
                </button>
              </>
            )}
          </div>
        </div>

        <div className="mt-3">
          <div className="flex items-center gap-1">
            <h1 className="text-xl font-extrabold">{profile.full_name || profile.username}</h1>
            {verified && <BadgeCheck className="w-5 h-5 text-primary fill-primary/20" />}
            {profile.premium_plan && profile.premium_plan !== "none" && <Crown className="w-5 h-5 text-amber-400" />}
          </div>
          <p className="text-sm text-muted-foreground">{handle}</p>
          {profile.bio && <p className="text-sm mt-2 leading-relaxed">{profile.bio}</p>}
          {profile.location && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
              <MapPin className="w-3.5 h-3.5" /> {profile.location}
            </div>
          )}
        </div>

        <div className="flex gap-6 mt-3">
          {[["Posts", posts.length], ["Followers", profile.followers_count || 0], ["Following", profile.following_count || 0], ["Friends", profile.friends_count || 0]].map(([l, v]) => (
            <div key={l}>
              <div className="font-bold text-base">{formatCount(typeof v === "number" ? v : 0)}</div>
              <div className="text-xs text-muted-foreground">{l}</div>
            </div>
          ))}
        </div>

        <div className="flex gap-1 mt-4 border-b border-border overflow-x-auto no-scrollbar">
          {tabs.map(t => {
            const Icon = TAB_ICONS[t];
            return (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={cn(
                  "flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition",
                  tab === t ? "border-primary text-primary" : "border-transparent text-muted-foreground"
                )}
              >
                <Icon className="w-4 h-4" /> {t}
              </button>
            );
          })}
        </div>

        {tab === "Posts" && (
          <div className="mt-3">
            {posts.length === 0 ? (
              <div className="text-center py-10 text-sm text-muted-foreground">No posts yet</div>
            ) : posts.map((p, i) => <PostCard key={p.id || i} post={p} />)}
          </div>
        )}
        {tab === "Photos" && grid(photos, "image")}
        {tab === "Likes" && isMe && (
          <div className="mt-3">
            {likedPosts.length === 0 ? (
              <div className="text-center py-10 text-sm text-muted-foreground">No liked posts yet</div>
            ) : likedPosts.map((p, i) => <PostCard key={p.id || i} post={p} />)}
          </div>
        )}
        {tab === "Saved" && isMe && grid(savedPosts, "image")}
      </div>

      {editing && (
        <EditProfileSheet
          profile={profile}
          onClose={() => setEditing(false)}
          onSaved={load}
        />
      )}

      <ReportSheet
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        targetType="user"
        targetId={profile.username}
        targetLabel={profile.username}
      />
    </div>
  );
}