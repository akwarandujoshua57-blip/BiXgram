import React, { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Video, Search, SlidersHorizontal, X, Calendar } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getLiveStreams, getViewerCounts } from "@/lib/live";
import { getFollowedNames } from "@/lib/social";
import { getVerifiedNameSet } from "@/lib/channels";
import StreamCard from "@/components/live/StreamCard";
import WatchLive from "@/components/live/WatchLive";
import GoLiveSheet from "@/components/live/GoLiveSheet";
import { cn } from "@/lib/utils";
import moment from "moment";

const CATEGORIES = ["All", "Music", "Gaming", "Talk", "Sports", "Chill"];

export default function Live() {
  const [streams, setStreams] = useState([]);
  const [counts, setCounts] = useState({});
  const [followed, setFollowed] = useState([]);
  const [verified, setVerified] = useState(new Set());
  const [scheduled, setScheduled] = useState([]);
  const [cat, setCat] = useState("All");
  const [query, setQuery] = useState("");
  const [watching, setWatching] = useState(null);
  const [goLive, setGoLive] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const [live, names, v, sched] = await Promise.all([
      getLiveStreams(),
      getFollowedNames().catch(() => []),
      getVerifiedNameSet().catch(() => new Set()),
      base44.entities.LiveStream.filter({ status: "scheduled" }, "scheduled_for", 10).catch(() => []),
    ]);
    const tally = await getViewerCounts(live.map(s => s.id));
    setStreams(live.map(s => ({ ...s, viewers_count: tally[String(s.id)] || 0 })));
    setCounts(tally);
    setFollowed(names);
    setVerified(v);
    setScheduled(sched);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const visible = streams.filter(s => {
    const catOk = cat === "All" || s.category === cat.toLowerCase();
    const q = query.trim().toLowerCase();
    const qOk = !q || `${s.title} ${s.host_name}`.toLowerCase().includes(q);
    return catOk && qOk;
  });

  const fromFollowing = visible.filter(s => followed.includes(s.host_name));
  const others = visible.filter(s => !followed.includes(s.host_name));

  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/85 backdrop-blur-xl border-b border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <Video className="w-5 h-5 text-rose-500 shrink-0" />
          <h1 className="text-xl font-extrabold bix-gradient-text flex-1 min-w-0">Live</h1>
          <Link to="/live/studio" aria-label="Live Studio" className="w-9 h-9 rounded-full bg-secondary/60 flex items-center justify-center shrink-0">
            <SlidersHorizontal className="w-4 h-4" />
          </Link>
          <button onClick={() => setGoLive(true)} className="px-4 py-2 rounded-full bix-gradient text-white text-xs font-semibold bix-glow shrink-0 bix-press">
            Go Live
          </button>
        </div>
        <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2.5 mt-3">
          <Search className="w-[18px] h-[18px] text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search lives or creators"
            className="flex-1 min-w-0 bg-transparent outline-none text-sm"
          />
          {query && <button onClick={() => setQuery("")} aria-label="Clear"><X className="w-4 h-4 text-muted-foreground" /></button>}
        </div>
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar mt-2.5">
          {CATEGORIES.map(c => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={cn(
                "px-3 py-1.5 rounded-full text-xs font-medium shrink-0 border transition",
                cat === c ? "bix-gradient text-white border-transparent" : "border-border text-muted-foreground"
              )}
            >
              {c}
            </button>
          ))}
        </div>
      </header>

      <div className="p-3 pb-[calc(5rem+env(safe-area-inset-bottom))]">
        {loading ? (
          <div className="grid grid-cols-2 gap-3">
            {[0, 1, 2, 3].map(i => <div key={i} className="h-56 rounded-2xl bix-skeleton" />)}
          </div>
        ) : streams.length === 0 ? (
          <div className="text-center py-16 px-6">
            <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
              <Video className="w-6 h-6 text-muted-foreground" />
            </div>
            <p className="font-semibold text-sm">No live streams right now</p>
            <p className="text-xs text-muted-foreground mt-1">When someone goes live, they'll appear here.</p>
            <button onClick={() => setGoLive(true)} className="mt-4 px-5 py-2.5 rounded-full bix-gradient text-white text-sm font-semibold bix-press">
              Go Live
            </button>
          </div>
        ) : (
          <>
            {fromFollowing.length > 0 && (
              <>
                <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2 px-1">Following</h2>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  {fromFollowing.map(s => (
                    <StreamCard key={s.id} stream={s} verified={verified.has(s.host_name)} onSelect={setWatching} />
                  ))}
                </div>
              </>
            )}
            <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2 px-1">
              {fromFollowing.length ? "Live now" : "Live now"}
            </h2>
            {others.length === 0 ? (
              <p className="text-xs text-muted-foreground px-1 py-6">No other live streams match this filter.</p>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {others.map(s => (
                  <StreamCard key={s.id} stream={s} verified={verified.has(s.host_name)} onSelect={setWatching} />
                ))}
              </div>
            )}
          </>
        )}

        {scheduled.length > 0 && (
          <div className="mt-6">
            <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2 px-1">Scheduled</h2>
            <div className="space-y-2">
              {scheduled.map(s => (
                <div key={s.id} className="bix-card p-3 flex items-center gap-3">
                  <img src={s.host_avatar} alt="" className="w-9 h-9 rounded-full object-cover shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-semibold truncate">{s.title}</div>
                    <div className="text-[11px] text-muted-foreground truncate">{s.host_name}</div>
                  </div>
                  <span className="text-[10px] text-sky-300 flex items-center gap-1 shrink-0">
                    <Calendar className="w-3 h-3" /> {s.scheduled_for ? moment(s.scheduled_for).format("D MMM, HH:mm") : "Soon"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <GoLiveSheet
        open={goLive}
        onClose={() => setGoLive(false)}
        onCreated={(created, isScheduled) => {
          if (isScheduled) setScheduled(s => [created, ...s]);
          else setWatching(created);
        }}
      />

      {watching && (
        <WatchLive
          stream={watching}
          onClose={() => setWatching(null)}
          onEnded={() => load()}
        />
      )}
    </div>
  );
}