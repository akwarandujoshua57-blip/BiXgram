import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Users, MessageSquare, ArrowLeft, UsersRound, Shield } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { formatCount } from "@/lib/bixgram-data";
import { getMe } from "@/lib/social";
import { WORLD_ICONS } from "@/lib/world-icons";
import { cn } from "@/lib/utils";
import PostComposer from "@/components/feed/PostComposer";
import PostCard from "@/components/feed/PostCard";

export default function CommunityDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [community, setCommunity] = useState(null);
  const [posts, setPosts] = useState([]);
  const [joined, setJoined] = useState(false);
  const [notFound, setNotFound] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const c = await base44.entities.World.get(id);
      setCommunity(c);
      const me = await getMe();
      const memberships = await base44.entities.WorldMembership.filter({ world_id: id, user_name: me.name });
      setJoined(memberships.length > 0);
      setPosts(await base44.entities.Post.filter({ world_id: id }, "-created_date", 50));
    } catch {
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [id]);

  const toggleJoin = async () => {
    const me = await getMe();
    if (joined) {
      await base44.entities.WorldMembership.deleteMany({ world_id: id, user_name: me.name });
      await base44.entities.World.updateMany({ id }, { $inc: { members_count: -1 } });
      setJoined(false);
      setCommunity(c => ({ ...c, members_count: Math.max(0, (c.members_count || 0) - 1) }));
    } else {
      await base44.entities.WorldMembership.create({ world_id: id, world_name: community.name, user_name: me.name });
      await base44.entities.World.updateMany({ id }, { $inc: { members_count: 1 } });
      setJoined(true);
      setCommunity(c => ({ ...c, members_count: (c.members_count || 0) + 1 }));
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-24">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (notFound || !community) {
    return (
      <div className="max-w-2xl mx-auto text-center py-24 px-4">
        <UsersRound className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
        <p className="text-muted-foreground">This community doesn't exist.</p>
        <button onClick={() => navigate("/communities")} className="mt-4 px-5 py-2 rounded-full bix-gradient text-white text-sm font-semibold">
          Browse Communities
        </button>
      </div>
    );
  }

  const Icon = WORLD_ICONS[community.icon] || UsersRound;

  return (
    <div className="max-w-2xl mx-auto pb-[calc(5rem+env(safe-area-inset-bottom))]">
      <div className="relative h-40">
        {community.cover_url && <img src={community.cover_url} alt="" className="w-full h-full object-cover" />}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
        <button onClick={() => navigate("/communities")} aria-label="Back" className="absolute top-3 left-3 w-9 h-9 rounded-full bg-black/40 backdrop-blur flex items-center justify-center">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
      </div>

      <div className="px-4 -mt-12 relative">
        <div className="flex items-end justify-between gap-3">
          <div className={cn("w-16 h-16 rounded-2xl bg-gradient-to-br flex items-center justify-center shadow-lg border-4 border-background shrink-0", community.color)}>
            <Icon className="w-8 h-8 text-white" />
          </div>
          <button
            onClick={toggleJoin}
            className={cn(
              "mb-2 px-6 py-2 rounded-full text-sm font-semibold transition shrink-0",
              joined ? "bg-secondary text-muted-foreground" : "bix-gradient text-white"
            )}
          >
            {joined ? "Joined" : "Join"}
          </button>
        </div>

        <h1 className="text-xl font-extrabold mt-3 break-words">{community.name}</h1>
        {community.category && (
          <span className="inline-block mt-1 px-2 py-0.5 rounded-full bg-secondary/60 text-[10px] font-medium text-muted-foreground">
            {community.category}
          </span>
        )}
        {community.description && (
          <p className="text-sm text-muted-foreground mt-2 whitespace-pre-wrap">{community.description}</p>
        )}
        <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2">
          <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> {formatCount(community.members_count || 0)} members</span>
          <span className="flex items-center gap-1"><MessageSquare className="w-3.5 h-3.5" /> {formatCount(community.posts_count || 0)} posts</span>
        </div>

        <div className="flex items-start gap-2 mt-3 p-3 rounded-xl bg-secondary/40">
          <Shield className="w-4 h-4 text-primary shrink-0 mt-0.5" />
          <p className="text-[11px] text-muted-foreground">
            Community moderators can remove posts and remove members. Reports go to Bixgram for review.
          </p>
        </div>

        <div className="mt-4">
          <PostComposer world={{ id, name: community.name }} onPosted={load} />
        </div>

        <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground mt-4 mb-1 px-1">Discussion</h2>
        {posts.length === 0 ? (
          <div className="text-center py-12 px-6">
            <p className="font-semibold text-sm">No posts yet</p>
            <p className="text-xs text-muted-foreground mt-1">Start the first conversation in this community.</p>
          </div>
        ) : (
          posts.map(p => <PostCard key={p.id} post={p} />)
        )}
      </div>
    </div>
  );
}