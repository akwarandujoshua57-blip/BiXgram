import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { TrendingUp, Flame, Sparkles, ArrowLeft } from "lucide-react";
import { base44 } from "@/api/base44Client";
import PostCard from "@/components/feed/PostCard";
import { formatCount } from "@/lib/bixgram-data";
import { getVerifiedNameSet } from "@/lib/channels";
import { getMe } from "@/lib/social";
import { cn } from "@/lib/utils";

const TABS = ["Trending", "Popular Words", "Suggested for You"];

// Every figure here is computed from real stored posts and profiles — nothing
// is seeded or estimated.
export default function Trending() {
  const [tab, setTab] = useState("Trending");
  const [posts, setPosts] = useState([]);
  const [profiles, setProfiles] = useState([]);
  const [verified, setVerified] = useState(new Set());
  const [me, setMe] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [p, profs, v, m] = await Promise.all([
        base44.entities.Post.list("-created_date", 100).catch(() => []),
        base44.entities.Profile.list(100).catch(() => []),
        getVerifiedNameSet().catch(() => new Set()),
        getMe().catch(() => null),
      ]);
      setPosts(p);
      setProfiles(profs);
      setVerified(v);
      setMe(m);
      setLoading(false);
    })();
  }, []);

  const ranked = useMemo(
    () => [...posts].sort((a, b) => ((b.likes_count || 0) + (b.comments_count || 0) * 2) - ((a.likes_count || 0) + (a.comments_count || 0) * 2)).slice(0, 20),
    [posts]
  );

  const words = useMemo(() => {
    const counts = {};
    for (const post of posts) {
      for (const tag of String(post.text || "").match(/#[\w]+/g) || []) {
        const k = tag.toLowerCase();
        counts[k] = (counts[k] || 0) + 1;
      }
    }
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 24);
  }, [posts]);

  const suggested = useMemo(
    () => profiles
      .filter(p => p.username && p.username !== me?.name)
      .sort((a, b) => (b.followers_count || 0) - (a.followers_count || 0))
      .slice(0, 20),
    [profiles, me]
  );

  return (
    <div className="max-w-2xl mx-auto pb-6">
      <header className="sticky top-0 z-40 bg-background/85 backdrop-blur-xl border-b border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <Link to="/menu" aria-label="Back" className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-secondary/60 shrink-0">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-extrabold bix-gradient-text flex-1 min-w-0">Trending</h1>
        </div>
        <div className="flex gap-1 mt-3 overflow-x-auto no-scrollbar">
          {TABS.map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition",
                tab === t ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground"
              )}
            >
              {t}
            </button>
          ))}
        </div>
      </header>

      <div className="p-3 space-y-2">
        {loading ? (
          [0, 1, 2].map(i => <div key={i} className="h-32 rounded-2xl bix-skeleton" />)
        ) : tab === "Trending" ? (
          ranked.length === 0 ? (
            <Empty icon={TrendingUp} title="No activity yet" body="Posts that people engage with will appear here." />
          ) : (
            ranked.map(p => <PostCard key={p.id} post={p} />)
          )
        ) : tab === "Popular Words" ? (
          words.length === 0 ? (
            <Empty icon={Flame} title="No popular words yet" body="Hashtags used in real posts show up here." />
          ) : (
            <div className="flex flex-wrap gap-2">
              {words.map(([tag, count]) => (
                <Link key={tag} to={`/search?q=${encodeURIComponent(tag.replace("#", ""))}`} className="bix-card px-3 py-2 bix-press">
                  <span className="text-sm font-semibold bix-gradient-text">{tag}</span>
                  <span className="text-[10px] text-muted-foreground ml-1.5">{formatCount(count)}</span>
                </Link>
              ))}
            </div>
          )
        ) : suggested.length === 0 ? (
          <Empty icon={Sparkles} title="No suggestions yet" body="Accounts with activity will be suggested here." />
        ) : (
          suggested.map(p => (
            <Link key={p.id} to={`/profile/${encodeURIComponent(p.username)}`} className="bix-card p-3 flex items-center gap-3 bix-press">
              <img src={p.avatar_url} alt="" className="w-11 h-11 rounded-full object-cover shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="font-semibold text-sm truncate">
                  {p.full_name || p.username}
                  {verified.has(p.username) && <span className="text-primary ml-1">✓</span>}
                </div>
                <div className="text-xs text-muted-foreground truncate">@{p.username} · {formatCount(p.followers_count || 0)} followers</div>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}

function Empty({ icon: Icon, title, body }) {
  return (
    <div className="text-center py-16 px-6">
      <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
        <Icon className="w-6 h-6 text-muted-foreground" />
      </div>
      <p className="font-semibold text-sm">{title}</p>
      <p className="text-xs text-muted-foreground mt-1">{body}</p>
    </div>
  );
}