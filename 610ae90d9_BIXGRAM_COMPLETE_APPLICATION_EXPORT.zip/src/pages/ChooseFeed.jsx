import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Check, SlidersHorizontal, Film, Trophy, Music, Gamepad2, Briefcase, GraduationCap, Laugh, Cpu, MapPin } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { WORLD_CATEGORIES, FEED_FILTERS } from "@/lib/bixgram-data";
import { cn } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";

const ICONS = { Film, Trophy, Music, Gamepad2, Briefcase, GraduationCap, Laugh, Cpu, MapPin };

export default function ChooseFeed() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [interests, setInterests] = useState([]);
  const [feedTypes, setFeedTypes] = useState(["For You"]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        if (me?.bix_interests) setInterests(me.bix_interests);
        if (me?.bix_feed_types) setFeedTypes(me.bix_feed_types);
      } catch { /* stay with defaults */ }
    })();
  }, []);

  const toggle = (list, setList, value) =>
    setList(list.includes(value) ? list.filter(v => v !== value) : [...list, value]);

  const save = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe({ bix_interests: interests, bix_feed_types: feedTypes });
      toast({ title: "Your feed is set! ✨" });
      navigate("/");
    } catch {
      toast({ title: "Couldn't save preferences", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border px-4 py-3 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bix-gradient flex items-center justify-center">
          <SlidersHorizontal className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-extrabold bix-gradient-text leading-tight">Choose Your Feed</h1>
          <p className="text-[11px] text-muted-foreground">Personalize what you see on BIXGRAM</p>
        </div>
      </header>

      <div className="p-4 space-y-6">
        <section>
          <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">Pick your interests</h2>
          <div className="grid grid-cols-3 gap-2.5">
            {WORLD_CATEGORIES.map(cat => {
              const selected = interests.includes(cat.name);
              const Icon = ICONS[cat.icon] || Film;
              return (
                <button
                  key={cat.name}
                  onClick={() => toggle(interests, setInterests, cat.name)}
                  className={cn(
                    "relative rounded-2xl p-3 bg-gradient-to-br text-left transition",
                    cat.color,
                    selected ? "ring-2 ring-primary ring-offset-2 ring-offset-background scale-[1.03]" : "opacity-70 hover:opacity-100"
                  )}
                >
                  <Icon className="w-6 h-6 text-white" />
                  <div className="text-white text-xs font-bold mt-1.5">{cat.name}</div>
                  {selected && (
                    <span className="absolute top-2 right-2 w-5 h-5 rounded-full bg-white flex items-center justify-center">
                      <Check className="w-3 h-3 text-emerald-600" strokeWidth={3} />
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </section>

        <section>
          <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">Feed types you want first</h2>
          <div className="flex flex-wrap gap-2">
            {FEED_FILTERS.map(f => (
              <button
                key={f}
                onClick={() => toggle(feedTypes, setFeedTypes, f)}
                className={cn(
                  "px-4 py-2 rounded-full text-sm font-semibold transition",
                  feedTypes.includes(f) ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground"
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </section>

        <p className="text-xs text-muted-foreground">You can change this anytime from the Menu.</p>

        <button
          onClick={save}
          disabled={saving}
          className="w-full py-3 rounded-xl bix-gradient text-white font-semibold disabled:opacity-40"
        >
          {saving ? "Saving…" : "Save My Feed"}
        </button>
      </div>
    </div>
  );
}