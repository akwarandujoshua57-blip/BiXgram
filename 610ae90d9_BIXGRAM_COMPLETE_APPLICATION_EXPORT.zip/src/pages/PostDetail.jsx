import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Search } from "lucide-react";
import { base44 } from "@/api/base44Client";
import PostCard from "@/components/feed/PostCard";
import PostSkeleton from "@/components/feed/PostSkeleton";

export default function PostDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [state, setState] = useState("loading");

  useEffect(() => {
    (async () => {
      try {
        const p = await base44.entities.Post.get(id);
        if (!p) { setState("missing"); return; }
        setPost(p);
        setState("ready");
      } catch {
        setState("missing");
      }
    })();
  }, [id]);

  return (
    <div className="max-w-2xl mx-auto pb-6">
      <header className="sticky top-0 z-40 bg-background/85 backdrop-blur-xl border-b border-border">
        <div className="h-16 flex items-center gap-2 px-3 max-w-2xl mx-auto">
          <button onClick={() => navigate(-1)} aria-label="Go back" className="bix-icon-btn">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-bold text-base">Post</h1>
          <button onClick={() => navigate("/search")} aria-label="Search" className="bix-icon-btn ml-auto">
            <Search className="w-5 h-5" />
          </button>
        </div>
      </header>

      {state === "loading" && <PostSkeleton />}

      {state === "missing" && (
        <div className="text-center py-20 px-6">
          <p className="text-sm font-semibold">This post isn't available</p>
          <p className="text-xs text-muted-foreground mt-1">It may have been deleted or the link is incorrect.</p>
          <button onClick={() => navigate("/")} className="mt-4 px-5 py-2 rounded-full bix-gradient text-white text-sm font-semibold">
            Back to Home
          </button>
        </div>
      )}

      {state === "ready" && post && <PostCard post={post} />}
    </div>
  );
}