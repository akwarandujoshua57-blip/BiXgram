import React, { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ArrowLeft, BadgeCheck, Users, Check, Plus, Share2, Flag, Loader2,
  Image as ImageIcon, Video, Megaphone, Trash2, X, ArrowUp, MoreVertical,
  Pencil, Bell, BellOff, BellRing,
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getMe, uploadFile } from "@/lib/social";
import {
  isSubscribed, toggleChannelSubscription, isUserVerified, reportChannel,
  notifyChannelSubscribers, setNotifyLevel,
} from "@/lib/channels";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";
import { formatCount } from "@/lib/bixgram-data";
import MonetizationSection from "@/components/channels/MonetizationSection";
import ChannelSubscribers from "@/components/channels/ChannelSubscribers";
import ChannelShareSheet from "@/components/channels/ChannelShareSheet";
import ChannelEditSheet from "@/components/channels/ChannelEditSheet";
import ChannelAnalytics from "@/components/channels/ChannelAnalytics";
import ChannelAbout from "@/components/channels/ChannelAbout";
import ChannelTabs from "@/components/channels/ChannelTabs";
import ChannelPostCard from "@/components/channels/ChannelPostCard";

const PAGE = 10;

const NOTIFY_OPTIONS = [
  { key: "all", label: "All updates", icon: BellRing },
  { key: "important", label: "Important only", icon: Bell },
  { key: "muted", label: "Off", icon: BellOff },
];

export default function ChannelProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [channel, setChannel] = useState(null);
  const [me, setMe] = useState(null);
  const [verified, setVerified] = useState(false);
  const [subscribed, setSubscribed] = useState(false);
  const [notifyLevel, setNotifyLevelState] = useState("all");
  const [posts, setPosts] = useState([]);
  const [limit, setLimit] = useState(PAGE);
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);
  const [tab, setTab] = useState("posts");
  const [composing, setComposing] = useState(false);
  const [draft, setDraft] = useState({ text: "", photos: [], video: null, link: "", announcement: false });
  const [posting, setPosting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showTop, setShowTop] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifyOpen, setNotifyOpen] = useState(false);

  const photoRef = useRef(null);
  const videoRef = useRef(null);

  const isOwner = !!(me && channel && (channel.owner_id === me.id || channel.created_by_id === me.id));

  const load = useCallback(async () => {
    try {
      const c = await base44.entities.Channel.get(id);
      setChannel(c);
      // Verification belongs to the owner's account, not to the channel itself.
      setVerified(await isUserVerified(c.owner_name));
    } catch {
      setMissing(true);
    }
  }, [id]);

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      try {
        const m = await getMe();
        if (!alive) return;
        setMe(m);
        await load();
      } catch {
        if (alive) setMissing(true);
      }
      if (alive) setLoading(false);
    })();
    return () => { alive = false; };
  }, [load]);

  // Subscription + notification preference are read from this account's own
  // subscriber record — the rules on the table only expose a user's own row.
  useEffect(() => {
    let alive = true;
    (async () => {
      if (!channel || !me) return;
      const sub = await isSubscribed(channel.id);
      if (!alive) return;
      setSubscribed(sub);
      if (sub) {
        const rows = await base44.entities.ChannelSubscriber
          .filter({ channel_id: String(channel.id) }, "-created_date", 5)
          .catch(() => []);
        if (alive && rows[0]) setNotifyLevelState(rows[0].notify_level || "all");
      }
    })();
    return () => { alive = false; };
  }, [channel?.id, me?.id]);

  // Channel updates load a page at a time, newest first.
  const loadPosts = useCallback(async () => {
    if (!channel) return;
    const rows = await base44.entities.ChannelPost
      .filter({ channel_id: String(channel.id) }, "-created_date", limit)
      .catch(() => []);
    setPosts([...rows].reverse());
  }, [channel, limit]);

  useEffect(() => { loadPosts(); }, [loadPosts]);

  // The page scrolls with the window so the app's scroll-aware navigation
  // behaves here exactly as it does everywhere else.
  useEffect(() => {
    const onScroll = () => {
      setShowTop(window.scrollY > 400);
      if (window.scrollY < 120 && posts.length >= limit) setLimit(l => l + PAGE);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [posts.length, limit]);

  const subscribe = async () => {
    try {
      const now = await toggleChannelSubscription(channel);
      setSubscribed(now);
      setChannel(c => ({ ...c, subscribers_count: Math.max(0, (c.subscribers_count || 0) + (now ? 1 : -1)) }));
      if (now) setNotifyLevelState("all");
    } catch {
      toast({ title: "Couldn't update your subscription. Please try again.", variant: "destructive" });
    }
  };

  const chooseNotify = async (level) => {
    setNotifyOpen(false);
    setNotifyLevelState(level);
    await setNotifyLevel(channel.id, level).catch(() => {});
    toast({ title: `Channel notifications: ${NOTIFY_OPTIONS.find(o => o.key === level)?.label}` });
  };

  const pick = async (e, kind) => {
    const files = Array.from(e.target.files || []);
    e.target.value = "";
    if (!files.length) return;
    setUploading(true);
    try {
      for (const file of files) {
        const url = await uploadFile(file);
        if (kind === "photo") setDraft(d => ({ ...d, photos: [...d.photos, url].slice(0, 4) }));
        else setDraft(d => ({ ...d, video: url }));
      }
    } catch {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const publish = async () => {
    if (!draft.text.trim() && draft.photos.length === 0 && !draft.video && !draft.link.trim()) return;
    setPosting(true);
    try {
      const created = await base44.entities.ChannelPost.create({
        channel_id: String(channel.id),
        channel_name: channel.name,
        owner_id: me.id,
        author_name: me.name,
        author_avatar: channel.avatar_url,
        text: draft.text.trim(),
        media_urls: draft.photos.length ? draft.photos : undefined,
        video_url: draft.video || undefined,
        link_url: draft.link.trim() || undefined,
        is_announcement: draft.announcement,
        visibility: channel.privacy === "private" ? "private" : "public",
        likes_count: 0,
        comments_count: 0,
        views_count: 0,
      });
      await base44.entities.Channel.updateMany({ id: channel.id }, { $inc: { content_count: 1 } }).catch(() => {});
      setChannel(c => ({ ...c, content_count: (c.content_count || 0) + 1 }));
      setPosts(p => [...p, created]);
      setDraft({ text: "", photos: [], video: null, link: "", announcement: false });
      setComposing(false);
      // Subscribers are notified only for a real published update, and only
      // those who haven't turned channel notifications off.
      notifyChannelSubscribers(channel, created);
      toast({ title: "Update published" });
    } catch {
      toast({ title: "Couldn't publish that update. Please try again.", variant: "destructive" });
    } finally {
      setPosting(false);
    }
  };

  const removePost = async (p) => {
    await base44.entities.ChannelPost.delete(p.id).catch(() => {});
    setPosts(list => list.filter(x => x.id !== p.id));
    await base44.entities.Channel.updateMany(
      { id: channel.id, content_count: { $gt: 0 } },
      { $inc: { content_count: -1 } }
    ).catch(() => {});
    setChannel(c => ({ ...c, content_count: Math.max(0, (c.content_count || 0) - 1) }));
  };

  const report = async () => {
    setMenuOpen(false);
    await reportChannel({ channel, reason: "other", details: "Reported from channel profile" });
    toast({ title: "Report submitted", description: "Our team will review this." });
  };

  if (loading) {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-3">
        <div className="h-32 rounded-2xl bix-skeleton" />
        <div className="h-24 rounded-2xl bix-skeleton" />
        <div className="h-40 rounded-2xl bix-skeleton" />
      </div>
    );
  }

  if (missing || !channel) {
    return (
      <div className="max-w-2xl mx-auto text-center py-20 px-6">
        <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
          <Users className="w-6 h-6 text-muted-foreground" />
        </div>
        <p className="font-semibold">This Channel is unavailable.</p>
        <p className="text-xs text-muted-foreground mt-1">It may have been removed, or you don't have access.</p>
        <button onClick={() => navigate("/channels")} className="mt-4 px-5 py-2.5 rounded-full bix-gradient text-white text-sm font-semibold bix-press">
          Browse channels
        </button>
      </div>
    );
  }

  const postList = posts.filter(p => !p.video_url);
  const videoList = posts.filter(p => !!p.video_url);
  const mediaList = posts.filter(p => p.media_urls?.length > 0);

  const TABS = [
    { key: "posts", label: "Posts", count: postList.length },
    { key: "videos", label: "Videos", count: videoList.length },
    { key: "media", label: "Media", count: mediaList.length },
    { key: "about", label: "About" },
  ];

  const shown = tab === "videos" ? videoList : tab === "media" ? mediaList : postList;
  const emptyCopy = {
    posts: ["No posts yet", "Updates from this channel will appear here."],
    videos: ["No videos yet", "Videos shared by this channel will appear here."],
    media: ["No media yet", "Photos shared by this channel will appear here."],
  }[tab];

  return (
    <div className="max-w-2xl mx-auto min-h-screen pb-[calc(5rem+env(safe-area-inset-bottom))]">
      {/* COVER */}
      <div className="relative">
        {channel.cover_url ? (
          <img src={channel.cover_url} alt="" className="w-full h-32 object-cover" />
        ) : (
          <div className="w-full h-32 bix-gradient opacity-70" />
        )}
        <button
          onClick={() => navigate(-1)}
          aria-label="Back"
          className="absolute top-3 left-3 w-9 h-9 rounded-full bg-black/50 backdrop-blur flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <button
          onClick={() => setMenuOpen(o => !o)}
          aria-label="Channel options"
          className="absolute top-3 right-3 w-9 h-9 rounded-full bg-black/50 backdrop-blur flex items-center justify-center"
        >
          <MoreVertical className="w-5 h-5 text-white" />
        </button>

        {menuOpen && (
          <div className="absolute top-14 right-3 z-40 w-52 bix-card overflow-hidden">
            {isOwner ? (
              <button
                onClick={() => { setMenuOpen(false); setEditOpen(true); }}
                className="w-full flex items-center gap-2.5 px-3.5 py-3 text-sm hover:bg-secondary/60"
              >
                <Pencil className="w-4 h-4 text-primary" /> Edit channel
              </button>
            ) : (
              <button onClick={report} className="w-full flex items-center gap-2.5 px-3.5 py-3 text-sm hover:bg-secondary/60">
                <Flag className="w-4 h-4 text-muted-foreground" /> Report channel
              </button>
            )}
            <button
              onClick={() => { setMenuOpen(false); setShareOpen(true); }}
              className="w-full flex items-center gap-2.5 px-3.5 py-3 text-sm hover:bg-secondary/60 border-t border-border"
            >
              <Share2 className="w-4 h-4 text-muted-foreground" /> Share channel
            </button>
          </div>
        )}
      </div>

      {/* HERO */}
      <div className="px-4 -mt-8">
        {channel.avatar_url ? (
          <img src={channel.avatar_url} alt={`${channel.name} profile image`} className="w-20 h-20 rounded-2xl object-cover border-4 border-background" />
        ) : (
          <div className="w-20 h-20 rounded-2xl bix-gradient flex items-center justify-center border-4 border-background text-white text-2xl font-bold">
            {String(channel.name).charAt(0).toUpperCase()}
          </div>
        )}

        <div className="flex items-center gap-1.5 mt-2 min-w-0">
          <h1 className="text-lg font-extrabold truncate">{channel.name}</h1>
          {verified && <BadgeCheck className="w-4 h-4 text-primary shrink-0" aria-label="Verified channel" />}
        </div>
        <p className="text-xs text-muted-foreground truncate">@{channel.username}</p>

        <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground flex-wrap">
          <span className="flex items-center gap-1">
            <Users className="w-3.5 h-3.5 shrink-0" />
            {formatCount(channel.subscribers_count || 0)} subscribers
          </span>
          <span>{formatCount(channel.content_count || 0)} updates</span>
          {channel.category && <span className="px-2 py-0.5 rounded-full bg-secondary/60">{channel.category}</span>}
        </div>

        {channel.description && <p className="text-sm mt-3 break-words">{channel.description}</p>}

        <div className="flex items-center gap-2 mt-4">
          {isOwner ? (
            <div className="flex-1 min-w-0 py-2.5 rounded-full bg-secondary/60 text-center text-xs font-semibold text-muted-foreground truncate px-2">
              You own this channel
            </div>
          ) : (
            <button
              onClick={subscribe}
              className={cn(
                "flex-1 min-w-0 py-2.5 rounded-full text-sm font-semibold flex items-center justify-center gap-1.5 bix-press",
                subscribed ? "bg-secondary text-muted-foreground" : "bix-gradient text-white bix-glow"
              )}
            >
              {subscribed ? <><Check className="w-4 h-4" /> Subscribed</> : <><Plus className="w-4 h-4" /> Subscribe</>}
            </button>
          )}

          {subscribed && !isOwner && (
            <div className="relative shrink-0">
              <button
                onClick={() => setNotifyOpen(o => !o)}
                aria-label="Channel notifications"
                className="w-10 h-10 rounded-full bg-secondary/60 flex items-center justify-center"
              >
                {notifyLevel === "muted"
                  ? <BellOff className="w-4 h-4 text-muted-foreground" />
                  : notifyLevel === "important"
                    ? <Bell className="w-4 h-4 text-primary" />
                    : <BellRing className="w-4 h-4 text-primary" />}
              </button>
              {notifyOpen && (
                <div className="absolute right-0 top-12 z-40 w-48 bix-card overflow-hidden">
                  {NOTIFY_OPTIONS.map(o => (
                    <button
                      key={o.key}
                      onClick={() => chooseNotify(o.key)}
                      className={cn(
                        "w-full flex items-center gap-2.5 px-3.5 py-2.5 text-xs hover:bg-secondary/60 border-b border-border last:border-0",
                        notifyLevel === o.key && "text-primary font-semibold"
                      )}
                    >
                      <o.icon className="w-3.5 h-3.5 shrink-0" /> {o.label}
                      {notifyLevel === o.key && <Check className="w-3.5 h-3.5 ml-auto shrink-0" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          <button onClick={() => setShareOpen(true)} aria-label="Share channel" className="w-10 h-10 rounded-full bg-secondary/60 flex items-center justify-center shrink-0">
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* OWNER TOOLS */}
      {isOwner && (
        <div className="px-4 mt-4 space-y-3">
          <button
            onClick={() => setComposing(v => !v)}
            className="w-full flex items-center gap-3 p-3 rounded-2xl bix-card text-left bix-press"
          >
            <div className="w-10 h-10 rounded-full bix-gradient flex items-center justify-center shrink-0">
              <Plus className="w-5 h-5 text-white" />
            </div>
            <span className="text-sm font-medium text-muted-foreground min-w-0 truncate">Share an update with your subscribers</span>
          </button>

          <button
            onClick={() => setEditOpen(true)}
            className="w-full flex items-center gap-3 p-3 rounded-2xl bix-card text-left bix-press"
          >
            <div className="w-10 h-10 rounded-full bg-secondary/70 flex items-center justify-center shrink-0">
              <Pencil className="w-4 h-4 text-primary" />
            </div>
            <span className="text-sm font-medium text-muted-foreground min-w-0 truncate">Edit channel details</span>
          </button>

          <ChannelAnalytics channel={channel} />
          <ChannelSubscribers channelId={channel.id} />
          <MonetizationSection channel={channel} isOwner={isOwner} />
        </div>
      )}

      {/* COMPOSER */}
      {isOwner && composing && (
        <div className="mx-4 mt-3 bix-card p-3">
          <textarea
            value={draft.text}
            onChange={e => setDraft(d => ({ ...d, text: e.target.value }))}
            rows={3}
            placeholder="What's new?"
            className="w-full bg-secondary/40 rounded-2xl px-3.5 py-2.5 resize-none outline-none text-sm focus:ring-1 focus:ring-primary/40"
          />
          {draft.photos.length > 0 && (
            <div className="grid grid-cols-2 gap-1.5 mt-2">
              {draft.photos.map((u, i) => (
                <div key={i} className="relative rounded-xl overflow-hidden">
                  <img src={u} alt="" className="w-full h-24 object-cover" />
                  <button
                    onClick={() => setDraft(d => ({ ...d, photos: d.photos.filter(x => x !== u) }))}
                    aria-label="Remove photo"
                    className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/60 flex items-center justify-center"
                  >
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ))}
            </div>
          )}
          {draft.video && (
            <div className="relative mt-2">
              <video src={draft.video} controls playsInline className="w-full max-h-56 rounded-xl bg-black" />
              <button onClick={() => setDraft(d => ({ ...d, video: null }))} aria-label="Remove video" className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60 flex items-center justify-center">
                <X className="w-3.5 h-3.5 text-white" />
              </button>
            </div>
          )}
          <input
            value={draft.link}
            onChange={e => setDraft(d => ({ ...d, link: e.target.value }))}
            placeholder="Add a link (optional)"
            className="w-full bg-secondary/40 rounded-xl px-3.5 py-2.5 outline-none text-sm mt-2"
          />
          <div className="flex items-center gap-1 mt-2 overflow-x-auto no-scrollbar">
            <button onClick={() => photoRef.current?.click()} className="flex items-center gap-1.5 px-2.5 py-2 rounded-lg hover:bg-secondary text-xs font-medium text-emerald-400 shrink-0">
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />} Photo
            </button>
            <button onClick={() => videoRef.current?.click()} className="flex items-center gap-1.5 px-2.5 py-2 rounded-lg hover:bg-secondary text-xs font-medium text-purple-400 shrink-0">
              <Video className="w-4 h-4" /> Video
            </button>
            <button
              onClick={() => setDraft(d => ({ ...d, announcement: !d.announcement }))}
              className={cn("flex items-center gap-1.5 px-2.5 py-2 rounded-lg text-xs font-medium shrink-0",
                draft.announcement ? "bix-gradient text-white" : "hover:bg-secondary text-amber-400")}
            >
              <Megaphone className="w-4 h-4" /> Announcement
            </button>
          </div>
          <button
            onClick={publish}
            disabled={posting || uploading}
            className="w-full mt-3 py-2.5 rounded-full bix-gradient text-white text-sm font-semibold disabled:opacity-40 bix-press"
          >
            {posting ? "Publishing…" : "Publish update"}
          </button>
        </div>
      )}

      {/* TABS + CONTENT */}
      <div className="mt-5">
        <ChannelTabs tabs={TABS} value={tab} onChange={setTab} />

        {tab === "about" ? (
          <ChannelAbout channel={channel} />
        ) : shown.length === 0 ? (
          <div className="text-center py-12 px-6">
            <div className="w-12 h-12 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
              {tab === "videos" ? <Video className="w-5 h-5 text-muted-foreground" /> : <Users className="w-5 h-5 text-muted-foreground" />}
            </div>
            <p className="font-semibold text-sm">{emptyCopy[0]}</p>
            <p className="text-xs text-muted-foreground mt-1">{emptyCopy[1]}</p>
            {isOwner && tab === "posts" && (
              <button
                onClick={() => { setComposing(true); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                className="mt-4 px-5 py-2.5 rounded-full bix-gradient text-white text-sm font-semibold bix-press"
              >
                Create your first post
              </button>
            )}
          </div>
        ) : (
          <div className="px-4 mt-3 space-y-3">
            {shown.map(p => (
              <ChannelPostCard
                key={p.id}
                post={p}
                channel={channel}
                verified={verified}
                isOwner={isOwner}
                onDelete={removePost}
              />
            ))}
          </div>
        )}
      </div>

      {showTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="Back to top"
          className="fixed bottom-24 right-4 w-10 h-10 rounded-full bix-gradient flex items-center justify-center bix-glow z-30"
        >
          <ArrowUp className="w-4 h-4 text-white" />
        </button>
      )}

      <ChannelShareSheet open={shareOpen} onClose={() => setShareOpen(false)} channel={channel} />
      <ChannelEditSheet
        open={editOpen}
        onClose={() => setEditOpen(false)}
        channel={channel}
        onSaved={load}
      />

      <input ref={photoRef} type="file" accept="image/*" multiple hidden onChange={e => pick(e, "photo")} />
      <input ref={videoRef} type="file" accept="video/*" hidden onChange={e => pick(e, "video")} />
    </div>
  );
}