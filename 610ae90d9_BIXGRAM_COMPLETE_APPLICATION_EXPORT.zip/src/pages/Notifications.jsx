import React, { useEffect, useState } from "react";
import { Heart, MessageCircle, UserPlus, AtSign, Share2, Radio, Globe2, ShoppingBag, Bell, Check, CheckCheck, X, Users, Crown } from "lucide-react";
import moment from "moment";
import { base44 } from "@/api/base44Client";
import { getMe, acceptFriendRequest, declineFriendRequest } from "@/lib/social";
import { cn } from "@/lib/utils";

const typeMap = {
  like: { icon: Heart, color: "text-rose-500", bg: "bg-rose-500/10", verb: "liked your post" },
  comment: { icon: MessageCircle, color: "text-sky-400", bg: "bg-sky-500/10", verb: "commented on your post" },
  follow: { icon: UserPlus, color: "text-purple-400", bg: "bg-purple-500/10", verb: "started following you" },
  friend_request: { icon: UserPlus, color: "text-emerald-400", bg: "bg-emerald-500/10", verb: "sent you a friend request" },
  message: { icon: MessageCircle, color: "text-cyan-400", bg: "bg-cyan-500/10", verb: "sent you a message" },
  mention: { icon: AtSign, color: "text-amber-400", bg: "bg-amber-500/10", verb: "mentioned you" },
  share: { icon: Share2, color: "text-indigo-400", bg: "bg-indigo-500/10", verb: "shared your post" },
  collab: { icon: Users, color: "text-teal-400", bg: "bg-teal-500/10", verb: "invited you to collaborate" },
  live: { icon: Radio, color: "text-rose-400", bg: "bg-rose-500/10", verb: "went live" },
  world: { icon: Globe2, color: "text-teal-400", bg: "bg-teal-500/10", verb: "posted in a World you joined" },
  marketplace: { icon: ShoppingBag, color: "text-green-400", bg: "bg-green-500/10", verb: "listed a new item" },
  premium: { icon: Crown, color: "text-amber-400", bg: "bg-amber-500/10", verb: "updated your Premium status" },
};

export default function Notifications() {
  const [notifs, setNotifs] = useState([]);
  const [accepted, setAccepted] = useState({});
  const [loading, setLoading] = useState(true);

  const markAllRead = async (list) => {
    setNotifs(ns => ns.map(n => ({ ...n, is_read: true })));
  };

  useEffect(() => {
    (async () => {
      let me = null;
      try { me = await getMe(); } catch {}
      try {
        const db = await base44.entities.Notification.list("-created_date", 50);
        const mine = db.filter(n => !n.recipient || n.recipient === me?.name);
        setNotifs(mine);
        // auto mark as read after viewing
        if (me && mine.some(n => !n.is_read)) {
          await base44.entities.Notification.updateMany(
            { recipient: me.name, is_read: false },
            { $set: { is_read: true } }
          ).catch(() => {});
          setNotifs(ns => ns.map(n => ({ ...n, is_read: true })));
        }
      } catch {
        setNotifs([]);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const accept = async (n) => {
    await acceptFriendRequest(n.actor_name).catch(() => {});
    setAccepted(a => ({ ...a, [n.id]: true }));
  };

  const decline = async (n) => {
    await declineFriendRequest(n.actor_name).catch(() => {});
    setNotifs(ns => ns.filter(x => x.id !== n.id));
  };

  const unread = notifs.filter(n => !n.is_read).length;

  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border px-4 py-3 flex items-center gap-2">
        <Bell className="w-6 h-6 text-primary" />
        <h1 className="text-2xl font-extrabold bix-gradient-text">Notifications</h1>
        <button
          onClick={() => markAllRead()}
          disabled={unread === 0}
          className="ml-auto px-3 py-1.5 rounded-full bg-secondary/60 text-xs font-semibold disabled:opacity-40"
        >
          {unread > 0 ? `Mark all read (${unread})` : "All read"}
        </button>
      </header>

      <div className="p-2">
        {loading ? (
          <div className="flex justify-center py-16">
            <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
          </div>
        ) : notifs.length === 0 ? (
          <div className="text-center py-16 text-sm text-muted-foreground">No notifications yet</div>
        ) : notifs.map((n, i) => {
          const cfg = typeMap[n.type] || typeMap.like;
          const Icon = cfg.icon;
          const isFriendReq = n.type === "friend_request";
          return (
            <div key={n.id || i} className={cn("flex items-center gap-3 p-3 rounded-2xl transition hover:bg-secondary/40", !n.is_read && "bg-primary/5")}>
              <div className="relative shrink-0">
                <img src={n.actor_avatar} alt="" className="w-12 h-12 rounded-full object-cover" />
                <div className={cn("absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center border-2 border-background", cfg.bg)}>
                  <Icon className={cn("w-3.5 h-3.5", cfg.color)} />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm"><span className="font-semibold">{n.actor_name}</span> <span className="text-muted-foreground">{n.text}</span></p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[10px] text-muted-foreground">{n.created_date ? moment(n.created_date).fromNow() : "just now"}</span>
                  {!n.is_read && <span className="w-2 h-2 rounded-full bix-gradient" />}
                </div>
                {isFriendReq && !accepted[n.id] ? (
                  <div className="flex gap-2 mt-2">
                    <button onClick={() => accept(n)} className="px-4 py-1.5 rounded-full bix-gradient text-white text-xs font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Accept
                    </button>
                    <button onClick={() => decline(n)} className="px-4 py-1.5 rounded-full bg-secondary text-muted-foreground text-xs font-semibold flex items-center gap-1">
                      <X className="w-3.5 h-3.5" /> Decline
                    </button>
                  </div>
                ) : isFriendReq ? (
                  <span className="inline-flex items-center gap-1 text-xs text-primary mt-1"><CheckCheck className="w-3.5 h-3.5" /> Friends now</span>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}