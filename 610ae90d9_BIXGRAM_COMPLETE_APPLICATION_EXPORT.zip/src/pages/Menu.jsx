import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { TrendingUp, Flame, Sparkles, ShoppingBag, Settings, Crown, LifeBuoy, LogOut, ChevronRight, BadgeCheck, Users, Video, Bot, SlidersHorizontal, Award, Bookmark, Shield, Lock, Flag, ShieldAlert } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { clearMeCache, getMe, getProfile, defaultAvatar } from "@/lib/social";

const sections = [
  { title: "Discover", items: [
    { label: "Trending Now", icon: TrendingUp, to: "/trending", color: "from-orange-500 to-rose-600" },
    { label: "Popular Words", icon: Flame, to: "/trending", color: "from-rose-500 to-pink-600" },
    { label: "Suggested for You", icon: Sparkles, to: "/trending", color: "from-amber-500 to-orange-600" },
    { label: "Community", icon: Users, to: "/communities", color: "from-cyan-500 to-blue-600" },
    { label: "Live", icon: Video, to: "/live", color: "from-rose-500 to-red-600" },
    { label: "Live Studio", icon: SlidersHorizontal, to: "/live/studio", color: "from-fuchsia-500 to-rose-600" },
    { label: "Channels", icon: Users, to: "/channels", color: "from-indigo-500 to-violet-600" },
    { label: "BIX AI", icon: Bot, to: "/bix-ai", color: "from-violet-500 to-purple-600" },
    { label: "Marketplace", icon: ShoppingBag, to: "/marketplace", color: "from-emerald-500 to-teal-600" },
  ]},
  { title: "Your Space", items: [
    { label: "Saved Posts", icon: Bookmark, to: "/profile?tab=Saved", color: "from-cyan-500 to-blue-600" },
    { label: "Creator Studio", icon: BadgeCheck, to: "/profile", color: "from-blue-500 to-indigo-600" },
    { label: "Creator Score", icon: Award, to: "/creator-score", color: "from-amber-500 to-yellow-600" },
    { label: "Choose Your Feed", icon: SlidersHorizontal, to: "/choose-feed", color: "from-teal-500 to-emerald-600" },
    { label: "Premium", icon: Crown, to: "/premium", color: "from-amber-400 to-yellow-600" },
  ]},
  { title: "Settings & Support", items: [
    { label: "Settings", icon: Settings, to: "/settings", color: "from-slate-400 to-slate-600" },
    { label: "Help & Support", icon: LifeBuoy, to: "/settings", color: "from-blue-500 to-sky-600" },
    { label: "Privacy", icon: Shield, to: "/settings", color: "from-indigo-500 to-blue-600" },
    { label: "Security", icon: Lock, to: "/settings", color: "from-emerald-500 to-teal-600" },
    { label: "Report a Problem", icon: Flag, to: "/settings", color: "from-rose-500 to-red-600" },
  ]},
];

export default function Menu() {
  const [me, setMe] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const m = await getMe();
        let avatar = defaultAvatar(m.name);
        let name = m.name;
        let handle = m.name;
        try {
          const p = await getProfile(m.name);
          avatar = p.avatar_url || avatar;
          name = p.full_name || p.username || name;
          handle = p.username || handle;
        } catch {}
        setMe({ name, handle, avatar });
      } catch {}
      try {
        // The role comes from the authenticated session as returned by the
        // server — never from a display name, local storage or a URL value,
        // so renaming an account or editing client state cannot grant access.
        // This only decides whether the entry point is drawn; the Admin Studio
        // re-checks the role itself and the platform enforces admin-only data
        // access server-side.
        const u = await base44.auth.me();
        setIsAdmin(u?.role === "admin" || u?.role === "owner");
      } catch {}
    })();
  }, []);

  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/85 backdrop-blur-xl border-b border-border">
        <div className="h-16 flex items-center px-4 max-w-2xl mx-auto">
          <h1 className="text-xl font-extrabold bix-gradient-text">Menu</h1>
        </div>
      </header>

      <div className="p-3">
        <Link to="/profile" className="bix-card p-4 flex items-center gap-3 mb-4 bix-press">
          <img src={me?.avatar || defaultAvatar("You")} alt="" className="w-14 h-14 rounded-full object-cover ring-2 ring-primary/40" />
          <div className="flex-1 min-w-0">
            <div className="font-bold truncate">{me?.name || "You"}</div>
            <div className="text-xs text-muted-foreground truncate">@{me?.handle || "you"} · View your profile</div>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
        </Link>

        {isAdmin && (
          <div className="mb-5">
            <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-1 mb-2">Administration</h2>
            <div className="bix-card overflow-hidden">
              <Link to="/admin" className="flex items-center gap-3 p-3 hover:bg-secondary/40 transition">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-rose-600 flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-5 h-5 text-white" />
                </div>
                <span className="flex-1 font-medium text-sm">Admin Studio</span>
                <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
              </Link>
            </div>
          </div>
        )}

        {sections.map(sec => (
          <div key={sec.title} className="mb-5">
            <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-1 mb-2">{sec.title}</h2>
            <div className="bix-card overflow-hidden">
              {sec.items.map((item, i) => (
                <Link key={i} to={item.to} className="flex items-center gap-3 p-3 hover:bg-secondary/40 transition border-b border-border last:border-0">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center shrink-0`}>
                    <item.icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="flex-1 font-medium text-sm">{item.label}</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                </Link>
              ))}
            </div>
          </div>
        ))}

        <button
          onClick={() => { clearMeCache(); base44.auth.logout(); }}
          className="w-full bix-card p-3 flex items-center justify-center gap-2 text-rose-400 font-semibold text-sm hover:bg-rose-500/10 transition"
        >
          <LogOut className="w-5 h-5" /> Log out
        </button>

        <p className="text-center text-[11px] text-muted-foreground mt-4">BIXGRAM · Connect. Share. Live.</p>
      </div>
    </div>
  );
}