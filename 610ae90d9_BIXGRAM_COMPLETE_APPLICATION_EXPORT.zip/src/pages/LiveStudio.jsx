import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Radio, Clock, Eye, Users, Gift, Coins, Calendar, Crown } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getMyLiveStats, formatDuration, getLiveEligibility } from "@/lib/live";
import { formatCount } from "@/lib/bixgram-data";
import moment from "moment";

export default function LiveStudio() {
  const [stats, setStats] = useState(null);
  const [eligibility, setEligibility] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [s, e] = await Promise.all([
        getMyLiveStats().catch(() => null),
        getLiveEligibility().catch(() => ({ canGoLive: false, plan: "none" })),
      ]);
      setStats(s);
      setEligibility(e);
      setLoading(false);
    })();
  }, []);

  const sessions = useMemo(() => {
    const list = stats?.streams || [];
    return [...list].sort((a, b) => new Date(b.started_at || b.scheduled_for || b.created_date) - new Date(a.started_at || a.scheduled_for || a.created_date));
  }, [stats]);

  if (loading) {
    return (
      <div className="flex justify-center py-24">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const cards = [
    { icon: Radio, label: "Sessions", value: formatCount(stats?.totalSessions || 0) },
    { icon: Clock, label: "Total duration", value: formatDuration(stats?.durationSeconds || 0) },
    { icon: Users, label: "Peak viewers", value: formatCount(stats?.peakViewers || 0) },
    { icon: Eye, label: "Total views", value: formatCount(stats?.totalViews || 0) },
    { icon: Gift, label: "Gifts", value: formatCount(stats?.gifts || 0) },
    { icon: Coins, label: "Coins", value: formatCount(stats?.coins || 0) },
  ];

  return (
    <div className="max-w-2xl mx-auto pb-6">
      <header className="sticky top-0 z-40 bg-background/85 backdrop-blur-xl border-b border-border px-4 py-3 flex items-center gap-2">
        <Link to="/live" aria-label="Back" className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-secondary/60 shrink-0">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="min-w-0 flex-1">
          <h1 className="text-lg font-extrabold bix-gradient-text">Live Studio</h1>
          <p className="text-[11px] text-muted-foreground">Your live sessions, audience and earnings</p>
        </div>
      </header>

      <div className="p-3 space-y-3">
        {!eligibility?.canGoLive && (
          <Link to="/premium" className="bix-card p-3 flex items-center gap-3 bix-press">
            <Crown className="w-5 h-5 text-amber-400 shrink-0" />
            <div className="min-w-0 flex-1">
              <div className="text-sm font-semibold">Live requires Premium</div>
              <div className="text-[11px] text-muted-foreground">Upgrade to start broadcasting.</div>
            </div>
          </Link>
        )}

        <div className="bix-card p-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted-foreground">Estimated Live earnings</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-secondary/60 text-muted-foreground">Estimated</span>
          </div>
          <div className="text-xl font-extrabold">
            {stats?.coins ? `${stats.estimatedEarnings} coins` : "No Live earnings yet"}
          </div>
          <p className="text-[10px] text-muted-foreground mt-1">
            70% creator share of gifts received. Not a settled payout, and coin purchases are not connected yet.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {cards.map(c => (
            <div key={c.label} className="bix-card p-2.5">
              <c.icon className="w-3.5 h-3.5 text-muted-foreground mb-1" />
              <div className="font-bold text-sm">{c.value}</div>
              <div className="text-[10px] text-muted-foreground leading-tight">{c.label}</div>
            </div>
          ))}
        </div>

        <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground px-1 pt-2">Sessions</h2>
        {sessions.length === 0 ? (
          <div className="text-center py-14 px-6">
            <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
              <Radio className="w-6 h-6 text-muted-foreground" />
            </div>
            <p className="font-semibold text-sm">No Live sessions yet</p>
            <p className="text-xs text-muted-foreground mt-1">Schedule or start a live to see it here.</p>
            <Link to="/live" className="inline-block mt-4 px-5 py-2.5 rounded-full bix-gradient text-white text-sm font-semibold">
              Go to Live
            </Link>
          </div>
        ) : (
          sessions.map(s => (
            <div key={s.id} className="bix-card p-3">
              <div className="flex items-center gap-2">
                <span className={s.status === "live" ? "px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-bold uppercase" : s.status === "scheduled" ? "px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 text-[10px] font-bold uppercase" : "px-2 py-0.5 rounded-full bg-secondary text-muted-foreground text-[10px] font-bold uppercase"}>
                  {s.status}
                </span>
                <span className="text-[10px] text-muted-foreground ml-auto flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {s.scheduled_for ? moment(s.scheduled_for).format("D MMM, HH:mm") : s.started_at ? moment(s.started_at).fromNow() : ""}
                </span>
              </div>
              <div className="font-semibold text-sm mt-1.5 break-words">{s.title}</div>
              <div className="flex items-center gap-3 text-[11px] text-muted-foreground mt-1">
                <span className="flex items-center gap-1"><Users className="w-3 h-3" />{formatCount(s.peak_viewers || 0)} peak</span>
                <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{formatCount(s.total_views || 0)}</span>
                {s.category && <span className="capitalize">{s.category}</span>}
              </div>
            </div>
          ))
        )}

        <div className="bix-card p-3">
          <p className="text-[11px] text-muted-foreground">
            <strong className="text-foreground">Not yet implemented:</strong> camera capture, live video ingest and
            real-time streaming transport. Sessions, viewing, comments, reactions and gifts run on the existing data layer.
          </p>
        </div>
      </div>
    </div>
  );
}