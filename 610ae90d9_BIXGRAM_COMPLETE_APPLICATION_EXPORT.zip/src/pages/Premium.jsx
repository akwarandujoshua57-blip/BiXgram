import React from "react";
import { Crown, Check, Zap, Sparkles } from "lucide-react";
import { PREMIUM_PLANS, PROMO_PACKAGES } from "@/lib/bixgram-data";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export default function Premium() {
  const { toast } = useToast();
  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border px-4 py-3">
        <h1 className="text-2xl font-extrabold flex items-center gap-2">
          <Crown className="w-6 h-6 text-amber-400" />
          <span className="bix-gradient-text">BIXGRAM Premium</span>
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">Unlock the full BIXGRAM experience.</p>
      </header>

      <div className="p-4">
        <div className="bix-card p-5 mb-5 text-center bg-gradient-to-br from-card to-secondary/30">
          <div className="w-16 h-16 rounded-2xl bix-gradient flex items-center justify-center mx-auto mb-3 bix-glow">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h2 className="font-extrabold text-lg">Go Premium, Stand Out</h2>
          <p className="text-sm text-muted-foreground mt-1">No ads, premium badge, advanced tools and more.</p>
        </div>

        <div className="space-y-3 mb-6">
          {PREMIUM_PLANS.map(p => (
            <div key={p.name} className={cn(
              "bix-card p-4 relative overflow-hidden",
              p.popular && "ring-2 ring-primary"
            )}>
              {p.popular && (
                <div className="absolute top-0 right-0 bix-gradient text-white text-[10px] font-bold px-3 py-1 rounded-bl-xl">MOST POPULAR</div>
              )}
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="font-bold text-base">{p.name}</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-extrabold">${p.price}</span>
                    <span className="text-xs text-muted-foreground">/month</span>
                  </div>
                </div>
                <div className={cn("w-12 h-12 rounded-xl bg-gradient-to-br flex items-center justify-center", p.color)}>
                  <Crown className="w-6 h-6 text-white" />
                </div>
              </div>
              <ul className="space-y-1.5 mb-3">
                {p.features.map(f => (
                  <li key={f} className="flex items-start gap-2 text-xs">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" /> {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => toast({ title: `${p.name} plan selected`, description: "Checkout connects here once payments are enabled." })}
                className={cn("w-full py-2.5 rounded-xl font-semibold text-sm transition", p.popular ? "bix-gradient text-white hover:scale-[1.02]" : "bg-secondary hover:bg-secondary/80")}
              >
                Choose {p.name}
              </button>
            </div>
          ))}
        </div>

        <div className="mb-3">
          <h2 className="font-bold text-sm mb-1 flex items-center gap-2"><Zap className="w-4 h-4 text-amber-400" /> Promote Your Post</h2>
          <p className="text-xs text-muted-foreground mb-3">Estimated reach — not guaranteed.</p>
          <div className="grid grid-cols-3 gap-2">
            {PROMO_PACKAGES.map(p => (
              <div key={p.price} className="bix-card p-3 text-center">
                <div className={cn("w-10 h-10 rounded-xl bg-gradient-to-br mx-auto mb-2 flex items-center justify-center", p.color)}>
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <div className="font-extrabold text-lg">${p.price}</div>
                <div className="text-[10px] text-muted-foreground">~{p.views} views</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}