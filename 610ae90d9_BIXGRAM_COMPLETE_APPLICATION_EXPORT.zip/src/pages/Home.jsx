import React, { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useNavigate, Link } from "react-router-dom";
import { SlidersHorizontal, RotateCw, WifiOff } from "lucide-react";
import { base44 } from "@/api/base44Client";
import FeedHeader from "@/components/feed/FeedHeader";
import PostComposer from "@/components/feed/PostComposer";
import PostCard from "@/components/feed/PostCard";
import PostSkeleton from "@/components/feed/PostSkeleton";
import { FEED_FILTERS } from "@/lib/bixgram-data";
import { getFollowedNames, getFriendNames } from "@/lib/social";
import { rankFeed } from "@/lib/feed";
import { cn } from "@/lib/utils";

const PAGE_SIZE = 10;

export default function Home() {
  const navigate = useNavigate();
  const [filter, setFilter] = useState("For You");
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [error, setError] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [followedNames, setFollowedNames] = useState([]);
  const [friendNames, setFriendNames] = useState([]);
  const cursorRef = useRef(null);
  const sentinelRef = useRef(null);

  const loadInitial = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const batch = await base44.entities.Post.list("-created_date", PAGE_SIZE);
      setPosts(batch);
      cursorRef.current = batch[batch.length - 1]?.created_date || null;
      setHasMore(batch.length >= PAGE_SIZE);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore || !cursorRef.current) return;
    setLoadingMore(true);
    try {
      // Cursor pagination: fetch the next page of posts older than the oldest shown.
      const batch = await base44.entities.Post.filter(
        { created_date: { $lt: cursorRef.current } },
        "-created_date",
        PAGE_SIZE
      );
      setPosts(prev => {
        const seen = new Set(prev.map(p => String(p.id)));
        const fresh = batch.filter(p => p.id && !seen.has(String(p.id)));
        return [...prev, ...fresh];
      });
      if (batch.length > 0) cursorRef.current = batch[batch.length - 1].created_date;
      setHasMore(batch.length >= PAGE_SIZE);
    } catch {
      // Cursor query unsupported — stop paging instead of breaking the feed
      setHasMore(false);
    } finally {
      setLoadingMore(false);
    }
  }, [loadingMore, hasMore]);

  const refresh = async () => {
    setRefreshing(true);
    await loadInitial();
    setRefreshing(false);
  };

  useEffect(() => { loadInitial(); }, [loadInitial]);

  useEffect(() => {
    getFollowedNames().then(setFollowedNames).catch(() => {});
    getFriendNames().then(setFriendNames).catch(() => {});
  }, []);

  // Infinite scroll: load the next page as the sentinel approaches the viewport
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      entries => { if (entries[0].isIntersecting) loadMore(); },
      { rootMargin: "400px" }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [loadMore]);

  const filtered = useMemo(() => {
    const f = posts.filter(p => {
      if (filter === "For You") return true;
      if (filter === "Following") return followedNames.includes(p.author_name);
      if (filter === "Friends") return friendNames.includes(p.author_name);
      return p.feed_type === filter.toLowerCase().replace(/\s/g, "_");
    });
    // For You is ranked by engagement + recency (see src/lib/feed.js);
    // other feeds stay chronological.
    return filter === "For You" ? rankFeed(f) : f;
  }, [posts, filter, followedNames, friendNames]);

  const onPosted = (created) => {
    if (created?.id) {
      setPosts(ps => [created, ...ps.filter(p => p.id !== created.id)]);
    } else {
      refresh();
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <FeedHeader onSearch={() => navigate("/search")} />

      <div className="sticky top-[64px] z-30 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="flex gap-1 px-3 py-2 overflow-x-auto no-scrollbar max-w-2xl mx-auto items-center">
          {FEED_FILTERS.map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition",
                filter === f ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground"
              )}
            >
              {f}
            </button>
          ))}
          <button
            onClick={refresh}
            title="Refresh feed"
            className="ml-auto shrink-0 w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center hover:bg-secondary transition"
          >
            <RotateCw className={cn("w-4 h-4 text-primary", refreshing && "animate-spin")} />
          </button>
          <Link
            to="/choose-feed"
            title="Choose Your Feed"
            className="shrink-0 w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center hover:bg-secondary transition"
          >
            <SlidersHorizontal className="w-4 h-4 text-primary" />
          </Link>
        </div>
      </div>

      <PostComposer onPosted={onPosted} />

      {loading ? (
        <div className="py-2">
          {[0, 1, 2].map(i => <PostSkeleton key={i} />)}
        </div>
      ) : error ? (
        <div className="flex flex-col items-center gap-3 py-16 px-6 text-center">
          <WifiOff className="w-10 h-10 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Couldn't load your feed right now.</p>
          <button onClick={refresh} className="px-5 py-2 rounded-full bix-gradient text-white text-sm font-semibold">
            Try again
          </button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 px-6">
          <p className="text-3xl mb-2">✨</p>
          <p className="text-sm font-semibold">Nothing here yet</p>
          <p className="text-xs text-muted-foreground mt-1">Be the first to share something in {filter}!</p>
        </div>
      ) : (
        <div>
          {filtered.map((p, i) => (
            <PostCard key={p.id || i} post={p} />
          ))}
          <div ref={sentinelRef} className="h-2" />
          {loadingMore || hasMore ? (
            <div className="flex justify-center py-6">
              <div className="w-7 h-7 border-4 border-secondary border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <div className="text-center py-6 text-xs text-muted-foreground">You're all caught up ✨</div>
          )}
        </div>
      )}
    </div>
  );
}