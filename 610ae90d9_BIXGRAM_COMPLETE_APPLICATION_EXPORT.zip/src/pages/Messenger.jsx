import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { Plus } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { defaultAvatar, getMe, getProfile } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import ChatView from "@/components/messenger/ChatView";
import NewChatSheet from "@/components/messenger/NewChatSheet";
import MessageTab from "@/components/messenger/MessageTab";

// Messenger is private messaging only: one clean conversation list, and calls
// live inside each individual chat. No Story, Community or Calls destinations.
export default function Messenger() {
  const location = useLocation();
  const { toast } = useToast();
  const [active, setActive] = useState(null);
  const [newChatOpen, setNewChatOpen] = useState(false);
  const [listKey, setListKey] = useState(0);
  const handledOpenWith = useRef(false);

  // Deep-link: open (or create) a chat with a specific person, e.g. from their profile
  useEffect(() => {
    const name = location.state?.openWith;
    if (!name || handledOpenWith.current) return;
    handledOpenWith.current = true;
    openWith(name);
  }, [location.state]);

  const openWith = async (name) => {
    const me = await getMe().catch(() => null);
    if (!me) return;

    // Only conversations this account actually belongs to are ever considered.
    const all = await base44.entities.Conversation.list("-updated_date", 50).catch(() => []);
    let c = all.find(x => !x.is_group && x.participant_name === name);

    if (!c) {
      // Respect the recipient's "who can message me" setting
      let allowed = true;
      let otherId = "";
      try {
        const p = await getProfile(name);
        otherId = p?.user_id || "";
        const rule = p?.privacy?.who_can_message;
        if (rule === "no_one") allowed = false;
        else if (rule === "followers") {
          const rows = await base44.entities.Follow
            .filter({ follower_name: me.name, following_name: name, created_by_id: me.id })
            .catch(() => []);
          allowed = rows.length > 0;
        }
      } catch {}

      if (!allowed) {
        toast({ title: "This person limits who can message them" });
        return;
      }
      if (!otherId) {
        toast({
          title: "Can't start this chat yet",
          description: `${name} hasn't set up their Bixgram profile.`,
          variant: "destructive",
        });
        return;
      }

      c = await base44.entities.Conversation.create({
        participant_name: name,
        participant_avatar: defaultAvatar(name),
        member_ids: [me.id, otherId],
        last_message: "",
        last_message_time: "now",
        unread_count: 0,
      }).catch(() => null);
    }

    if (!c) return;
    setActive(c);
  };

  const openGroup = async (groupName, memberNames) => {
    try {
      const me = await getMe();
      const ids = [];
      for (const n of memberNames) {
        try { const id = (await getProfile(n)).user_id; if (id) ids.push(id); } catch {}
      }
      const c = await base44.entities.Conversation.create({
        participant_name: groupName,
        participant_avatar: defaultAvatar(groupName),
        members: [me.name, ...memberNames],
        member_ids: [me.id, ...ids],
        is_group: true,
        last_message: "",
        last_message_time: "now",
        unread_count: 0,
      });
      setNewChatOpen(false);
      setActive(c);
    } catch {
      toast({ title: "Could not create the group", variant: "destructive" });
    }
  };

  const startCall = (kind) => {
    toast({
      title: kind === "video" ? "Video calling isn't connected yet" : "Voice calling isn't connected yet",
      description: "Calling needs a real-time media provider before it can connect real people.",
    });
  };

  if (active) {
    return (
      <ChatView
        convo={active}
        onBack={() => { setActive(null); setListKey(k => k + 1); }}
        onStartCall={startCall}
      />
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <header className="sticky top-0 z-40 bg-background/85 backdrop-blur-xl border-b border-border">
        <div className="h-16 flex items-center justify-between gap-2 px-4">
          <h1 className="text-2xl font-extrabold bix-gradient-text min-w-0 truncate">Message</h1>
          <button
            onClick={() => setNewChatOpen(true)}
            aria-label="New message"
            className="w-9 h-9 rounded-full bix-gradient flex items-center justify-center bix-glow bix-press shrink-0"
          >
            <Plus className="w-5 h-5 text-white" />
          </button>
        </div>
      </header>

      <MessageTab key={listKey} onOpen={setActive} onNew={() => setNewChatOpen(true)} />

      <NewChatSheet
        open={newChatOpen}
        onClose={() => setNewChatOpen(false)}
        onStart={openWith}
        onGroup={openGroup}
      />
    </div>
  );
}