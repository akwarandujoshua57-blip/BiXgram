import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search as SearchIcon, X, TrendingUp, BadgeCheck, MapPin, Clock } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { formatCount } from "@/lib/bixgram-data";
import { isFollowing, toggleFollow, defaultAvatar } from "@/lib/social";
import { getVerifiedNameSet } from "@/lib/channels";
import { getSuggestedPeople, getTopHashtags } from "@/lib/feed";
import { cn } from "@/lib/utils";
import PostCard from "@/components/feed/PostCard";
import ChannelResultRow from "@/components/channels/ChannelResultRow";

const TABS = ["Users", "Posts", "Channels", "Hashtags", "Marketplace"];

export default function Search() {
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("Users");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [follows, setFollows] = useState({});
  const [recents, setRecents] = useState(() => {
    try { return JSON.parse(localStorage.getItem("bix_recent_searches") || "[]"); } catch { return []; }
  });
  const [suggested, setSuggested] = useState({ people: [], tags: [] });
  const [verifiedNames, setVerifiedNames] = useState(new Set());
  const timerRef = useRef(null);
  const navigate = useNavigate();

  const saveRecents = (list) => {
    setRecents(list);
    try { localStorage.setItem("bix_recent_searches", JSON.stringify(list)); } catch {}
  };
  const addRecent = (q) => {
    const t = q.trim();
    if (!t) return;
    saveRecents([t, ...recents.filter(x => x !== t)].slice(0, 8));
  };
  const removeRecent = (q) => saveRecents(recents.filter(x => x !== q));
  const clearRecents = () => saveRecents([]);

  useEffect(() => {
    const q = query.trim();
    clearTimeout(timerRef.current);
    if (q.length === 0) { setResults(null); return; }
    timerRef.current = setTimeout(async () => {
      setLoading(true);
      const lower = q.toLowerCase();
      const [profiles, posts, channels, listings] = await Promise.all([
        base44.entities.Profile.list(100).catch(() => []),
        base44.entities.Post.list("-likes_count", 100).catch(() => []),
        base44.entities.Channel.list("-created_date", 50).catch(() => []),
        base44.entities.MarketplaceListing.list(50).catch(() => []),
      ]);

      const users = profiles.filter(p => p.username?.toLowerCase().includes(lower));
      const matchedPosts = posts.filter(p => p.text?.toLowerCase().includes(lower) || p.author_name?.toLowerCase().includes(lower));

      // hashtags from post text plus trending topics
      const tagCounts = {};
      const countTags = (text) => {
        for (const m of String(text || "").match(/#[\w]+/g) || []) {
          tagCounts[m.toLowerCase()] = (tagCounts[m.toLowerCase()] || 0) + 1;
        }
      };
      posts.forEach(p => countTags(p.text));
      const hashtags = Object.entries(tagCounts)
        .filter(([tag]) => tag.includes(q.toLowerCase().replace("#", "")) && tag.startsWith("#"))
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([tag, count]) => ({ tag, count }));

      setResults({
        users,
        posts: matchedPosts,
        channels: channels.filter(c =>
          c.name?.toLowerCase().includes(lower) || c.username?.toLowerCase().includes(lower)
        ),
        hashtags,
        listings: listings.filter(l => l.title?.toLowerCase().includes(lower) || l.description?.toLowerCase().includes(lower)),
      });

      // load follow states for user results
      const states = {};
      for (const u of users) {
        states[u.username] = await isFollowing(u.username).catch(() => false);
      }
      setFollows(states);
      setLoading(false);
    }, 450);
    return () => clearTimeout(timerRef.current);
  }, [query]);

  // Real discovery data: top creators by followers + hashtags from recent posts
  useEffect(() => {
    if (query.trim()) return;
    Promise.all([
      getSuggestedPeople(5).catch(() => []),
      getTopHashtags(6).catch(() => []),
    ]).then(([people, tags]) => setSuggested({ people, tags }));
  }, [query]);

  // Verification comes from the admin-controlled record — never from a profile
  // field a user could set on themselves.
  useEffect(() => {
    getVerifiedNameSet().then(setVerifiedNames).catch(() => {});
  }, []);

  const onFollow = async (username) => {
    const next = await toggleFollow(username);
    setFollows(f => ({ ...f, [username]: next }));
  };

  const countFor = (t) => {
    if (!results) return 0;
    return results[{
      Users: "users", Posts: "posts", Channels: "channels",
      Hashtags: "hashtags", Marketplace: "listings",
    }[t]].length;
  };

  return (
    <div className="max-w-2xl mx-auto pb-6">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border px-4 py-3">
        <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2.5">
          <SearchIcon className="w-5 h-5 text-muted-foreground" />
          <input
            autoFocus
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === "Enter" && addRecent(query)}
            placeholder="Search BIXGRAM…"
            className="flex-1 bg-transparent outline-none text-sm"
          />
          {query && <button onClick={() => setQuery("")}><X className="w-4 h-4 text-muted-foreground" /></button>}
        </div>
      </header>

      {!query ? (
        <div className="p-4">
          {recents.length > 0 && (
            <div className="mb-5">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> Recent searches</h2>
                <button onClick={clearRecents} className="text-xs text-primary font-semibold">Clear all</button>
              </div>
              <div className="bix-card overflow-hidden">
                {recents.map(r => (
                  <div key={r} className="flex items-center gap-3 px-3 py-2.5 border-b border-border last:border-0">
                    <button onClick={() => setQuery(r)} className="flex-1 text-left text-sm">{r}</button>
                    <button onClick={() => removeRecent(r)}><X className="w-4 h-4 text-muted-foreground" /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
          <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Popular Words</h2>
          <div className="flex flex-wrap gap-2">
            {suggested.tags.length > 0 ? suggested.tags.map(t => (
              <button key={t.tag} onClick={() => setQuery(t.tag)} className="px-3 py-1.5 rounded-full bg-secondary/60 text-sm font-medium hover:bg-secondary transition">
                {t.tag}
              </button>
            )) : (
              <span className="text-sm text-muted-foreground">No popular words yet — they appear as people post.</span>
            )}
          </div>
          <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2 mt-5 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" /> Trending Searches
          </h2>
          <div className="bix-card overflow-hidden">
            {suggested.people.map((u, i) => (
              <Link key={u.username} to={`/profile/${encodeURIComponent(u.username)}`} className="flex items-center gap-3 p-3 border-b border-border last:border-0 hover:bg-secondary/40 transition">
                <span className="text-lg font-extrabold text-muted-foreground/40 w-6">{i + 1}</span>
                <img src={u.avatar_url || defaultAvatar(u.username)} alt="" className="w-9 h-9 rounded-full object-cover" />
                <div className="flex-1">
                  <div className="flex items-center gap-1"><span className="font-semibold text-sm">{u.full_name || u.username}</span>{(verifiedNames.has(u.full_name) || verifiedNames.has(u.username)) && <BadgeCheck className="w-3.5 h-3.5 text-primary" />}</div>
                  <div className="text-xs text-muted-foreground">@{u.username.toLowerCase().replace(/\s+/g, "")} · {formatCount(u.followers_count || 0)} followers</div>
                </div>
              </Link>
            ))}
            {suggested.people.length === 0 && (
              <div className="text-center py-6 text-sm text-muted-foreground">No suggested creators yet</div>
            )}
          </div>
        </div>
      ) : (
        <div>
          <div className="flex gap-1 px-3 pt-3 overflow-x-auto no-scrollbar">
            {TABS.map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition",
                  tab === t ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground"
                )}
              >
                {t}
                {results && <span className="ml-1 opacity-70">{countFor(t)}</span>}
              </button>
            ))}
          </div>
          <div className="p-3">
            {loading ? (
              <div className="flex justify-center py-16">
                <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
              </div>
            ) : !results || countFor(tab) === 0 ? (
              <div className="text-center py-16 text-sm text-muted-foreground">
                No {tab.toLowerCase()} found for "{query}" 😕
              </div>
            ) : tab === "Users" ? results.users.map(u => (
              <div key={u.id} className="flex items-center gap-3 p-2">
                <Link to={`/profile/${encodeURIComponent(u.username)}`}>
                  <img src={u.avatar_url || defaultAvatar(u.username)} alt="" className="w-11 h-11 rounded-full object-cover" />
                </Link>
                <Link to={`/profile/${encodeURIComponent(u.username)}`} className="flex-1 min-w-0">
                  <div className="flex items-center gap-1"><span className="font-semibold text-sm">{u.full_name || u.username}</span></div>
                  <div className="text-xs text-muted-foreground">@{u.username.replace(/\s+/g, "").toLowerCase()} · {formatCount(u.followers_count || 0)} followers</div>
                </Link>
                <button
                  onClick={() => onFollow(u.username)}
                  className={cn("px-4 py-1.5 rounded-full text-xs font-semibold", follows[u.username] ? "bg-secondary text-muted-foreground" : "bix-gradient text-white")}
                >
                  {follows[u.username] ? "Following" : "Follow"}
                </button>
              </div>
            )) : tab === "Posts" ? results.posts.map((p, i) => (
              <PostCard key={p.id || i} post={p} />
            )) : tab === "Channels" ? results.channels.map((c, i) => (
              <ChannelResultRow key={c.id || i} channel={c} verified={verifiedNames.has(c.name)} />
            )) : tab === "Hashtags" ? results.hashtags.map(h => (
              <Link key={h.tag} to="/trending" className="block bix-card p-3 mb-2 hover:bg-secondary/40 transition">
                <div className="font-bold text-sm bix-gradient-text">{h.tag}</div>
                <div className="text-xs text-muted-foreground">{h.count} {h.count === 1 ? "post" : "posts"}</div>
              </Link>
            )) : results.listings.map((l, i) => (
              <Link key={l.id || i} to="/marketplace" className="block bix-card overflow-hidden mb-2">
                {l.image_url && <img src={l.image_url} alt="" className="w-full h-32 object-cover" />}
                <div className="p-2">
                  <div className="text-sm font-bold">${l.price} · {l.title}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="w-3 h-3" /> {l.location}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}