import { lazy, Suspense } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import AppLayout from '@/components/AppLayout';
// Auth pages
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
// App pages
import Home from '@/pages/Home';
import Community from '@/pages/Community';
import Messenger from '@/pages/Messenger';
import Menu from '@/pages/Menu';
import Profile from '@/pages/Profile';
// Secondary pages load lazily for faster first paint
const Trending = lazy(() => import('@/pages/Trending'));
const LiveStudio = lazy(() => import('@/pages/LiveStudio'));
const Marketplace = lazy(() => import('@/pages/Marketplace'));
const Premium = lazy(() => import('@/pages/Premium'));
const Settings = lazy(() => import('@/pages/Settings'));
const Notifications = lazy(() => import('@/pages/Notifications'));
const Search = lazy(() => import('@/pages/Search'));
const CreatorScore = lazy(() => import('@/pages/CreatorScore'));
const AdminStudio = lazy(() => import('@/pages/AdminStudio'));
const Live = lazy(() => import('@/pages/Live'));
const BixAI = lazy(() => import('@/pages/BixAI'));
const ChooseFeed = lazy(() => import('@/pages/ChooseFeed'));
const CommunityDetail = lazy(() => import('@/pages/CommunityDetail'));
const PostDetail = lazy(() => import('@/pages/PostDetail'));
const Channels = lazy(() => import('@/pages/Channels'));
const ChannelProfile = lazy(() => import('@/pages/ChannelProfile'));

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-10 h-10 border-4 border-secondary border-t-primary rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Suspense fallback={
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-10 h-10 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    }>
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<AppLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/communities" element={<Community />} />
          <Route path="/communities/:id" element={<CommunityDetail />} />
          <Route path="/post/:id" element={<PostDetail />} />
          <Route path="/messenger" element={<Messenger />} />
          <Route path="/menu" element={<Menu />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/profile/:username" element={<Profile />} />
          <Route path="/trending" element={<Trending />} />
          <Route path="/live/studio" element={<LiveStudio />} />
          <Route path="/marketplace" element={<Marketplace />} />
          <Route path="/premium" element={<Premium />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/search" element={<Search />} />
          <Route path="/creator-score" element={<CreatorScore />} />
          <Route path="/live" element={<Live />} />
          <Route path="/bix-ai" element={<BixAI />} />
          <Route path="/choose-feed" element={<ChooseFeed />} />
          <Route path="/channels" element={<Channels />} />
          <Route path="/channels/:id" element={<ChannelProfile />} />
        </Route>
        <Route path="/admin" element={<AdminStudio />} />
      </Route>

      <Route path="*" element={<PageNotFound />} />
    </Routes>
    </Suspense>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App