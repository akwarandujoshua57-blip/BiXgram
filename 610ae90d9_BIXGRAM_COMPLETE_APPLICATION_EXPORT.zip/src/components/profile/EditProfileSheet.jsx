import React, { useState, useRef } from "react";
import { X, Camera, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { uploadFile } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";

export default function EditProfileSheet({ profile, onClose, onSaved }) {
  const [fullName, setFullName] = useState(profile.full_name || profile.username);
  const [bio, setBio] = useState(profile.bio || "");
  const [location, setLocation] = useState(profile.location || "");
  const [avatar, setAvatar] = useState(profile.avatar_url);
  const [cover, setCover] = useState(profile.cover_url);
  const [saving, setSaving] = useState(false);
  const [uploadingField, setUploadingField] = useState(null);
  const avatarRef = useRef(null);
  const coverRef = useRef(null);
  const { toast } = useToast();

  const onFile = async (e, field, setter) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setUploadingField(field);
    try {
      setter(await uploadFile(file));
    } catch {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setUploadingField(null);
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      await base44.entities.Profile.update(profile.id, {
        full_name: fullName.trim() || profile.username,
        bio: bio.trim(),
        location: location.trim(),
        avatar_url: avatar,
        cover_url: cover,
      });
      toast({ title: "Profile updated ✨" });
      onSaved?.();
      onClose?.();
    } catch {
      toast({ title: "Could not save profile", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
      <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-lg">Edit Profile</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex gap-3">
          <button onClick={() => avatarRef.current?.click()} className="relative shrink-0 group">
            <img src={avatar} alt="" className="w-20 h-20 rounded-full object-cover" />
            <span className="absolute inset-0 rounded-full bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
              {uploadingField === "avatar" ? <Loader2 className="w-5 h-5 animate-spin text-white" /> : <Camera className="w-5 h-5 text-white" />}
            </span>
          </button>
          <button onClick={() => coverRef.current?.click()} className="relative flex-1 h-20 rounded-xl overflow-hidden group">
            <img src={cover} alt="" className="w-full h-full object-cover" />
            <span className="absolute inset-0 bg-black/50 flex items-center justify-center gap-1.5 text-xs font-medium text-white">
              {uploadingField === "cover" ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Camera className="w-4 h-4" /> Change cover</>}
            </span>
          </button>
        </div>
        <input ref={avatarRef} type="file" accept="image/*" hidden onChange={e => onFile(e, "avatar", setAvatar)} />
        <input ref={coverRef} type="file" accept="image/*" hidden onChange={e => onFile(e, "cover", setCover)} />

        <div>
          <label className="text-xs text-muted-foreground">Name</label>
          <input value={fullName} onChange={e => setFullName(e.target.value)} className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none mt-1" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Username</label>
          <input value={profile.username} disabled className="w-full bg-secondary/30 rounded-xl px-3 py-2.5 text-sm outline-none mt-1 text-muted-foreground" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Bio</label>
          <textarea value={bio} onChange={e => setBio(e.target.value)} rows={2} className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none mt-1 resize-none" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Location</label>
          <input value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g. Lagos, Nigeria" className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none mt-1" />
        </div>

        <button onClick={save} disabled={saving || uploadingField} className="w-full py-3 rounded-xl bix-gradient text-white font-semibold disabled:opacity-50">
          {saving ? "Saving…" : "Save Changes"}
        </button>
      </div>
    </div>
  );
}