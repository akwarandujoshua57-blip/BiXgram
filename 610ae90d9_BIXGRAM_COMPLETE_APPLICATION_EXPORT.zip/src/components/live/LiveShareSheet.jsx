import React from "react";
import { Link2, Send, Copy, Check } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

// The shared link always resolves from the real stream id.
export default function LiveShareSheet({ open, onClose, stream }) {
  const { toast } = useToast();
  if (!open) return null;

  const link = `${window.location.origin}/live?s=${encodeURIComponent(stream.id)}`;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(link);
      toast({ title: "Live link copied" });
      onClose();
    } catch {
      toast({ title: "Could not copy the link", variant: "destructive" });
    }
  };

  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: `${stream.host_name} is live`, text: stream.title, url: link });
        onClose();
        return;
      } catch {}
    }
    copy();
  };

  const toMessage = async () => {
    try {
      await navigator.clipboard.writeText(link);
      toast({ title: "Link copied", description: "Paste it into a conversation." });
      onClose();
    } catch {}
  };

  return (
    <div className="fixed inset-0 z-[80] bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
      <div className="w-full max-w-md bg-card rounded-t-3xl p-5" onClick={e => e.stopPropagation()}>
        <h3 className="font-bold mb-3">Share this live</h3>
        <div className="space-y-2">
          <Row icon={Send} label="Share to Message" onClick={toMessage} />
          <Row icon={Copy} label="Copy live link" onClick={copy} />
          <Row icon={Link2} label="Share externally" onClick={share} />
        </div>
        <div className="mt-3 flex items-center gap-2 bg-secondary/50 rounded-xl px-3 py-2">
          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="text-[10px] text-muted-foreground truncate">{link}</span>
        </div>
        <button onClick={onClose} className="w-full mt-4 py-3 rounded-full bg-secondary text-sm font-semibold bix-press">
          Close
        </button>
      </div>
    </div>
  );
}

function Row({ icon: Icon, label, onClick }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-3 p-3 rounded-xl bg-secondary/50 bix-press">
      <Icon className="w-4 h-4 text-primary shrink-0" />
      <span className="text-sm font-medium">{label}</span>
    </button>
  );
}