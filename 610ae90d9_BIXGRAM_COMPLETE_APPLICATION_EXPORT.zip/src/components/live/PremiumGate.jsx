import React from "react";
import { Link } from "react-router-dom";
import { Crown, Video, Check } from "lucide-react";

const BENEFITS = [
  "Go Live whenever you want",
  "Host unlimited live sessions",
  "Receive gifts from your viewers",
  "Live analytics in your Creator Studio",
];

// Shown instead of the Go Live flow when the account has no active Premium
// entitlement. It never pretends the user has access.
export default function PremiumGate({ onClose }) {
  return (
    <div className="fixed inset-0 z-[70] bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
      <div
        className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-4"
        onClick={e => e.stopPropagation()}
      >
        <div className="w-14 h-14 rounded-2xl bix-gradient flex items-center justify-center mx-auto bix-glow">
          <Video className="w-7 h-7 text-white" />
        </div>

        <div className="text-center">
          <h3 className="font-extrabold text-lg">Go Live with Bixgram Premium</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Live streaming is a Premium feature. Upgrade to start broadcasting to your followers.
          </p>
        </div>

        <ul className="space-y-2">
          {BENEFITS.map(b => (
            <li key={b} className="flex items-start gap-2 text-sm">
              <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" /> {b}
            </li>
          ))}
        </ul>

        <p className="text-[11px] text-muted-foreground text-center">
          Premium is activated on your account by Bixgram. Checkout is not connected yet, so plans cannot be
          purchased in-app today.
        </p>

        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 min-w-0 py-3 rounded-full bg-secondary text-sm font-semibold bix-press">
            Not now
          </button>
          <Link
            to="/premium"
            onClick={onClose}
            className="flex-1 min-w-0 py-3 rounded-full bix-gradient text-white text-sm font-semibold flex items-center justify-center gap-1.5 bix-press"
          >
            <Crown className="w-4 h-4" /> See plans
          </Link>
        </div>
      </div>
    </div>
  );
}