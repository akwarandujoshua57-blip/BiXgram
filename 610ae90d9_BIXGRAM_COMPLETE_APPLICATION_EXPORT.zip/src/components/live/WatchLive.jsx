import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  X, Eye, BadgeCheck, Heart, Share2, Gift, Square, Volume2, VolumeX,
  Camera, CameraOff, RefreshCw, MoreVertical, Flag, Ban, MessageSquareOff,
  MessageSquare, Coins,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { formatCount } from "@/lib/bixgram-data";
import { getMe, isFollowing, toggleFollow, reportContent, toggleBlock, isBlockedByMe } from "@/lib/social";
import { isUserVerified } from "@/lib/channels";
import {
  REACTIONS, GIFT_BY_KEY, giftCoins,
  addLiveComment, getLiveComments, hideLiveComment, deleteLiveComment,
  sendLiveReaction, getLiveReactionTotal, joinLive, leaveLive, getLiveViewerCount,
  getLiveGifts, sendLiveGift, endLive, blockViewerFromStream,
} from "@/lib/live";
import { cn } from "@/lib/utils";
import LiveChat from "@/components/live/LiveChat";
import GiftSheet from "@/components/live/GiftSheet";
import LiveShareSheet from "@/components/live/LiveShareSheet";
import LiveEndedCard from "@/components/live/LiveEndedCard";

export default function WatchLive({ stream: initial, onClose, onEnded }) {
  const [stream, setStream] = useState(initial);
  const [comments, setComments] = useState([]);
  const [viewers, setViewers] = useState(0);
  const [reactionTotal, setReactionTotal] = useState(0);
  const [gifts, setGifts] = useState([]);
  const [me, setMe] = useState(null);
  const [verified, setVerified] = useState(false);
  const [following, setFollowing] = useState(false);
  const [blocked, setBlocked] = useState(false);
  const [muted, setMuted] = useState(true);
  const [cameraOn, setCameraOn] = useState(true);
  const [hearts, setHearts] = useState([]);
  const [showGifts, setShowGifts] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [busy, setBusy] = useState(false);
  const [ended, setEnded] = useState(!initial.is_live || initial.status === "ended");
  const peakRef = useRef(0);
  const chatRef = useRef(null);

  const isHost = !!(me && (stream.owner_id === me.id || stream.created_by_id === me.id));
  const commentsEnabled = stream.comments_enabled !== false;
  const giftsEnabled = stream.gifts_enabled !== false;

  // Identity + the badges that are resolved from admin-controlled records.
  useEffect(() => {
    (async () => {
      try {
        const m = await getMe();
        setMe(m);
        const [f, v, b] = await Promise.all([
          isFollowing(stream.host_name).catch(() => false),
          isUserVerified(stream.host_name).catch(() => false),
          isBlockedByMe(stream.host_name).catch(() => false),
        ]);
        setFollowing(f); setVerified(v); setBlocked(b);
      } catch {}
    })();
  }, [stream.host_name]);

  const refresh = useCallback(async () => {
    const [v, r, g] = await Promise.all([
      getLiveViewerCount(stream.id),
      getLiveReactionTotal(stream.id),
      getLiveGifts(stream.id),
    ]);
    setViewers(v);
    setReactionTotal(r);
    setGifts(g);
    if (v > peakRef.current) peakRef.current = v;
  }, [stream.id]);

  useEffect(() => {
    (async () => {
      setComments(await getLiveComments(stream.id));
      await refresh();
    })();
  }, [stream.id, refresh]);

  // Presence — only viewers occupy a slot; the host is not their own audience.
  useEffect(() => {
    if (!me || isHost) return;
    joinLive(stream.id);
    return () => { leaveLive(stream.id); };
  }, [me, isHost, stream.id]);

  // Realtime: only the collections this stream actually needs.
  useEffect(() => {
    const sameStream = (e) => String(e?.data?.stream_id ?? e?.data?.id ?? "") === String(stream.id);
    const unsubs = [
      base44.entities.LiveComment.subscribe(e => {
        if (!sameStream(e)) return;
        const rec = e.data;
        if (e.type === "create") setComments(c => (c.some(x => x.id === rec.id) ? c : [...c, rec]));
        else if (e.type === "update") setComments(c => c.map(x => (x.id === rec.id ? rec : x)));
        else if (e.type === "delete") setComments(c => c.filter(x => x.id !== (e.id || rec?.id)));
      }),
      base44.entities.LiveReaction.subscribe(e => {
        if (!sameStream(e) || e.type !== "create") return;
        setReactionTotal(n => n + 1);
      }),
      base44.entities.LiveViewer.subscribe(e => {
        if (!sameStream(e)) return;
        setViewers(n => {
          const next = Math.max(0, n + (e.type === "create" ? 1 : e.type === "delete" ? -1 : 0));
          if (next > peakRef.current) peakRef.current = next;
          return next;
        });
      }),
      base44.entities.LiveGift.subscribe(e => {
        if (!sameStream(e) || e.type !== "create") return;
        setGifts(g => (g.some(x => x.id === e.data.id) ? g : [...g, e.data]));
      }),
      base44.entities.LiveStream.subscribe(e => {
        if (String(e.data?.id) !== String(stream.id)) return;
        if (e.type === "update") {
          setStream(e.data);
          if (!e.data.is_live || e.data.status === "ended") setEnded(true);
        }
      }),
    ];
    return () => unsubs.forEach(u => u && u());
  }, [stream.id]);

  useEffect(() => {
    chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight, behavior: "smooth" });
  }, [comments.length]);

  const react = async (key) => {
    const id = Date.now() + Math.random();
    setHearts(h => [...h.slice(-10), { id, left: 65 + Math.random() * 25, emoji: REACTIONS[key] }]);
    setTimeout(() => setHearts(h => h.filter(x => x.id !== id)), 1300);
    await sendLiveReaction(stream.id, key).catch(() => {});
  };

  const sendComment = async (text) => {
    setSending(true);
    try {
      await addLiveComment(stream, text);
    } catch {
    } finally {
      setSending(false);
    }
  };

  const follow = async () => setFollowing(await toggleFollow(stream.host_name).catch(() => following));

  const sendGift = async (gift) => {
    setBusy(true);
    try {
      await sendLiveGift(stream, gift.key);
      setShowGifts(false);
    } catch {
    } finally {
      setBusy(false);
    }
  };

  const finish = async () => {
    setBusy(true);
    try {
      const updated = await endLive(stream, {
        peakViewers: peakRef.current,
        totalViews: peakRef.current,
      });
      setStream(updated);
      setEnded(true);
      onEnded?.(updated);
    } catch {
    } finally {
      setBusy(false);
    }
  };

  const reportStream = async () => {
    setMenuOpen(false);
    await reportContent({
      targetType: "live",
      targetId: stream.id,
      reason: "inappropriate",
      targetLabel: stream.title,
    }).catch(() => {});
  };

  const reportCreator = async () => {
    setMenuOpen(false);
    await reportContent({
      targetType: "user",
      targetId: stream.owner_id || stream.created_by_id,
      reason: "other",
      targetLabel: stream.host_name,
    }).catch(() => {});
  };

  const blockCreator = async () => {
    setMenuOpen(false);
    const nowBlocked = await toggleBlock(stream.host_name).catch(() => blocked);
    setBlocked(nowBlocked);
    if (nowBlocked) onClose();
  };

  const hideComment = async (c, hidden) => {
    try { await hideLiveComment(c.id, hidden); } catch {}
  };
  const removeComment = async (c) => {
    try { await deleteLiveComment(c.id); } catch {}
  };
  const blockCommenter = async (c) => {
    try {
      await blockViewerFromStream(stream, c.author_id);
      await toggleBlock(c.author_name).catch(() => {});
      const updated = { ...stream, blocked_viewer_ids: [...(stream.blocked_viewer_ids || []), c.author_id] };
      setStream(updated);
    } catch {}
  };
  const reportComment = async (c) => {
    await reportContent({
      targetType: "live_comment",
      targetId: c.id,
      reason: "harassment",
      targetLabel: c.text?.slice(0, 60) || "",
    }).catch(() => {});
  };

  // Comments from viewers the host has blocked are hidden for everyone
  // viewing this stream — the list is persisted on the stream record.
  const blockedIds = Array.isArray(stream.blocked_viewer_ids) ? stream.blocked_viewer_ids : [];
  const visibleComments = comments.filter(c => !c.author_id || !blockedIds.includes(c.author_id));

  const giftCoinsTotal = gifts.reduce((s, g) => s + giftCoins(g.gift_key), 0);

  return (
    <div className="fixed inset-0 z-[60] bg-black flex flex-col">
      {ended ? (
        <LiveEndedCard stream={stream} onBack={onClose} />
      ) : (
        <>
          {stream.video_url ? (
            <video
              src={stream.video_url}
              autoPlay
              loop
              muted={muted}
              playsInline
              className="absolute inset-0 w-full h-full object-cover"
              onClick={() => setMuted(!muted)}
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 to-black">
              <RefreshCw className="w-7 h-7 text-white/40 animate-spin mb-3" />
              <p className="text-white/60 text-sm">Waiting for the video feed</p>
              <p className="text-white/30 text-[11px] mt-1">The host has not connected a video source</p>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/80 pointer-events-none" />

          {/* Top bar */}
          <div className="relative z-10 flex items-center gap-2 p-4">
            <button onClick={onClose} aria-label="Close" className="w-10 h-10 rounded-full bg-black/40 backdrop-blur flex items-center justify-center shrink-0">
              <X className="w-5 h-5 text-white" />
            </button>
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-600 text-white text-[10px] font-bold uppercase shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> Live
            </span>
            <span className="flex items-center gap-1 text-white/90 text-xs font-medium ml-auto shrink-0">
              <Eye className="w-4 h-4" /> {formatCount(viewers)}
            </span>
            {isHost ? (
              <button
                onClick={finish}
                disabled={busy}
                className="px-3 py-2 rounded-full bg-rose-600 text-white text-xs font-bold flex items-center gap-1 shrink-0 disabled:opacity-50"
              >
                <Square className="w-3.5 h-3.5 fill-white" /> End
              </button>
            ) : (
              <button onClick={() => setMenuOpen(true)} aria-label="More options" className="w-9 h-9 rounded-full bg-black/40 backdrop-blur flex items-center justify-center shrink-0">
                <MoreVertical className="w-4 h-4 text-white" />
              </button>
            )}
          </div>

          {/* Creator row */}
          <div className="relative z-10 flex items-center gap-2.5 px-4">
            <img src={stream.host_avatar} alt="" className="w-10 h-10 rounded-full object-cover ring-2 ring-rose-500 shrink-0" />
            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-white text-sm font-bold truncate">{stream.host_name}</span>
                {verified && <BadgeCheck className="w-4 h-4 text-sky-400 shrink-0" />}
              </div>
              <div className="text-white/70 text-xs truncate">{stream.title}</div>
              {stream.channel_name && (
                <div className="text-white/50 text-[10px] truncate">{stream.channel_name}</div>
              )}
            </div>
            {!isHost && (
              <button
                onClick={follow}
                className={cn(
                  "ml-auto px-4 py-1.5 rounded-full text-xs font-semibold border transition shrink-0",
                  following ? "bg-white/10 border-white/20 text-white/70" : "bix-gradient text-white"
                )}
              >
                {following ? "Following" : "Follow"}
              </button>
            )}
          </div>

          {/* Creator controls — kept to the edge so the video stays visible */}
          {isHost && (
            <div className="relative z-10 flex items-center gap-2 px-4 mt-3 flex-wrap">
              <HostBtn icon={muted ? VolumeX : Volume2} label={muted ? "Unmute" : "Mute"} onClick={() => setMuted(!muted)} />
              <HostBtn icon={cameraOn ? Camera : CameraOff} label={cameraOn ? "Camera off" : "Camera on"} onClick={() => setCameraOn(!cameraOn)} />
              <HostBtn icon={RefreshCw} label="Switch" onClick={() => {}} />
              <HostBtn
                icon={commentsEnabled ? MessageSquareOff : MessageSquare}
                label={commentsEnabled ? "Comments off" : "Comments on"}
                onClick={async () => {
                  const next = !commentsEnabled;
                  const updated = await base44.entities.LiveStream
                    .update(stream.id, { comments_enabled: next }).catch(() => null);
                  if (updated) setStream(updated);
                }}
              />
            </div>
          )}

          {/* Bottom overlay */}
          <div className="relative z-10 mt-auto space-y-3 p-4">
            {gifts.length > 0 && (
              <div className="flex items-center gap-2 text-[11px] text-amber-300">
                <Gift className="w-3.5 h-3.5" />
                {formatCount(gifts.length)} gift{gifts.length === 1 ? "" : "s"}
                <span className="text-amber-400/70 flex items-center gap-0.5">
                  <Coins className="w-3 h-3" /> {formatCount(giftCoinsTotal)}
                </span>
              </div>
            )}

            <div ref={chatRef}>
              <LiveChat
                comments={visibleComments}
                canModerate={isHost}
                disabled={!commentsEnabled}
                sending={sending}
                onSend={sendComment}
                onHide={hideComment}
                onDelete={removeComment}
                onBlock={blockCommenter}
                onReport={reportComment}
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => react("heart")}
                aria-label="Send a heart"
                className="w-10 h-10 rounded-full bg-white/10 backdrop-blur flex items-center justify-center shrink-0"
              >
                <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
              </button>
              <div className="flex items-center gap-1 bg-white/10 backdrop-blur rounded-full px-2 py-1.5">
                {Object.entries(REACTIONS).slice(1).map(([key, emoji]) => (
                  <button key={key} onClick={() => react(key)} aria-label={key} className="text-lg px-1">
                    {emoji}
                  </button>
                ))}
              </div>
              {reactionTotal > 0 && (
                <span className="text-white/60 text-[11px] shrink-0">{formatCount(reactionTotal)}</span>
              )}
              <div className="ml-auto flex items-center gap-2 shrink-0">
                {!isHost && (
                  <button
                    onClick={() => setShowGifts(true)}
                    aria-label="Send a gift"
                    className="w-10 h-10 rounded-full bg-white/10 backdrop-blur flex items-center justify-center"
                  >
                    <Gift className="w-5 h-5 text-amber-400" />
                  </button>
                )}
                <button
                  onClick={() => setShowShare(true)}
                  aria-label="Share"
                  className="w-10 h-10 rounded-full bg-white/10 backdrop-blur flex items-center justify-center"
                >
                  <Share2 className="w-5 h-5 text-white/80" />
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Options menu */}
      {menuOpen && (
        <div className="absolute inset-0 z-20 bg-black/50" onClick={() => setMenuOpen(false)}>
          <div className="absolute bottom-0 inset-x-0 bg-card rounded-t-3xl p-4 space-y-1" onClick={e => e.stopPropagation()}>
            <MenuItem icon={Flag} label="Report this live" onClick={reportStream} />
            <MenuItem icon={Flag} label="Report the creator" onClick={reportCreator} />
            <MenuItem
              icon={Ban}
              label={blocked ? "Unblock creator" : "Block creator"}
              danger={!blocked}
              onClick={blockCreator}
            />
            <button onClick={() => setMenuOpen(false)} className="w-full py-3 mt-1 rounded-full bg-secondary text-sm font-semibold bix-press">
              Cancel
            </button>
          </div>
        </div>
      )}

      <AnimatePresence>
        {hearts.map(h => (
          <motion.div
            key={h.id}
            initial={{ opacity: 1, y: 0, scale: 0.6 }}
            animate={{ opacity: 0, y: -220, scale: 1.4 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.1, ease: "easeOut" }}
            className="absolute bottom-24 pointer-events-none text-2xl"
            style={{ left: `${h.left}%` }}
          >
            {h.emoji}
          </motion.div>
        ))}
      </AnimatePresence>

      <GiftSheet
        open={showGifts}
        onClose={() => setShowGifts(false)}
        onSend={sendGift}
        sending={busy}
        giftsEnabled={giftsEnabled}
      />
      <LiveShareSheet open={showShare} onClose={() => setShowShare(false)} stream={stream} />
    </div>
  );
}

function HostBtn({ icon: Icon, label, onClick }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur text-white/80 text-[11px] font-medium"
    >
      <Icon className="w-3.5 h-3.5" /> {label}
    </button>
  );
}

function MenuItem({ icon: Icon, label, onClick, danger }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-3 p-3 rounded-xl bg-secondary/50 bix-press">
      <Icon className={cn("w-4 h-4 shrink-0", danger ? "text-rose-400" : "text-muted-foreground")} />
      <span className={cn("text-sm font-medium", danger && "text-rose-400")}>{label}</span>
    </button>
  );
}