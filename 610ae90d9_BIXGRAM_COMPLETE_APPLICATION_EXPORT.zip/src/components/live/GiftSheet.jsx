import React from "react";
import { Gift, Coins } from "lucide-react";
import { GIFT_CATALOG } from "@/lib/live";
import { cn } from "@/lib/utils";

// Gift cost is never taken from the client — only the gift key is sent, and
// the price shown here is looked up from the shared catalog.
export default function GiftSheet({ open, onClose, onSend, sending, giftsEnabled }) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[80] bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
      <div className="w-full max-w-md bg-card rounded-t-3xl p-5" onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-2 mb-1">
          <Gift className="w-5 h-5 text-rose-400" />
          <h3 className="font-bold">Send a gift</h3>
        </div>
        <p className="text-[11px] text-muted-foreground mb-4">
          Gifts go to the creator. Coin purchases are not connected yet, so nothing is charged today.
        </p>

        {!giftsEnabled ? (
          <p className="text-sm text-muted-foreground py-6 text-center">
            The creator has turned gifts off for this live.
          </p>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            {GIFT_CATALOG.map(g => (
              <button
                key={g.key}
                disabled={sending}
                onClick={() => onSend(g)}
                className={cn(
                  "bix-card p-3 flex flex-col items-center gap-1 bix-press disabled:opacity-40"
                )}
              >
                <span className="text-2xl">{g.emoji}</span>
                <span className="text-[11px] font-semibold">{g.name}</span>
                <span className="flex items-center gap-1 text-[10px] text-amber-400">
                  <Coins className="w-3 h-3" /> {g.coins}
                </span>
              </button>
            ))}
          </div>
        )}

        <button onClick={onClose} className="w-full mt-4 py-3 rounded-full bg-secondary text-sm font-semibold bix-press">
          Close
        </button>
      </div>
    </div>
  );
}