import React from "react";
import { Link } from "react-router-dom";
import { Radio, User } from "lucide-react";

// Shown when a stream is no longer live, so the video area is never blank.
export default function LiveEndedCard({ stream, onBack }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center px-8 text-center bg-black">
      <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mb-4">
        <Radio className="w-7 h-7 text-white/70" />
      </div>
      <h3 className="text-white font-bold text-lg">Live ended</h3>
      <p className="text-white/60 text-sm mt-1">
        {stream.host_name}'s live stream has finished.
      </p>

      <div className="flex flex-col gap-2 w-full max-w-xs mt-6">
        <Link
          to={`/profile/${encodeURIComponent(stream.host_name)}`}
          className="w-full py-3 rounded-full bix-gradient text-white text-sm font-semibold flex items-center justify-center gap-2 bix-press"
        >
          <User className="w-4 h-4" /> View creator profile
        </Link>
        <button
          onClick={onBack}
          className="w-full py-3 rounded-full bg-white/10 text-white text-sm font-semibold bix-press"
        >
          Back to Live
        </button>
      </div>
    </div>
  );
}