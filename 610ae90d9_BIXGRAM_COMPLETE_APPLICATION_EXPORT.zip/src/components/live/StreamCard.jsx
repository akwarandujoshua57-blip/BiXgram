import React from "react";
import { Eye, Users, BadgeCheck } from "lucide-react";
import { Image } from "@/components/ui/image";
import { formatCount } from "@/lib/bixgram-data";

export default function StreamCard({ stream, verified, onSelect }) {
  return (
    <button onClick={() => onSelect(stream)} className="bix-card overflow-hidden text-left bix-press">
      <div className="relative">
        {stream.cover_url ? (
          <Image src={stream.cover_url} alt="" className="w-full h-40" />
        ) : (
          <div className="w-full h-40 bix-gradient opacity-40" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        <span className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-bold uppercase">
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> Live
        </span>
        <span className="absolute bottom-2 left-2 flex items-center gap-1 text-white text-[11px] font-medium">
          <Eye className="w-3.5 h-3.5" /> {formatCount(stream.viewers_count || 0)}
        </span>
        {stream.category && (
          <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded-full bg-black/50 text-white text-[10px] font-medium capitalize">
            {stream.category}
          </span>
        )}
      </div>
      <div className="p-2.5 flex items-start gap-2">
        <img
          src={stream.host_avatar}
          alt=""
          className="w-8 h-8 rounded-full object-cover ring-2 ring-rose-500/60 shrink-0"
        />
        <div className="min-w-0">
          <div className="flex items-center gap-1">
            <span className="text-xs font-semibold truncate">{stream.host_name}</span>
            {verified && <BadgeCheck className="w-3.5 h-3.5 text-primary shrink-0" />}
          </div>
          <div className="text-[10px] text-muted-foreground truncate">{stream.title}</div>
          {stream.channel_name && (
            <div className="text-[10px] text-primary truncate flex items-center gap-1">
              <Users className="w-3 h-3 shrink-0" /> {stream.channel_name}
            </div>
          )}
        </div>
      </div>
    </button>
  );
}