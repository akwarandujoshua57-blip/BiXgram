import React from "react";
import { Clock, Eye, MessageCircle, Heart, Gift, Coins, TrendingUp, Users } from "lucide-react";
import { formatCount } from "@/lib/bixgram-data";
import { formatDuration } from "@/lib/live";

// The creator's end-of-live summary. Every figure is derived from real rows
// created during the stream — zeros are shown as zeros, never invented.
export default function LiveSummarySheet({ open, summary, onClose }) {
  if (!open) return null;
  const s = summary || {};

  const rows = [
    { icon: Clock, label: "Duration", value: formatDuration(s.durationSeconds) },
    { icon: Users, label: "Peak viewers", value: formatCount(s.peakViewers || 0) },
    { icon: Eye, label: "Views", value: formatCount(s.totalViews || 0) },
    { icon: MessageCircle, label: "Comments", value: formatCount(s.comments || 0) },
    { icon: Heart, label: "Reactions", value: formatCount(s.reactions || 0) },
    { icon: Gift, label: "Gifts", value: formatCount(s.gifts || 0) },
    { icon: Coins, label: "Coins earned", value: formatCount(s.coins || 0) },
  ];

  return (
    <div className="fixed inset-0 z-[90] bg-black/70 backdrop-blur flex items-end justify-center">
      <div className="w-full max-w-md bg-card rounded-t-3xl p-5">
        <h3 className="font-extrabold text-lg text-center">Live summary</h3>
        <p className="text-xs text-muted-foreground text-center mt-1 mb-4">
          Your live has ended. These figures come from activity during this stream.
        </p>

        <div className="bix-card p-3 mb-3">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="text-xs text-muted-foreground">Estimated earnings</span>
          </div>
          <div className="text-2xl font-extrabold">
            {s.coins ? `${s.estimatedEarnings} coins` : "No Live earnings yet"}
          </div>
          <p className="text-[10px] text-muted-foreground mt-1">
            Estimated at the 70% creator share of gifts received. Not a settled payout.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-4">
          {rows.map(r => (
            <div key={r.label} className="bix-card p-3">
              <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                <r.icon className="w-3.5 h-3.5" />
                <span className="text-[10px]">{r.label}</span>
              </div>
              <div className="font-bold text-sm">{r.value}</div>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 rounded-full bix-gradient text-white text-sm font-semibold bix-press"
        >
          Done
        </button>
      </div>
    </div>
  );
}