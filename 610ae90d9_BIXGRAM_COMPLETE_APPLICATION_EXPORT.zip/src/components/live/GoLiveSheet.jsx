import React, { useEffect, useState } from "react";
import {
  X, Loader2, Image as ImageIcon, ShieldCheck, Calendar, Radio, Users,
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { LIVE_CATEGORIES, startLive, getLiveEligibility } from "@/lib/live";
import { uploadFile } from "@/lib/social";
import PremiumGate from "@/components/live/PremiumGate";
import { cn } from "@/lib/utils";

const field = "w-full bg-secondary/50 rounded-xl px-3.5 py-2.5 outline-none text-sm mt-1 focus:ring-1 focus:ring-primary/40";

export default function GoLiveSheet({ open, onClose, onCreated }) {
  const [eligibility, setEligibility] = useState(null);
  const [form, setForm] = useState({
    title: "", description: "", category: "talk",
    visibility: "public", comments: true, gifts: true, guests: false,
  });
  const [cover, setCover] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [scheduling, setScheduling] = useState(false);
  const [scheduledFor, setScheduledFor] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    getLiveEligibility().then(setEligibility).catch(() => setEligibility({ canGoLive: false }));
  }, [open]);

  if (!open) return null;

  if (eligibility && !eligibility.canGoLive) {
    return <PremiumGate onClose={onClose} />;
  }

  const pickCover = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) return setError("Please choose an image file");
    if (file.size > 5 * 1024 * 1024) return setError("Image must be 5MB or smaller");
    setError("");
    setUploading(true);
    try {
      setCover(await uploadFile(file));
    } catch {
      setError("Upload failed — try again");
    } finally {
      setUploading(false);
    }
  };

  const submit = async () => {
    if (!form.title.trim()) return setError("Give your live a title");
    if (scheduling && !scheduledFor) return setError("Choose a date and time");
    if (scheduling && new Date(scheduledFor).getTime() < Date.now()) return setError("Pick a time in the future");

    setSaving(true);
    setError("");
    try {
      if (scheduling) {
        const created = await base44.entities.LiveStream.create({
          ...(await baseFields()),
          is_live: false,
          status: "scheduled",
          scheduled_for: new Date(scheduledFor).toISOString(),
        });
        onCreated?.(created, true);
      } else {
        const created = await startLive({
          ...form,
          cover_url: cover,
          comments_enabled: form.comments,
          gifts_enabled: form.gifts,
          guests_enabled: form.guests,
        });
        onCreated?.(created, false);
      }
      setForm({ title: "", description: "", category: "talk", visibility: "public", comments: true, gifts: true, guests: false });
      setCover(null);
      setScheduling(false);
      setScheduledFor("");
      onClose();
    } catch (e) {
      setError(e?.message === "PREMIUM_REQUIRED" ? "Live streaming requires Bixgram Premium." : "Could not start the live. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  // Shared fields for a scheduled record — the record is created only after
  // the creator confirms, never while they are still configuring.
  const baseFields = async () => {
    const { getMe, getProfile, defaultAvatar } = await import("@/lib/social");
    const me = await getMe();
    const profile = await getProfile(me.name).catch(() => null);
    return {
      owner_id: me.id,
      host_name: me.name,
      host_username: profile?.username || me.name,
      host_avatar: profile?.avatar_url || defaultAvatar(me.name),
      title: form.title.trim(),
      description: form.description.trim(),
      category: form.category,
      cover_url: cover || "",
      visibility: form.visibility,
      comments_enabled: form.comments,
      gifts_enabled: form.gifts,
      guests_enabled: form.guests,
      peak_viewers: 0,
      total_views: 0,
    };
  };

  return (
    <div className="fixed inset-0 z-[70] bg-black/60 backdrop-blur flex items-end" onClick={onClose}>
      <div
        className="w-full max-w-2xl mx-auto bg-card border-t border-border rounded-t-2xl max-h-[92vh] overflow-y-auto overscroll-contain p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold flex items-center gap-2">
            <Radio className="w-5 h-5 text-rose-400" /> Go Live
          </h3>
          <button onClick={onClose} aria-label="Close" className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        <label className="cursor-pointer block">
          {cover ? (
            <img src={cover} alt="" className="w-full h-32 rounded-xl object-cover" />
          ) : (
            <div className="w-full h-32 rounded-xl bg-secondary/50 border border-dashed border-border flex flex-col items-center justify-center gap-1">
              {uploading ? <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /> : <ImageIcon className="w-5 h-5 text-muted-foreground" />}
              <span className="text-[11px] text-muted-foreground">Add a cover (optional)</span>
            </div>
          )}
          <input type="file" accept="image/*" hidden onChange={pickCover} />
        </label>

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Title</label>
        <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="What are you going live about?" className={field} maxLength={100} />

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Description (optional)</label>
        <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} className={cn(field, "resize-none")} maxLength={300} />

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Category</label>
        <div className="flex gap-2 overflow-x-auto no-scrollbar py-2">
          {LIVE_CATEGORIES.map(c => (
            <button
              key={c.key}
              onClick={() => setForm(f => ({ ...f, category: c.key }))}
              className={cn("px-3.5 py-1.5 rounded-full text-xs font-medium shrink-0 border transition",
                form.category === c.key ? "bix-gradient text-white border-transparent" : "border-border text-muted-foreground")}
            >
              {c.label}
            </button>
          ))}
        </div>

        <label className="text-xs font-semibold text-muted-foreground mt-2 block">Who can watch</label>
        <div className="flex gap-2 mt-1.5">
          {[["public", "Public"], ["private", "Private"]].map(([key, label]) => (
            <button
              key={key}
              onClick={() => setForm(f => ({ ...f, visibility: key }))}
              className={cn("px-3.5 py-1.5 rounded-full text-xs font-medium border transition",
                form.visibility === key ? "bix-gradient text-white border-transparent" : "border-border text-muted-foreground")}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="mt-3 space-y-1">
          <Toggle label="Comments" checked={form.comments} onChange={v => setForm(f => ({ ...f, comments: v }))} />
          <Toggle label="Gifts" checked={form.gifts} onChange={v => setForm(f => ({ ...f, gifts: v }))} />
          <Toggle label="Allow guest invites" checked={form.guests} onChange={v => setForm(f => ({ ...f, guests: v }))} />
        </div>

        <button onClick={() => setScheduling(v => !v)} className="flex items-center gap-1.5 mt-3 text-xs font-semibold text-primary">
          <Calendar className="w-4 h-4" /> {scheduling ? "Start now instead" : "Schedule for later"}
        </button>
        {scheduling && (
          <input
            type="datetime-local"
            value={scheduledFor}
            onChange={e => setScheduledFor(e.target.value)}
            className={field}
          />
        )}

        <div className="flex items-start gap-2 mt-3 p-3 rounded-xl bg-secondary/50">
          <ShieldCheck className="w-4 h-4 text-primary shrink-0 mt-0.5" />
          <p className="text-[11px] text-muted-foreground">
            Bixgram does not yet provide video broadcasting infrastructure. You can configure and schedule a live,
            and viewers can join the session, but no camera or streaming backend is connected.
          </p>
        </div>

        {error && <p className="text-xs text-rose-400 mt-3">{error}</p>}

        <button
          onClick={submit}
          disabled={saving || uploading}
          className="w-full py-3 mt-4 rounded-full bix-gradient text-white text-sm font-semibold disabled:opacity-40 bix-press"
        >
          {saving ? "Working…" : scheduling ? "Schedule live" : "Go Live"}
        </button>
      </div>
    </div>
  );
}

function Toggle({ label, checked, onChange }) {
  return (
    <button onClick={() => onChange(!checked)} className="w-full flex items-center justify-between p-2.5 rounded-xl bg-secondary/40">
      <span className="text-xs font-medium">{label}</span>
      <span className={cn("w-9 h-5 rounded-full transition relative", checked ? "bix-gradient" : "bg-secondary")}>
        <span className={cn("absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all", checked ? "left-[18px]" : "left-0.5")} />
      </span>
    </button>
  );
}