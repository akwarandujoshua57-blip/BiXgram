import React, { useState } from "react";
import { Send, MoreVertical, EyeOff, Eye, Trash2, Ban, Flag } from "lucide-react";

// Real comments only. Moderation actions are offered only to the stream owner
// (and are enforced by the database rules, not by hiding the buttons).
export default function LiveChat({
  comments, canModerate, disabled, sending,
  onSend, onHide, onDelete, onBlock, onReport,
}) {
  const [text, setText] = useState("");
  const [menuFor, setMenuFor] = useState(null);

  const submit = () => {
    const t = text.trim();
    if (!t || disabled || sending) return;
    onSend(t);
    setText("");
  };

  return (
    <div className="space-y-2">
      <div className="max-h-40 overflow-y-auto no-scrollbar space-y-2">
        {comments.length === 0 && (
          <p className="text-[11px] text-white/50">No comments yet</p>
        )}
        {comments.map(c => (
          <div key={c.id}>
            <div className="flex items-start gap-1.5">
              <img src={c.author_avatar} alt="" className="w-5 h-5 rounded-full object-cover shrink-0 mt-0.5" />
              <div className="min-w-0 flex-1 text-xs">
                <span className="font-semibold text-purple-300">{c.author_name}</span>
                <span className="text-white/90"> {c.text}</span>
                {c.is_hidden && <span className="text-white/40 italic"> (hidden)</span>}
              </div>
              {canModerate && (
                <button
                  onClick={() => setMenuFor(menuFor === c.id ? null : c.id)}
                  aria-label="Comment options"
                  className="text-white/60 shrink-0 p-1"
                >
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {menuFor === c.id && (
              <div className="flex flex-wrap gap-1.5 mt-1.5 ml-6">
                <ModBtn
                  icon={c.is_hidden ? Eye : EyeOff}
                  label={c.is_hidden ? "Unhide" : "Hide"}
                  onClick={() => { onHide(c, !c.is_hidden); setMenuFor(null); }}
                />
                <ModBtn icon={Trash2} label="Delete" onClick={() => { onDelete(c); setMenuFor(null); }} />
                <ModBtn icon={Ban} label="Block" onClick={() => { onBlock(c); setMenuFor(null); }} />
                <ModBtn icon={Flag} label="Report" onClick={() => { onReport(c); setMenuFor(null); }} />
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="flex items-center gap-2 bg-white/10 backdrop-blur rounded-full px-4 py-2.5">
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => e.key === "Enter" && submit()}
          disabled={disabled}
          placeholder={disabled ? "Comments are turned off" : "Say something…"}
          className="flex-1 min-w-0 bg-transparent outline-none text-sm text-white placeholder:text-white/50 disabled:cursor-not-allowed"
        />
        <button onClick={submit} disabled={disabled || sending || !text.trim()} className="disabled:opacity-40 shrink-0">
          <Send className="w-4 h-4 text-white/70" />
        </button>
      </div>
    </div>
  );
}

function ModBtn({ icon: Icon, label, onClick }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1 px-2 py-1 rounded-full bg-white/10 text-white/80 text-[10px] font-medium"
    >
      <Icon className="w-3 h-3" /> {label}
    </button>
  );
}