import React, { useState } from "react";
import { X, Trash2, Edit3, Flag, BadgeDollarSign } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import ReportSheet from "@/components/shared/ReportSheet";

export default function ListingActionsSheet({ listing, isMine, open, onClose, onUpdated, onDeleted }) {
  const [editing, setEditing] = useState(false);
  const [reporting, setReporting] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    title: listing.title || "",
    price: String(listing.price ?? ""),
    description: listing.description || "",
    location: listing.location || "",
  });
  const { toast } = useToast();

  if (!open) return null;

  const toggleSold = async () => {
    setBusy(true);
    try {
      const status = listing.status === "sold" ? "active" : "sold";
      await base44.entities.MarketplaceListing.update(listing.id, { status });
      toast({ title: status === "sold" ? "Marked as sold 🎉" : "Listing is active again" });
      onUpdated?.({ ...listing, status });
      onClose?.();
    } catch {
      toast({ title: "Could not update listing", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const del = async () => {
    setBusy(true);
    try {
      await base44.entities.MarketplaceListing.delete(listing.id);
      toast({ title: "Listing deleted" });
      onDeleted?.(listing);
      onClose?.();
    } catch {
      toast({ title: "Could not delete listing", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const saveEdit = async () => {
    const price = parseFloat(form.price);
    if (!form.title.trim()) { toast({ title: "Add a title", variant: "destructive" }); return; }
    if (!form.price || isNaN(price) || price <= 0) { toast({ title: "Enter a valid price", variant: "destructive" }); return; }
    setBusy(true);
    try {
      await base44.entities.MarketplaceListing.update(listing.id, {
        title: form.title.trim(),
        price,
        description: form.description.trim(),
        location: form.location.trim(),
      });
      toast({ title: "Listing updated" });
      onUpdated?.({ ...listing, title: form.title.trim(), price, description: form.description.trim(), location: form.location.trim() });
      onClose?.();
    } catch {
      toast({ title: "Could not update listing", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
        <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-1" onClick={e => e.stopPropagation()}>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-lg truncate max-w-[80%]">{listing.title}</h3>
            <button onClick={onClose} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
              <X className="w-4 h-4" />
            </button>
          </div>

          {isMine ? (
            <>
              <button onClick={toggleSold} disabled={busy} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-secondary/50 transition text-left disabled:opacity-50">
                <BadgeDollarSign className="w-5 h-5 text-primary" />
                <span className="font-medium text-sm">{listing.status === "sold" ? "Relist (mark active)" : "Mark as sold"}</span>
              </button>
              <button onClick={() => setEditing(true)} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-secondary/50 transition text-left">
                <Edit3 className="w-5 h-5 text-primary" />
                <span className="font-medium text-sm">Edit listing</span>
              </button>
              <button onClick={del} disabled={busy} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-rose-500/10 transition text-left disabled:opacity-50">
                <Trash2 className="w-5 h-5 text-rose-400" />
                <span className="font-medium text-sm text-rose-400">Delete listing</span>
              </button>
            </>
          ) : (
            <button onClick={() => setReporting(true)} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-rose-500/10 transition text-left">
              <Flag className="w-5 h-5 text-rose-400" />
              <span className="font-medium text-sm text-rose-400">Report listing</span>
            </button>
          )}

          <button onClick={onClose} className="w-full p-3 text-center text-sm text-muted-foreground">Cancel</button>
        </div>
      </div>

      {editing && (
        <div className="fixed inset-0 z-[70] bg-black/60 backdrop-blur flex items-end justify-center" onClick={() => setEditing(false)}>
          <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-3 max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-lg">Edit listing</h3>
            <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Title *" className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none" />
            <input value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="Price ($) *" inputMode="decimal" className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none" />
            <input value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="Location" className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none" />
            <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} placeholder="Description" className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none resize-none" />
            <button onClick={saveEdit} disabled={busy} className="w-full py-3 rounded-xl bix-gradient text-white font-semibold disabled:opacity-50">
              {busy ? "Saving…" : "Save changes"}
            </button>
          </div>
        </div>
      )}

      <ReportSheet
        open={reporting}
        onClose={() => { setReporting(false); onClose?.(); }}
        targetType="listing"
        targetId={listing.id}
        targetLabel={listing.title}
      />
    </>
  );
}