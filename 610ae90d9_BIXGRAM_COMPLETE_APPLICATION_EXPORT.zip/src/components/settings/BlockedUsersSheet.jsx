import React, { useState, useEffect } from "react";
import { X, Ban } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getMe, defaultAvatar } from "@/lib/social";

export default function BlockedUsersSheet({ open, onClose }) {
  const [blocked, setBlocked] = useState([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    if (!open) return;
    setLoading(true);
    try {
      const me = await getMe();
      setBlocked(await base44.entities.BlockedUser.filter({ user_name: me.name }));
    } catch {
      setBlocked([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [open]);

  if (!open) return null;

  const unblock = async (b) => {
    await base44.entities.BlockedUser.delete(b.id).catch(() => {});
    setBlocked(bs => bs.filter(x => x.id !== b.id));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
      <div className="w-full max-w-md bg-card rounded-t-3xl flex flex-col" style={{ maxHeight: "70vh" }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h3 className="font-bold flex items-center gap-2"><Ban className="w-5 h-5 text-rose-400" /> Blocked Users</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {loading ? (
            <div className="flex justify-center py-10">
              <div className="w-7 h-7 border-4 border-secondary border-t-primary rounded-full animate-spin" />
            </div>
          ) : blocked.length === 0 ? (
            <div className="text-center py-10 text-sm text-muted-foreground">
              You haven't blocked anyone 🎉
            </div>
          ) : blocked.map(b => (
            <div key={b.id} className="flex items-center gap-3 p-3 rounded-2xl hover:bg-secondary/40">
              <img src={defaultAvatar(b.blocked_name)} alt="" className="w-10 h-10 rounded-full object-cover" />
              <span className="flex-1 font-semibold text-sm">{b.blocked_name}</span>
              <button onClick={() => unblock(b)} className="px-4 py-1.5 rounded-full bg-secondary text-xs font-semibold">
                Unblock
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}