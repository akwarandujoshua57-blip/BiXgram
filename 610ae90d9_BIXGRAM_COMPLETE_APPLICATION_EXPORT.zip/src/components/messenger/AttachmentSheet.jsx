import React from "react";
import { Camera, Image as ImageIcon, Video, FileText, Sparkles, X } from "lucide-react";

// Attachment / action menu. Rendered directly above the composer inside the chat
// column, so it always sits above the system keyboard instead of behind it.
const ACTIONS = [
  { key: "camera", label: "Camera", Icon: Camera, tint: "text-cyan-400" },
  { key: "photo", label: "Photos", Icon: ImageIcon, tint: "text-emerald-400" },
  { key: "video", label: "Video", Icon: Video, tint: "text-purple-400" },
  { key: "file", label: "Document", Icon: FileText, tint: "text-amber-400" },
  { key: "sticker", label: "Sticker", Icon: Sparkles, tint: "text-pink-400" },
];

export default function AttachmentSheet({ onPick, onClose }) {
  return (
    <div className="border-t border-border bg-card/95 backdrop-blur-xl px-4 pt-4 pb-3">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Send</span>
        <button onClick={onClose} aria-label="Close attachments" className="w-7 h-7 rounded-full bg-secondary/60 flex items-center justify-center">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {ACTIONS.map(({ key, label, Icon, tint }) => (
          <button
            key={key}
            onClick={() => onPick(key)}
            className="shrink-0 w-[72px] flex flex-col items-center gap-2 py-2 rounded-2xl hover:bg-secondary/60 transition bix-press"
          >
            <span className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center">
              <Icon className={`w-5 h-5 ${tint}`} />
            </span>
            <span className="text-[11px] text-muted-foreground">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}