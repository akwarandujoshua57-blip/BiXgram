import React, { useState, useRef, useEffect } from "react";
import { Plus, Smile, Mic, Send, X, Square, CornerUpLeft, Image as ImageIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import AttachmentSheet from "@/components/messenger/AttachmentSheet";
import EmojiStickerPicker from "@/components/messenger/EmojiStickerPicker";

const MAX_INPUT_HEIGHT = 116; // px — roughly 5 lines, then it scrolls

const isTouch = () =>
  typeof window !== "undefined" && window.matchMedia?.("(hover: none)").matches;

// The message composer.
//
// It is anchored to the bottom of the chat column and never reserves space for
// the keyboard — pickers and menus render above it inside the same column, so
// whatever the device does with its keyboard, the composer simply follows.
export default function Composer({
  onSendText,
  onSendMedia,
  onSendVoice,
  onSendSticker,
  replyTo,
  onCancelReply,
  uploading = false,
  disabled = false,
}) {
  const [text, setText] = useState("");
  const [panel, setPanel] = useState(null); // null | "attach" | "emoji" | "stickers"
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [busy, setBusy] = useState(false);

  const taRef = useRef(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);
  const streamRef = useRef(null);
  const cancelledRef = useRef(false);
  const startedAtRef = useRef(0);
  const photoRef = useRef(null);
  const videoRef = useRef(null);
  const fileRef = useRef(null);
  const cameraRef = useRef(null);

  const voiceSupported =
    typeof navigator !== "undefined" && navigator.mediaDevices && typeof window.MediaRecorder !== "undefined";

  // Auto-grow the input up to a sensible maximum, then let it scroll.
  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, MAX_INPUT_HEIGHT)}px`;
  }, [text]);

  useEffect(() => {
    if (!recording) return;
    const t = setInterval(() => setSeconds(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [recording]);

  const hasText = text.trim().length > 0;

  const openPanel = (next) => {
    setPanel(p => (p === next ? null : next));
    // Let the picker take the keyboard's place instead of stacking on top of it.
    taRef.current?.blur();
  };

  const focusInput = () => {
    setPanel(null);
    taRef.current?.focus();
  };

  const send = async () => {
    const t = text.trim();
    if (!t || disabled || busy) return;
    setBusy(true);
    try {
      await onSendText(t);
      setText("");
      setPanel(null);
    } finally {
      setBusy(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key !== "Enter") return;
    // On touch devices Enter makes a new line; the send button sends.
    if (isTouch() || e.shiftKey) return;
    e.preventDefault();
    send();
  };

  const pickFile = async (e, kind) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setPanel(null);
    await onSendMedia(file, kind);
  };

  const startRecording = async () => {
    if (!voiceSupported || recording) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      cancelledRef.current = false;
      chunksRef.current = [];
      const rec = new MediaRecorder(stream);
      rec.ondataavailable = (ev) => ev.data.size > 0 && chunksRef.current.push(ev.data);
      rec.onstop = async () => {
        streamRef.current?.getTracks().forEach(t => t.stop());
        streamRef.current = null;
        const wasCancelled = cancelledRef.current;
        const elapsed = Math.max(1, Math.round((Date.now() - startedAtRef.current) / 1000));
        setRecording(false);
        setSeconds(0);
        if (wasCancelled) return;
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        if (blob.size === 0) return;
        await onSendVoice(new File([blob], "voice-message.webm", { type: blob.type }), elapsed);
      };
      recorderRef.current = rec;
      startedAtRef.current = Date.now();
      setSeconds(0);
      setPanel(null);
      rec.start();
      setRecording(true);
    } catch {
      onSendVoice(null, 0);
    }
  };

  const finishRecording = () => { cancelledRef.current = false; recorderRef.current?.stop(); };
  const cancelRecording = () => { cancelledRef.current = true; recorderRef.current?.stop(); };

  const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  const iconBtn = "w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition bix-press";

  return (
    <div className="shrink-0 border-t border-border bg-card/95 backdrop-blur-xl pb-[env(safe-area-inset-bottom)]">
      {replyTo && (
        <div className="flex items-center gap-2 px-3 pt-2.5">
          <div className="flex-1 min-w-0 flex items-center gap-2 bg-secondary/60 rounded-xl px-3 py-2 border-l-2 border-primary">
            <CornerUpLeft className="w-3.5 h-3.5 text-primary shrink-0" />
            <div className="min-w-0">
              <div className="text-[11px] font-semibold text-primary truncate">{replyTo.author}</div>
              <div className="text-[11px] text-muted-foreground truncate">{replyTo.preview}</div>
            </div>
          </div>
          <button onClick={onCancelReply} aria-label="Cancel reply" className={cn(iconBtn, "bg-secondary/60")}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {panel === "attach" && (
        <AttachmentSheet
          onClose={() => setPanel(null)}
          onPick={(key) => {
            if (key === "camera") cameraRef.current?.click();
            else if (key === "photo") photoRef.current?.click();
            else if (key === "video") videoRef.current?.click();
            else if (key === "file") fileRef.current?.click();
            else if (key === "sticker") setPanel("stickers");
          }}
        />
      )}
      {(panel === "emoji" || panel === "stickers") && (
        <EmojiStickerPicker
          tab={panel}
          onTab={setPanel}
          onEmoji={(e) => {
            setText(t => t + e);
            taRef.current?.focus();
          }}
        />
      )}

      {recording ? (
        <div className="flex items-center gap-3 px-3 py-2.5">
          <button onClick={cancelRecording} aria-label="Cancel recording" className={cn(iconBtn, "bg-secondary/60")}>
            <X className="w-4 h-4 text-rose-400" />
          </button>
          <div className="flex-1 min-w-0 flex items-center gap-2.5 bg-secondary/60 rounded-full px-4 py-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse shrink-0" />
            <span className="text-sm font-semibold tabular-nums shrink-0">{fmt(seconds)}</span>
            <span className="text-xs text-muted-foreground truncate">Recording…</span>
          </div>
          <button
            onClick={finishRecording}
            aria-label="Send voice message"
            className="w-10 h-10 rounded-full bix-gradient flex items-center justify-center shrink-0 bix-glow"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      ) : (
        <div className="flex items-end gap-1.5 px-2.5 py-2.5">
          <button
            onClick={() => openPanel("attach")}
            aria-label="Add attachment"
            aria-expanded={panel === "attach"}
            className={cn(iconBtn, "bg-secondary/60", panel === "attach" && "bix-gradient text-white")}
          >
            <Plus className={cn("w-5 h-5", panel === "attach" ? "text-white" : "text-primary")} />
          </button>

          <div className="flex-1 min-w-0 flex items-end gap-1 bg-secondary/50 rounded-3xl pl-3.5 pr-1.5 py-1">
            <textarea
              ref={taRef}
              rows={1}
              value={text}
              onChange={e => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              onFocus={() => setPanel(null)}
              placeholder="Message…"
              disabled={disabled}
              className="flex-1 min-w-0 bg-transparent outline-none resize-none text-sm py-2 max-h-[116px] overflow-y-auto placeholder:text-muted-foreground"
            />
            {!hasText && (
              <button
                onClick={() => openPanel("emoji")}
                aria-label="Emoji and stickers"
                className={cn(iconBtn, "w-8 h-8", panel === "emoji" || panel === "stickers" ? "text-primary" : "text-muted-foreground")}
              >
                <Smile className="w-[19px] h-[19px]" />
              </button>
            )}
            {uploading && <span className="text-[10px] text-muted-foreground shrink-0 py-2">…</span>}
          </div>

          {hasText ? (
            <button
              onClick={send}
              disabled={busy || disabled}
              aria-label="Send message"
              className="w-10 h-10 rounded-full bix-gradient flex items-center justify-center shrink-0 bix-glow disabled:opacity-50"
            >
              <Send className="w-[18px] h-[18px] text-white" />
            </button>
          ) : voiceSupported ? (
            <button onClick={startRecording} aria-label="Record voice message" className={cn(iconBtn, "bg-secondary/60")}>
              <Mic className="w-[19px] h-[19px] text-primary" />
            </button>
          ) : (
            <button onClick={focusInput} aria-label="Message" className={cn(iconBtn, "bg-secondary/60")}>
              <ImageIcon className="w-[19px] h-[19px] text-primary" />
            </button>
          )}
        </div>
      )}

      <input ref={cameraRef} type="file" accept="image/*" capture="environment" hidden onChange={e => pickFile(e, "image")} />
      <input ref={photoRef} type="file" accept="image/*" hidden onChange={e => pickFile(e, "image")} />
      <input ref={videoRef} type="file" accept="video/*" hidden onChange={e => pickFile(e, "video")} />
      <input ref={fileRef} type="file" hidden onChange={e => pickFile(e, "file")} />
    </div>
  );
}