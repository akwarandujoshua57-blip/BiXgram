import React, { useState } from "react";
import { Smile, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

// A compact, curated emoji set — real Unicode characters, no invented data.
const EMOJI = [
  "😀","😂","🥰","😍","😎","🤩","😊","🙌","👏","🙏","💪","🔥",
  "❤️","💙","💜","✨","🎉","😭","😅","🤔","😴","👍","👀","💯",
  "🌟","🎶","☀️","🌙","🍕","☕","⚽","🎮","📸","✈️","🌈","💫",
];

// Stickers have no packs in the database yet, so this shows an honest empty
// state rather than inventing sticker content.
export default function EmojiStickerPicker({ tab, onTab, onEmoji }) {
  const [inner, setInner] = useState(tab || "emoji");
  const active = onTab ? tab : inner;
  const setActive = onTab || setInner;

  return (
    <div className="border-t border-border bg-card/95 backdrop-blur-xl">
      <div className="flex items-center gap-1 px-3 pt-2.5">
        <button
          onClick={() => setActive("emoji")}
          className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition",
            active === "emoji" ? "bix-gradient text-white" : "text-muted-foreground hover:bg-secondary/60")}
        >
          <Smile className="w-3.5 h-3.5" /> Emoji
        </button>
        <button
          onClick={() => setActive("stickers")}
          className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition",
            active === "stickers" ? "bix-gradient text-white" : "text-muted-foreground hover:bg-secondary/60")}
        >
          <Sparkles className="w-3.5 h-3.5" /> Stickers
        </button>
      </div>

      {active === "emoji" ? (
        <div className="grid grid-cols-8 gap-1 px-3 py-3 max-h-[190px] overflow-y-auto overscroll-contain">
          {EMOJI.map((e, i) => (
            <button
              key={`${e}-${i}`}
              onClick={() => onEmoji(e)}
              className="aspect-square rounded-xl hover:bg-secondary/70 flex items-center justify-center text-xl bix-press"
            >
              {e}
            </button>
          ))}
        </div>
      ) : (
        <div className="px-6 py-8 text-center">
          <div className="w-12 h-12 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
            <Sparkles className="w-5 h-5 text-muted-foreground" />
          </div>
          <p className="text-sm font-semibold">No sticker packs yet</p>
          <p className="text-xs text-muted-foreground mt-1">Sticker packs will appear here once they're available.</p>
        </div>
      )}
    </div>
  );
}