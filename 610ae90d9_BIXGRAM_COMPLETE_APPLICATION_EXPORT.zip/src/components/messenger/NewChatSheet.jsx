import React, { useState, useEffect } from "react";
import { X, Search, Check, Users } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getMe } from "@/lib/social";
import { cn } from "@/lib/utils";

export default function NewChatSheet({ open, onClose, onStart, onGroup }) {
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState([]);
  const [selected, setSelected] = useState([]);
  const [groupName, setGroupName] = useState("");
  const [showName, setShowName] = useState(false);

  useEffect(() => {
    if (!open) return;
    setSelected([]);
    setGroupName("");
    setShowName(false);
    setQuery("");
    (async () => {
      let me = null;
      try { me = await getMe(); } catch {}
      try {
        const profiles = await base44.entities.Profile.list(100);
        setUsers(profiles
          .filter(p => p.username !== me?.name)
          .map(p => ({ username: p.username, avatar_url: p.avatar_url })));
      } catch {
        setUsers([]);
      }
    })();
  }, [open]);

  if (!open) return null;

  const filtered = users.filter(u => u.username.toLowerCase().includes(query.toLowerCase()));

  const toggle = (u) => {
    setSelected(sel => {
      const exists = sel.find(s => s.username === u.username);
      const next = exists ? sel.filter(s => s.username !== u.username) : [...sel, u];
      if (next.length < 2) setShowName(false);
      return next;
    });
  };

  const start = () => {
    if (selected.length === 1) {
      onStart(selected[0].username);
      onClose();
    } else if (selected.length >= 2) {
      if (!showName) { setShowName(true); return; }
      const name = groupName.trim() || `Group of ${selected.length + 1}`;
      onGroup(name, selected.map(s => s.username));
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end justify-center" onClick={onClose}>
      <div className="w-full max-w-md bg-card rounded-t-3xl flex flex-col" style={{ maxHeight: "80vh" }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h3 className="font-bold">{selected.length >= 2 ? "New group chat" : "New message"}</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-3 pb-0">
          <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2.5">
            <Search className="w-4 h-4 text-muted-foreground" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder={selected.length >= 2 ? "Group name…" : "Search people…"}
              className="flex-1 bg-transparent outline-none text-sm"
            />
          </div>
          {selected.length >= 2 && !showName && (
            <div className="flex gap-1.5 flex-wrap mt-2">
              {selected.map(s => (
                <span key={s.username} className="px-2 py-1 rounded-full bg-primary/10 text-primary text-[10px] font-semibold">{s.username}</span>
              ))}
            </div>
          )}
          {showName && (
            <input
              value={groupName}
              onChange={e => setGroupName(e.target.value)}
              placeholder="Group name (optional)"
              autoFocus
              className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none mt-2"
            />
          )}
        </div>
        <div className="flex-1 overflow-y-auto px-2 py-3">
          {filtered.map(u => {
            const isSel = selected.some(s => s.username === u.username);
            return (
              <button
                key={u.username}
                onClick={() => toggle(u)}
                className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-secondary/40 transition text-left"
              >
                <div className="relative shrink-0">
                  <img src={u.avatar_url} alt="" className="w-11 h-11 rounded-full object-cover" />
                  {isSel && (
                    <span className="absolute inset-0 rounded-full bg-primary/40 flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" strokeWidth={3} />
                    </span>
                  )}
                </div>
                <div>
                  <div className="font-semibold text-sm">{u.username}</div>
                  <div className="text-xs text-muted-foreground">@{u.username.replace(/\s+/g, "").toLowerCase()}</div>
                </div>
              </button>
            );
          })}
          {filtered.length === 0 && (
            <div className="text-center py-8 text-sm text-muted-foreground">No people found</div>
          )}
        </div>
        <div className="p-3 border-t border-border safe-bottom">
          <button
            onClick={start}
            disabled={selected.length === 0}
            className={cn(
              "w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-40",
              selected.length >= 2 ? "bix-gradient text-white" : "bg-secondary"
            )}
          >
            {selected.length >= 2
              ? <><Users className="w-4 h-4" /> {showName ? "Create Group" : `Create Group (${selected.length + 1})`}</>
              : selected.length === 1 ? "Start Chat" : "Select people"}
          </button>
        </div>
      </div>
    </div>
  );
}