import React, { useState, useEffect, useRef } from "react";
import { Search, Plus, Pin, PinOff, BellOff, EyeOff, UserX, Flag, Bot, Sparkles, MessageCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { getMe, toggleBlock, reportContent } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export default function MessageTab({ onOpen, onNew }) {
  const [convos, setConvos] = useState([]);
  const [me, setMe] = useState(null);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [actionsFor, setActionsFor] = useState(null);
  const pressTimer = useRef(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  const load = async () => {
    try {
      const rows = await base44.entities.Conversation.list("-updated_date", 50);
      setConvos(rows);
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    (async () => {
      try { setMe(await getMe()); } catch {}
      await load();
    })();
  }, []);

  const visible = convos
    .filter(c => !(me && (c.hidden_for || []).includes(me.id)))
    .filter(c => c.participant_name?.toLowerCase().includes(query.trim().toLowerCase()))
    .sort((a, b) => Number(!!b.is_pinned) - Number(!!a.is_pinned));

  const patch = async (c, data) => {
    setActionsFor(null);
    setConvos(cs => cs.map(x => (x.id === c.id ? { ...x, ...data } : x)));
    await base44.entities.Conversation.update(c.id, data).catch(() => {});
  };

  const startPress = (c) => {
    clearTimeout(pressTimer.current);
    pressTimer.current = setTimeout(() => setActionsFor(c), 450);
  };
  const endPress = () => clearTimeout(pressTimer.current);

  const doBlock = async (c) => {
    setActionsFor(null);
    const now = await toggleBlock(c.participant_name).catch(() => false);
    toast({ title: now ? `Blocked ${c.participant_name}` : `Unblocked ${c.participant_name}` });
  };

  const doReport = async (c) => {
    setActionsFor(null);
    await reportContent({
      targetType: "user", targetId: c.id, reason: "other",
      targetLabel: c.participant_name, details: "Reported from Messenger",
    }).catch(() => {});
    toast({ title: "Report submitted", description: "Our team will review this." });
  };

  return (
    <div className="p-2">
      <div className="px-2 pb-2">
        <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2.5">
          <Search className="w-[18px] h-[18px] text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search conversations"
            className="flex-1 min-w-0 bg-transparent outline-none text-sm"
          />
        </div>
      </div>

      <button
        onClick={() => navigate("/bix-ai")}
        className="w-full flex items-center gap-3 p-3 mb-1.5 rounded-2xl bix-card text-left bix-press"
      >
        <div className="w-[52px] h-[52px] rounded-full bix-gradient flex items-center justify-center bix-glow shrink-0">
          <Bot className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-sm bix-gradient-text">BIX AI</div>
          <p className="text-xs text-muted-foreground truncate">Captions, ideas, rewrites & more ✨</p>
        </div>
        <Sparkles className="w-5 h-5 text-primary shrink-0" />
      </button>

      {loading ? (
        <div className="p-2 space-y-2">
          {[0, 1, 2, 3].map(i => <div key={i} className="h-[68px] rounded-2xl bix-skeleton" />)}
        </div>
      ) : visible.length === 0 ? (
        <div className="text-center py-14 px-6">
          <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
            <MessageCircle className="w-6 h-6 text-muted-foreground" />
          </div>
          <p className="font-semibold text-sm">{query.trim() ? "No matches" : "No conversations yet"}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {query.trim() ? "Try a different name." : "Start a private chat with someone you know."}
          </p>
          {!query.trim() && (
            <button onClick={onNew} className="mt-4 px-5 py-2.5 rounded-full bix-gradient text-white text-sm font-semibold bix-press">
              New message
            </button>
          )}
        </div>
      ) : (
        visible.map(c => (
          <div key={c.id} className="relative">
            <button
              onPointerDown={() => startPress(c)}
              onPointerUp={endPress}
              onPointerLeave={endPress}
              onPointerCancel={endPress}
              onContextMenu={(e) => { e.preventDefault(); setActionsFor(c); }}
              onClick={() => onOpen(c)}
              className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-secondary/40 transition text-left"
            >
              <img src={c.participant_avatar} alt="" className="w-[52px] h-[52px] rounded-full object-cover shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 min-w-0">
                  {c.is_pinned && <Pin className="w-3 h-3 text-primary shrink-0" />}
                  <span className="font-semibold text-sm truncate">{c.participant_name}</span>
                  {c.is_muted && <BellOff className="w-3 h-3 text-muted-foreground shrink-0" />}
                  {c.is_group && (
                    <span className="text-[10px] bg-secondary px-1.5 py-0.5 rounded-full text-muted-foreground shrink-0">Group</span>
                  )}
                </div>
                <p className={cn("text-xs truncate", c.unread_count > 0 ? "text-foreground font-medium" : "text-muted-foreground")}>
                  {c.last_message || "Say hi 👋"}
                </p>
              </div>
              <div className="text-right shrink-0">
                <div className="text-[10px] text-muted-foreground">{c.last_message_time}</div>
                {c.unread_count > 0 && (
                  <div className="mt-1 ml-auto w-5 h-5 rounded-full bix-gradient text-white text-[10px] font-bold flex items-center justify-center">
                    {c.unread_count > 9 ? "9+" : c.unread_count}
                  </div>
                )}
              </div>
            </button>
          </div>
        ))
      )}

      {actionsFor && (
        <div className="fixed inset-0 z-[60] bg-black/50 flex items-end" onClick={() => setActionsFor(null)}>
          <div
            className="w-full max-w-2xl mx-auto bg-card border-t border-border rounded-t-2xl p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 px-2 pb-3 mb-1 border-b border-border">
              <img src={actionsFor.participant_avatar} alt="" className="w-10 h-10 rounded-full object-cover" />
              <span className="font-semibold text-sm truncate">{actionsFor.participant_name}</span>
            </div>
            <button onClick={() => patch(actionsFor, { is_pinned: !actionsFor.is_pinned })}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-secondary/60 text-sm">
              {actionsFor.is_pinned ? <PinOff className="w-4 h-4 text-muted-foreground" /> : <Pin className="w-4 h-4 text-muted-foreground" />}
              {actionsFor.is_pinned ? "Unpin" : "Pin to top"}
            </button>
            <button onClick={() => patch(actionsFor, { is_muted: !actionsFor.is_muted })}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-secondary/60 text-sm">
              <BellOff className="w-4 h-4 text-muted-foreground" />
              {actionsFor.is_muted ? "Unmute" : "Mute"}
            </button>
            <button onClick={() => patch(actionsFor, { hidden_for: [...new Set([...(actionsFor.hidden_for || []), me?.id].filter(Boolean))] })}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-secondary/60 text-sm">
              <EyeOff className="w-4 h-4 text-muted-foreground" /> Remove from my inbox
            </button>
            <button onClick={() => doBlock(actionsFor)} className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-secondary/60 text-sm">
              <UserX className="w-4 h-4 text-muted-foreground" /> Block
            </button>
            <button onClick={() => doReport(actionsFor)} className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-secondary/60 text-sm text-rose-400">
              <Flag className="w-4 h-4" /> Report
            </button>
          </div>
        </div>
      )}
    </div>
  );
}