import React, { useState, useEffect, useRef, useCallback } from "react";
import { ArrowLeft, Phone, Video, Search, MoreVertical, Users, Lock, LockOpen, CornerUpLeft, X, BellOff, UserX, Flag, EyeOff } from "lucide-react";
import moment from "moment";
import { base44 } from "@/api/base44Client";
import { getMe, getProfile, toggleBlock, reportContent, notify } from "@/lib/social";
import { ensureOwnKeys, getSharedKey, encryptText, decryptText, isEncrypted } from "@/lib/e2ee";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";
import useKeyboardInset from "@/hooks/use-keyboard-inset";
import Composer from "@/components/messenger/Composer";
import MessageBubble, { REACTIONS } from "@/components/messenger/MessageBubble";

const PAGE = 30;
const NEAR_BOTTOM = 140;

export default function ChatView({ convo, onBack, onStartCall }) {
  const [messages, setMessages] = useState([]);
  const [me, setMe] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [e2ee, setE2ee] = useState(null);
  const [decrypted, setDecrypted] = useState({});
  const [replyTo, setReplyTo] = useState(null);
  const [actionsFor, setActionsFor] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [limit, setLimit] = useState(PAGE);
  const [pendingNew, setPendingNew] = useState(0);
  const [muted, setMuted] = useState(!!convo.is_muted);

  const inset = useKeyboardInset();
  const scrollRef = useRef(null);
  const endRef = useRef(null);
  const atBottomRef = useRef(true);
  const restoreRef = useRef(null);
  const { toast } = useToast();

  const loadMessages = useCallback(async () => {
    const db = await base44.entities.Message
      .filter({ conversation_id: convo.id }, "-created_date", limit)
      .catch(() => []);
    setMessages([...db].reverse());
  }, [convo.id, limit]);

  // Initial load: recent messages first, plus this device's E2EE key material.
  useEffect(() => {
    let alive = true;
    (async () => {
      let m = null;
      try { m = await getMe(); if (alive) setMe(m); } catch {}
      await loadMessages();
      if (!alive) return;
      requestAnimationFrame(() => endRef.current?.scrollIntoView({ block: "end" }));

      if (m && !convo.is_group) {
        try {
          const keys = await ensureOwnKeys(m.id);
          const own = await getProfile(m.name);
          if (!own.e2ee_public_key && own.id) {
            await base44.entities.Profile.update(own.id, { e2ee_public_key: JSON.stringify(keys.pub) }).catch(() => {});
          }
          const other = await getProfile(convo.participant_name);
          setE2ee(
            other?.e2ee_public_key
              ? { key: await getSharedKey(m.id, keys.priv, JSON.parse(other.e2ee_public_key)) }
              : { key: null }
          );
        } catch {
          if (alive) setE2ee({ key: null });
        }
      }
    })();
    return () => { alive = false; };
  }, [convo.id, loadMessages]);

  // Load older messages when the user scrolls back, keeping their place.
  useEffect(() => {
    if (limit === PAGE) return;
    const el = scrollRef.current;
    if (!el || !restoreRef.current) return;
    el.scrollTop = el.scrollHeight - restoreRef.current;
    restoreRef.current = null;
  }, [messages, limit]);

  // Realtime: incoming messages arrive instantly. The subscription is torn down
  // when the conversation closes so no duplicate listeners are left behind.
  useEffect(() => {
    const unsub = base44.entities.Message.subscribe((ev) => {
      if (ev.type !== "create" || ev.data?.conversation_id !== convo.id) return;
      setMessages(ms => (ms.some(x => x.id === ev.data.id) ? ms : [...ms, ev.data]));
      if (atBottomRef.current) requestAnimationFrame(() => endRef.current?.scrollIntoView({ block: "end" }));
      else setPendingNew(n => n + 1);
    });
    return unsub;
  }, [convo.id]);

  // Mark the other person's messages as read — this is what gives the sender a
  // genuine read receipt, so no status is ever faked.
  useEffect(() => {
    if (!me) return;
    base44.entities.Message
      .updateMany({ conversation_id: convo.id, is_mine: false, is_read: false }, { $set: { is_read: true } })
      .catch(() => {});
    base44.entities.Conversation.update(convo.id, { unread_count: 0 }).catch(() => {});
  }, [me, convo.id, messages.length]);

  // Decrypt encrypted bodies on this device only.
  useEffect(() => {
    if (!e2ee?.key || messages.length === 0) return;
    (async () => {
      const next = {};
      for (const m of messages) {
        if (isEncrypted(m.text) && decrypted[m.id] === undefined) {
          const pt = await decryptText(e2ee.key, m.text);
          next[m.id] = pt === null ? null : pt;
        }
      }
      if (Object.keys(next).length > 0) setDecrypted(d => ({ ...d, ...next }));
    })();
  }, [messages, e2ee]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    atBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < NEAR_BOTTOM;
    if (atBottomRef.current) setPendingNew(0);
    if (el.scrollTop < 60 && messages.length >= limit) {
      restoreRef.current = el.scrollHeight;
      setLimit(l => l + PAGE);
    }
  };

  const persist = (data) =>
    base44.entities.Message.create({
      conversation_id: convo.id,
      member_ids: convo.member_ids,
      sender_name: data.mine ? me.name : convo.participant_name,
      text: data.text || "",
      media_url: data.media_url,
      media_type: data.type || "text",
      file_name: data.file_name,
      duration_seconds: data.duration_seconds || 0,
      reply_to_id: data.reply_to_id,
      reply_author: data.reply_author,
      reply_preview: data.reply_preview,
      status: data.mine ? "sent" : "read",
      reaction: "",
      is_mine: !!data.mine,
      is_read: !data.mine,
    });

  const updateConvo = (lastText) => {
    base44.entities.Conversation
      .update(convo.id, { last_message: lastText, last_message_time: "now", updated_date: new Date().toISOString() })
      .catch(() => {});
  };

  const replyFields = () => {
    if (!replyTo) return {};
    return {
      reply_to_id: replyTo.id,
      reply_author: replyTo.is_mine ? "You" : replyTo.sender_name,
      reply_preview: previewOf(replyTo),
    };
  };

  const previewOf = (m) => {
    if (isEncrypted(m.text)) return "Encrypted message";
    if (m.media_type === "voice") return "🎤 Voice message";
    if (m.media_type === "image") return "📷 Photo";
    if (m.media_type === "video") return "🎥 Video";
    if (m.media_type === "file") return `📄 ${m.file_name || "Document"}`;
    if (m.media_type === "sticker") return "Sticker";
    return String(m.text || "").slice(0, 80);
  };

  const scrollToEnd = () => {
    setPendingNew(0);
    atBottomRef.current = true;
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  };

  const sendText = async (t) => {
    if (!me) return;
    const payload = e2ee?.key ? await encryptText(e2ee.key, t) : t;
    const m = await persist({ text: payload, type: "text", mine: true, ...replyFields() }).catch(() => null);
    setReplyTo(null);
    if (m) { setMessages(ms => [...ms, m]); scrollToEnd(); }
    updateConvo(e2ee?.key ? "Encrypted message" : t);
  };

  const sendMedia = async (file, type) => {
    if (!file) return;
    setUploading(true);
    try {
      const { uploadPrivateFile } = await import("@/lib/social");
      const url = await uploadPrivateFile(file);
      const m = await persist({
        media_url: url, type, mine: true,
        file_name: type === "file" ? file.name : undefined,
        ...replyFields(),
      }).catch(() => null);
      setReplyTo(null);
      if (m) { setMessages(ms => [...ms, m]); scrollToEnd(); }
      updateConvo(type === "image" ? "📷 Photo" : type === "video" ? "🎥 Video" : `📄 ${file.name || "Document"}`);
    } catch {
      toast({ title: "Upload failed — please try again", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const sendVoice = async (file, seconds) => {
    if (!file) {
      toast({ title: "Microphone unavailable", description: "Check your browser's microphone permission.", variant: "destructive" });
      return;
    }
    setUploading(true);
    try {
      const { uploadPrivateFile } = await import("@/lib/social");
      const url = await uploadPrivateFile(file);
      const m = await persist({
        media_url: url, type: "voice", mine: true, duration_seconds: seconds, ...replyFields(),
      }).catch(() => null);
      setReplyTo(null);
      if (m) { setMessages(ms => [...ms, m]); scrollToEnd(); }
      updateConvo("🎤 Voice message");
    } catch {
      toast({ title: "Could not send voice message", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const react = async (m, emoji) => {
    const next = m.reaction === emoji ? "" : emoji;
    setActionsFor(null);
    await base44.entities.Message.update(m.id, { reaction: next }).catch(() => {});
    setMessages(ms => ms.map(x => (x.id === m.id ? { ...x, reaction: next } : x)));
  };

  const startReply = (m) => { setReplyTo(m); setActionsFor(null); };

  const mute = async () => {
    const next = !muted;
    setMuted(next);
    setMenuOpen(false);
    await base44.entities.Conversation.update(convo.id, { is_muted: next }).catch(() => {});
    toast({ title: next ? "Conversation muted" : "Conversation unmuted" });
  };

  const hide = async () => {
    setMenuOpen(false);
    const hidden = [...new Set([...(convo.hidden_for || []), me?.id].filter(Boolean))];
    await base44.entities.Conversation.update(convo.id, { hidden_for: hidden }).catch(() => {});
    toast({ title: "Removed from your inbox" });
    onBack?.();
  };

  const block = async () => {
    setMenuOpen(false);
    const now = await toggleBlock(convo.participant_name).catch(() => false);
    toast({ title: now ? `Blocked ${convo.participant_name}` : `Unblocked ${convo.participant_name}` });
  };

  const report = async () => {
    setMenuOpen(false);
    await reportContent({
      targetType: "user",
      targetId: convo.id,
      reason: "other",
      targetLabel: convo.participant_name,
      details: "Reported from Messenger conversation",
    }).catch(() => {});
    toast({ title: "Report submitted", description: "Our team will review this." });
  };

  const display = (m) => {
    if (!isEncrypted(m.text)) return m.text;
    if (decrypted[m.id] === undefined) return "Decrypting…";
    return decrypted[m.id] === null ? "Encrypted — not readable on this device" : decrypted[m.id];
  };

  const statusOf = (m) => (m.is_read ? "read" : "sent");

  const shown = searchQuery.trim()
    ? messages.filter(m => String(display(m) || "").toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  return (
    <div
      className="app-viewport fixed left-0 right-0 top-0 z-50 mx-auto w-full max-w-2xl flex flex-col bg-background overflow-hidden overscroll-none"
      style={{ "--kb-inset": `${inset}px` }}
    >
      {/* Header — every element shrinks or truncates so it fits a 320px screen */}
      <header className="shrink-0 flex items-center gap-1.5 px-2 py-2 border-b border-border bg-card/90 backdrop-blur-xl">
        <button onClick={onBack} aria-label="Back" className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 hover:bg-secondary/60">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <img src={convo.participant_avatar} alt="" className="w-9 h-9 rounded-full object-cover shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-sm truncate">{convo.participant_name}</div>
          <div className="text-[11px] text-muted-foreground flex items-center gap-1 min-w-0">
            {convo.is_group ? (
              <><Users className="w-3 h-3 shrink-0" /><span className="truncate">{(convo.members || []).length || 2} members</span></>
            ) : e2ee?.key ? (
              <span className="text-emerald-400 flex items-center gap-1 min-w-0"><Lock className="w-3 h-3 shrink-0" /><span className="truncate">Encrypted on your device</span></span>
            ) : (
              <span className="text-amber-400 flex items-center gap-1 min-w-0"><LockOpen className="w-3 h-3 shrink-0" /><span className="truncate">Not encrypted</span></span>
            )}
          </div>
        </div>
        <button onClick={() => setSearchOpen(s => !s)} aria-label="Search" className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 hover:bg-secondary/60">
          <Search className="w-[18px] h-[18px] text-primary" />
        </button>
        <button onClick={() => onStartCall?.("voice")} aria-label="Voice call" className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 hover:bg-secondary/60">
          <Phone className="w-[18px] h-[18px] text-primary" />
        </button>
        <button onClick={() => onStartCall?.("video")} aria-label="Video call" className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 hover:bg-secondary/60">
          <Video className="w-[18px] h-[18px] text-primary" />
        </button>
        <button onClick={() => setMenuOpen(o => !o)} aria-label="Conversation settings" className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 hover:bg-secondary/60">
          <MoreVertical className="w-[18px] h-[18px]" />
        </button>
      </header>

      {menuOpen && (
        <div className="shrink-0 border-b border-border bg-card/95 backdrop-blur-xl px-2 py-1.5">
          <button onClick={mute} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-secondary/60 text-sm">
            <BellOff className="w-4 h-4 text-muted-foreground" /> {muted ? "Unmute conversation" : "Mute conversation"}
          </button>
          <button onClick={block} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-secondary/60 text-sm">
            <UserX className="w-4 h-4 text-muted-foreground" /> Block {convo.participant_name}
          </button>
          <button onClick={report} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-secondary/60 text-sm">
            <Flag className="w-4 h-4 text-muted-foreground" /> Report
          </button>
          <button onClick={hide} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-secondary/60 text-sm text-rose-400">
            <EyeOff className="w-4 h-4" /> Remove from my inbox
          </button>
        </div>
      )}

      {searchOpen && (
        <div className="shrink-0 px-3 py-2 border-b border-border bg-card/70">
          <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2">
            <Search className="w-4 h-4 text-muted-foreground shrink-0" />
            <input
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              autoFocus
              placeholder="Search in conversation…"
              className="flex-1 min-w-0 bg-transparent outline-none text-sm"
            />
            <button onClick={() => { setSearchQuery(""); setSearchOpen(false); }} aria-label="Close search">
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </div>
      )}

      {/* Messages — the only scrolling region, sized to what's actually left */}
      <div
        ref={scrollRef}
        onScroll={onScroll}
        className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-3 py-3 space-y-2.5"
      >
        {shown.length === 0 && (
          <div className="h-full flex items-center justify-center px-6 text-center">
            <p className="text-sm text-muted-foreground">
              {searchQuery.trim() ? `No messages match "${searchQuery}"` : "No messages yet — say hi 👋"}
            </p>
          </div>
        )}
        {shown.map(m => (
          <MessageBubble
            key={m.id}
            m={m}
            mine={m.is_mine}
            text={display(m)}
            time={m.created_date ? moment(m.created_date).format("HH:mm") : ""}
            status={statusOf(m)}
            onOpenActions={setActionsFor}
            onDoubleTapReact={(msg) => react(msg, "❤️")}
          />
        ))}
        <div ref={endRef} />
      </div>

      {pendingNew > 0 && (
        <div className="shrink-0 flex justify-center pb-1.5">
          <button onClick={scrollToEnd} className="px-3.5 py-1.5 rounded-full bix-gradient text-white text-[11px] font-semibold bix-glow">
            {pendingNew} new message{pendingNew > 1 ? "s" : ""}
          </button>
        </div>
      )}

      <Composer
        onSendText={sendText}
        onSendMedia={sendMedia}
        onSendVoice={sendVoice}
        onSendSticker={() => {}}
        replyTo={replyTo && { author: replyTo.is_mine ? "You" : replyTo.sender_name, preview: previewOf(replyTo) }}
        onCancelReply={() => setReplyTo(null)}
        uploading={uploading}
      />

      {actionsFor && (
        <div className="absolute inset-0 z-10 bg-black/50 flex items-end" onClick={() => setActionsFor(null)}>
          <div className="w-full bg-card border-t border-border rounded-t-2xl p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-around mb-2">
              {REACTIONS.map(r => (
                <button
                  key={r}
                  onClick={() => react(actionsFor, r)}
                  className={cn("w-11 h-11 rounded-full flex items-center justify-center text-2xl bix-press",
                    actionsFor.reaction === r ? "bg-secondary" : "")}
                >
                  {r}
                </button>
              ))}
            </div>
            <button
              onClick={() => startReply(actionsFor)}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-secondary/60 text-sm"
            >
              <CornerUpLeft className="w-4 h-4 text-primary" /> Reply
            </button>
          </div>
        </div>
      )}
    </div>
  );
}