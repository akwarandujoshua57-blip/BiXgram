import React, { useRef, useState, useEffect } from "react";
import { Play, Pause, Mic } from "lucide-react";
import { cn } from "@/lib/utils";

// Bixgram voice message — a compact in-bubble player with play/pause, a
// progress track and a duration readout. Deliberately not the browser's native
// <audio> control, which is oversized and breaks the bubble on small screens.
export default function VoiceMessage({ url, mine, durationSeconds = 0 }) {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0); // 0..1
  const [elapsed, setElapsed] = useState(0);

  const total = durationSeconds || 0;
  const fmt = (s) => {
    const v = Math.max(0, Math.round(s || 0));
    return `${Math.floor(v / 60)}:${String(v % 60).padStart(2, "0")}`;
  };

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const onTime = () => {
      const d = a.duration && isFinite(a.duration) ? a.duration : total;
      setElapsed(a.currentTime);
      setProgress(d ? a.currentTime / d : 0);
    };
    const onEnd = () => { setPlaying(false); setProgress(0); setElapsed(0); };
    a.addEventListener("timeupdate", onTime);
    a.addEventListener("ended", onEnd);
    return () => {
      a.removeEventListener("timeupdate", onTime);
      a.removeEventListener("ended", onEnd);
    };
  }, [total]);

  const toggle = () => {
    const a = audioRef.current;
    if (!a) return;
    if (playing) { a.pause(); setPlaying(false); }
    else { a.play().then(() => setPlaying(true)).catch(() => setPlaying(false)); }
  };

  const shown = playing || elapsed > 0 ? elapsed : total;

  return (
    <div className="flex items-center gap-2.5 w-[190px] max-w-full">
      <audio ref={audioRef} src={url} preload="metadata" className="hidden" />
      <button
        onClick={toggle}
        aria-label={playing ? "Pause voice message" : "Play voice message"}
        className={cn(
          "w-9 h-9 rounded-full flex items-center justify-center shrink-0",
          mine ? "bg-white/25 text-white" : "bg-primary text-primary-foreground"
        )}
      >
        {playing ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
      </button>
      <div className="flex-1 min-w-0">
        <div className={cn("h-1 rounded-full overflow-hidden", mine ? "bg-white/25" : "bg-muted")}>
          <div
            className={cn("h-full rounded-full transition-[width] duration-150", mine ? "bg-white" : "bix-gradient")}
            style={{ width: `${Math.min(100, progress * 100)}%` }}
          />
        </div>
        <div className={cn("flex items-center gap-1 mt-1 text-[10px]", mine ? "text-white/80" : "text-muted-foreground")}>
          <Mic className="w-3 h-3" />
          <span>{fmt(shown)}</span>
        </div>
      </div>
    </div>
  );
}