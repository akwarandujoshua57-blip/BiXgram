import React, { useRef } from "react";
import { Check, CheckCheck, CornerUpLeft, FileText, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import VoiceMessage from "@/components/messenger/VoiceMessage";
import { Image } from "@/components/ui/image";
import useSignedUrl from "@/hooks/use-signed-url";

const REACTIONS = ["❤️", "👍", "😂", "😮", "😢", "😡"];

export { REACTIONS };

function StatusTicks({ status, mine }) {
  if (!mine) return null;
  if (status === "read") return <CheckCheck className="w-3.5 h-3.5 text-cyan-400" aria-label="Read" />;
  if (status === "delivered") return <CheckCheck className="w-3.5 h-3.5 text-muted-foreground" aria-label="Delivered" />;
  return <Check className="w-3.5 h-3.5 text-muted-foreground" aria-label="Sent" />;
}

export default function MessageBubble({ m, mine, text, time, onOpenActions, onDoubleTapReact }) {
  const pressTimer = useRef(null);
  // Private attachments resolve to a short-lived signed link; older public
  // URLs pass straight through.
  const mediaUrl = useSignedUrl(m.media_url);

  const startPress = () => {
    clearTimeout(pressTimer.current);
    pressTimer.current = setTimeout(() => onOpenActions?.(m), 450);
  };
  const endPress = () => clearTimeout(pressTimer.current);

  const bubbleBase = cn(
    "max-w-[78%] px-3.5 py-2 rounded-2xl text-sm overflow-hidden break-words",
    mine ? "bix-gradient text-white rounded-br-md" : "bg-secondary text-foreground rounded-bl-md"
  );

  return (
    <div className={cn("flex flex-col", mine ? "items-end" : "items-start")}>
      <div
        onPointerDown={startPress}
        onPointerUp={endPress}
        onPointerLeave={endPress}
        onPointerCancel={endPress}
        onDoubleClick={() => onDoubleTapReact?.(m)}
        onContextMenu={(e) => { e.preventDefault(); onOpenActions?.(m); }}
        className={cn(bubbleBase, "cursor-pointer select-none")}
      >
        {m.reply_to_id && (
          <div className={cn(
            "mb-1.5 rounded-lg px-2.5 py-1.5 border-l-2",
            mine ? "bg-black/20 border-white/60" : "bg-background/50 border-primary"
          )}>
            <div className={cn("text-[10px] font-semibold truncate", mine ? "text-white/90" : "text-primary")}>
              {m.reply_author || "Message"}
            </div>
            <div className={cn("text-[11px] truncate", mine ? "text-white/70" : "text-muted-foreground")}>
              {m.reply_preview || "Original message"}
            </div>
          </div>
        )}

        {m.media_type === "image" && mediaUrl && (
          <Image src={mediaUrl} alt="" className="rounded-xl max-w-full mb-1" fittingType="fit" />
        )}
        {m.media_type === "video" && mediaUrl && (
          <video src={mediaUrl} controls playsInline preload="metadata" className="rounded-xl max-w-full mb-1 bg-black" />
        )}
        {m.media_type === "sticker" && mediaUrl && (
          <Image src={mediaUrl} alt="" className="w-24 h-24" fittingType="fit" />
        )}
        {m.media_type === "voice" && mediaUrl && (
          <VoiceMessage url={mediaUrl} mine={mine} durationSeconds={m.duration_seconds} />
        )}
        {m.media_type === "file" && mediaUrl && (
          <a
            href={mediaUrl}
            target="_blank"
            rel="noreferrer"
            onClick={(e) => e.stopPropagation()}
            className={cn("flex items-center gap-2.5 min-w-0", mine ? "text-white" : "text-foreground")}
          >
            <span className={cn("w-9 h-9 rounded-xl flex items-center justify-center shrink-0", mine ? "bg-white/20" : "bg-background/60")}>
              <FileText className="w-4 h-4" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-xs font-semibold truncate">{m.file_name || "Document"}</span>
              <span className={cn("text-[10px]", mine ? "text-white/70" : "text-muted-foreground")}>Tap to open</span>
            </span>
            <Download className={cn("w-4 h-4 shrink-0", mine ? "text-white/80" : "text-muted-foreground")} />
          </a>
        )}

        {text && <p className={cn("whitespace-pre-wrap", m.media_type !== "text" && m.media_url ? "mt-1" : "")}>{text}</p>}
      </div>

      <div className={cn("flex items-center gap-1.5 mt-0.5", mine ? "mr-1" : "ml-1")}>
        <span className="text-[10px] text-muted-foreground">{time}</span>
        <StatusTicks status={m.status} mine={mine} />
        {m.reaction && (
          <span className="text-[11px] leading-none px-1.5 py-0.5 rounded-full bg-secondary border border-border">
            {m.reaction}
          </span>
        )}
      </div>
    </div>
  );
}