import React, { useEffect } from "react";
import { Outlet } from "react-router-dom";
import BottomNav from "@/components/BottomNav";
import { ensureMyProfile } from "@/lib/social";

export default function AppLayout() {
  // Guarantee this account has its own profile record, so it can be addressed
  // by its authenticated user id and never by a shared display name.
  useEffect(() => {
    ensureMyProfile();
  }, []);

  return (
    <div className="min-h-screen bg-background safe-top">
      <main className="min-h-screen pb-[calc(5rem+env(safe-area-inset-bottom))]">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
}