import React from "react";
import BixLogo from "@/components/BixLogo";

export default function AuthLayout({ icon: Icon, title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bix-gradient opacity-10 blur-3xl" />
      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <BixLogo size={56} />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight bix-gradient-text font-display">{title}</h1>
          {subtitle && <p className="text-muted-foreground mt-2 text-sm">{subtitle}</p>}
        </div>
        <div className="bg-card/80 backdrop-blur-xl rounded-3xl shadow-lg border border-border p-7">
          {children}
        </div>
        {footer && (
          <p className="text-center text-sm text-muted-foreground mt-6">{footer}</p>
        )}
        <p className="text-center text-xs text-muted-foreground/60 mt-6">Your world, your people, your feed.</p>
      </div>
    </div>
  );
}