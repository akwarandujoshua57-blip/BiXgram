import React, { useEffect, useState } from "react";
import { DollarSign, Check, X, MessageSquare, PauseCircle, PlayCircle, Ban, RefreshCw, BadgeCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getMe } from "@/lib/social";
import { formatCount } from "@/lib/bixgram-data";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

// Channel Monetization Management — restricted to Bixgram administrators.
//
// Every state change here writes an admin-only ChannelMonetization record plus an
// audit entry. A channel owner has no way to create or modify either record, so
// monetization can only ever come from this screen.
export default function MonetizationPanel() {
  const [applications, setApplications] = useState([]);
  const [decisions, setDecisions] = useState([]);
  const [audits, setAudits] = useState([]);
  const [adminName, setAdminName] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);
  const [notes, setNotes] = useState({});
  const { toast } = useToast();

  const load = async () => {
    const [apps, mons, logs] = await Promise.all([
      base44.entities.ChannelApplication.list("-created_date", 100).catch(() => []),
      base44.entities.ChannelMonetization.list("-created_date", 100).catch(() => []),
      base44.entities.ChannelAudit.list("-created_date", 100).catch(() => []),
    ]);
    setApplications(apps);
    setDecisions(mons);
    setAudits(logs);
    setLoading(false);
  };

  useEffect(() => {
    (async () => {
      try { setAdminName((await getMe()).name); } catch {}
      await load();
    })();
  }, []);

  const writeAudit = (entry) =>
    base44.entities.ChannelAudit.create({
      target_type: "monetization",
      administrator: adminName || "admin",
      ...entry,
    }).catch(() => {});

  const decide = async (app, newStatus, action) => {
    setBusy(app.id);
    try {
      const existing = decisions.find(d => String(d.channel_id) === String(app.channel_id));
      const payload = {
        channel_id: String(app.channel_id),
        channel_name: app.channel_name,
        owner_name: app.owner_name,
        owner_id: app.owner_id,
        status: newStatus,
        decided_by: adminName || "admin",
        decided_at: new Date().toISOString(),
        reason: notes[app.id] || "",
      };

      const previous = existing?.status || app.status;

      if (existing) {
        // The authoritative approval record — writable only by an administrator.
        await base44.entities.ChannelMonetization.update(existing.id, payload);
      } else {
        await base44.entities.ChannelMonetization.create(payload);
      }

      await base44.entities.ChannelApplication.update(app.id, { status: "decided" }).catch(() => {});

      await writeAudit({
        channel_id: String(app.channel_id),
        owner_id: app.owner_id,
        action,
        previous_status: previous,
        new_status: newStatus,
        reason: notes[app.id] || "",
        internal_notes: notes[app.id] || "",
      });

      toast({ title: `${app.channel_name} — ${action}` });
      setNotes(n => ({ ...n, [app.id]: "" }));
      await load();
    } catch {
      toast({ title: "Action failed", variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  const changeStatus = async (record, newStatus, action) => {
    setBusy(record.id);
    try {
      await base44.entities.ChannelMonetization.update(record.id, {
        status: newStatus,
        decided_by: adminName || "admin",
        decided_at: new Date().toISOString(),
        reason: notes[record.id] || record.reason || "",
      });
      await writeAudit({
        channel_id: String(record.channel_id),
        owner_id: record.owner_id,
        action,
        previous_status: record.status,
        new_status: newStatus,
        reason: notes[record.id] || "",
        internal_notes: notes[record.id] || "",
      });
      toast({ title: `${record.channel_name} — ${action}` });
      setNotes(n => ({ ...n, [record.id]: "" }));
      await load();
    } catch {
      toast({ title: "Action failed", variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  if (loading) return <div className="h-40 rounded-2xl bix-skeleton" />;

  const queue = applications.filter(a => a.status === "pending_review" || a.status === "info_requested");

  const statusChip = (s) => {
    const map = {
      approved: "bg-emerald-500/10 text-emerald-400",
      active: "bg-emerald-500/10 text-emerald-400",
      rejected: "bg-rose-500/10 text-rose-400",
      revoked: "bg-rose-500/10 text-rose-400",
      suspended: "bg-amber-500/10 text-amber-400",
    };
    return map[s] || "bg-secondary text-muted-foreground";
  };

  return (
    <div className="space-y-5">
      <div className="bix-card p-4">
        <div className="flex items-center gap-2 mb-1">
          <DollarSign className="w-5 h-5 text-primary" />
          <h3 className="font-bold">Monetization applications</h3>
          <span className="ml-auto text-xs text-muted-foreground">{queue.length} awaiting review</span>
        </div>
        <p className="text-xs text-muted-foreground mb-4">
          Approval is manual and can only be granted here. Meeting the eligibility criteria never monetizes a channel
          on its own, and owners cannot approve themselves.
        </p>

        {queue.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground">No applications awaiting review</div>
        ) : queue.map(a => (
          <div key={a.id} className="border-b border-border last:border-0 py-4 first:pt-0">
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <span className="font-semibold text-sm">{a.channel_name}</span>
              <span className="text-[10px] text-muted-foreground">by @{a.owner_name}</span>
              {a.verified_at_submission && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary flex items-center gap-1">
                  <BadgeCheck className="w-3 h-3" /> Verified
                </span>
              )}
              {a.status === "info_requested" && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400">Info requested</span>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
              {[
                { label: "Followers", value: formatCount(a.followers_at_submission || 0) },
                { label: "Videos", value: formatCount(a.videos_at_submission || 0) },
                { label: "Views", value: formatCount(a.views_at_submission || 0) },
                { label: "Plan", value: a.premium_at_submission || "none" },
              ].map(m => (
                <div key={m.label} className="rounded-xl bg-secondary/50 p-2.5">
                  <div className="text-sm font-bold truncate">{m.value}</div>
                  <div className="text-[10px] text-muted-foreground">{m.label}</div>
                </div>
              ))}
            </div>

            <textarea
              value={notes[a.id] || ""}
              onChange={e => setNotes(n => ({ ...n, [a.id]: e.target.value }))}
              rows={2}
              placeholder="Internal notes / reason (admins only)"
              className="w-full bg-secondary/50 rounded-xl px-3 py-2 outline-none text-xs resize-none mb-2"
            />

            <div className="flex flex-wrap gap-2">
              <button
                disabled={busy === a.id}
                onClick={() => decide(a, "approved", "Approved monetization")}
                className="px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold flex items-center gap-1 disabled:opacity-50"
              >
                <Check className="w-3.5 h-3.5" /> Approve
              </button>
              <button
                disabled={busy === a.id}
                onClick={() => decide(a, "rejected", "Rejected monetization")}
                className="px-3 py-1.5 rounded-lg bg-rose-500/10 text-rose-400 text-xs font-semibold flex items-center gap-1 disabled:opacity-50"
              >
                <X className="w-3.5 h-3.5" /> Reject
              </button>
              <button
                disabled={busy === a.id}
                onClick={async () => {
                  setBusy(a.id);
                  await base44.entities.ChannelApplication.update(a.id, { status: "info_requested" }).catch(() => {});
                  await writeAudit({
                    channel_id: String(a.channel_id), owner_id: a.owner_id,
                    action: "Requested more information",
                    previous_status: a.status, new_status: "info_requested",
                    reason: notes[a.id] || "", internal_notes: notes[a.id] || "",
                  });
                  toast({ title: "Information requested" });
                  setBusy(null);
                  await load();
                }}
                className="px-3 py-1.5 rounded-lg bg-secondary text-muted-foreground text-xs font-semibold flex items-center gap-1 disabled:opacity-50"
              >
                <MessageSquare className="w-3.5 h-3.5" /> Request info
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="bix-card p-4">
        <div className="flex items-center gap-2 mb-3">
          <BadgeCheck className="w-5 h-5 text-primary" />
          <h3 className="font-bold">Decided channels</h3>
          <button onClick={load} aria-label="Refresh" className="ml-auto w-8 h-8 rounded-full hover:bg-secondary flex items-center justify-center">
            <RefreshCw className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        </div>

        {decisions.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground">No decisions yet</div>
        ) : decisions.map(d => (
          <div key={d.id} className="border-b border-border last:border-0 py-3 first:pt-0">
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <span className="font-semibold text-sm">{d.channel_name}</span>
              <span className="text-[10px] text-muted-foreground">@{d.owner_name}</span>
              <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full capitalize", statusChip(d.status))}>{d.status}</span>
              {d.decided_at && <span className="text-[10px] text-muted-foreground">by {d.decided_by}</span>}
            </div>
            <div className="flex flex-wrap gap-2">
              {d.status === "suspended" ? (
                <button disabled={busy === d.id} onClick={() => changeStatus(d, "active", "Restored monetization")}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold flex items-center gap-1">
                  <PlayCircle className="w-3.5 h-3.5" /> Restore
                </button>
              ) : (
                <button disabled={busy === d.id} onClick={() => changeStatus(d, "suspended", "Suspended monetization")}
                  className="px-3 py-1.5 rounded-lg bg-amber-500/10 text-amber-400 text-xs font-semibold flex items-center gap-1">
                  <PauseCircle className="w-3.5 h-3.5" /> Suspend
                </button>
              )}
              {d.status !== "revoked" && (
                <button disabled={busy === d.id} onClick={() => changeStatus(d, "revoked", "Revoked monetization")}
                  className="px-3 py-1.5 rounded-lg bg-rose-500/10 text-rose-400 text-xs font-semibold flex items-center gap-1">
                  <Ban className="w-3.5 h-3.5" /> Revoke
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="bix-card p-4">
        <h3 className="font-bold mb-3">Approval audit trail</h3>
        {audits.length === 0 ? (
          <div className="text-center py-8 text-sm text-muted-foreground">No audit records yet</div>
        ) : audits.map(a => (
          <div key={a.id} className="border-b border-border last:border-0 py-2.5 first:pt-0 text-xs">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold">{a.action}</span>
              <span className="text-muted-foreground">
                {a.previous_status ? `${a.previous_status} → ${a.new_status}` : a.new_status}
              </span>
              <span className="text-muted-foreground ml-auto">{a.administrator}</span>
            </div>
            {a.reason && <p className="text-muted-foreground mt-1">{a.reason}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}