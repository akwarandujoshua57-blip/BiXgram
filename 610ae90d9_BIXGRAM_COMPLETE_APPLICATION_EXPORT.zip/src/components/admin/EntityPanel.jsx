import React from "react";
import { cn } from "@/lib/utils";

export default function EntityPanel({ icon: Icon, title, rows, emptyText = "Nothing here yet." }) {
  return (
    <div className="bix-card p-4">
      <div className="flex items-center gap-2 mb-3">
        {Icon && <Icon className="w-5 h-5 text-primary" />}
        <h3 className="font-bold">{title}</h3>
        <span className="ml-auto text-xs text-muted-foreground">{rows.length} total</span>
      </div>
      {rows.length === 0 ? (
        <div className="text-center py-10 text-sm text-muted-foreground">{emptyText}</div>
      ) : (
        <div className="divide-y divide-border max-h-[60vh] overflow-y-auto">
          {rows.map(r => (
            <div key={r.id} className="flex items-center gap-3 py-2.5">
              {r.avatar && <img src={r.avatar} alt="" className="w-9 h-9 rounded-full object-cover" />}
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm truncate">{r.primary}</div>
                {r.secondary && <div className="text-xs text-muted-foreground truncate">{r.secondary}</div>}
              </div>
              {r.meta && <span className="text-xs text-muted-foreground shrink-0">{r.meta}</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}