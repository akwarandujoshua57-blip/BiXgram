import React, { useState, useEffect } from "react";
import { Bot, ShieldCheck, Trash2, CircleAlert } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { cn } from "@/lib/utils";

const REASONS = {
  spam: { label: "Spam", color: "bg-amber-500/10 text-amber-400" },
  scam: { label: "Scam", color: "bg-rose-500/10 text-rose-400" },
  harassment: { label: "Harassment", color: "bg-orange-500/10 text-orange-400" },
  hate: { label: "Hate", color: "bg-red-500/10 text-red-400" },
  inappropriate: { label: "Inappropriate", color: "bg-fuchsia-500/10 text-fuchsia-400" },
  fake_account: { label: "Fake account", color: "bg-slate-500/10 text-slate-400" },
};

export default function ModerationQueue({ refreshKey, onHandled }) {
  const [flags, setFlags] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      setFlags(await base44.entities.ModerationFlag.filter({ status: "flagged" }, "-created_date", 50));
    } catch {
      setFlags([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [refreshKey]);

  const approve = async (f) => {
    await base44.entities.ModerationFlag.update(f.id, { status: "approved" }).catch(() => {});
    setFlags(fs => fs.filter(x => x.id !== f.id));
    onHandled?.();
  };

  const remove = async (f) => {
    // remove the offending content, then close the flag
    if (f.target_type === "post") await base44.entities.Post.delete(f.target_id).catch(() => {});
    if (f.target_type === "comment") await base44.entities.Comment.delete(f.target_id).catch(() => {});
    await base44.entities.ModerationFlag.update(f.id, { status: "removed" }).catch(() => {});
    setFlags(fs => fs.filter(x => x.id !== f.id));
    onHandled?.();
  };

  return (
    <div className="bix-card p-4">
      <div className="flex items-center gap-2 mb-3">
        <Bot className="w-5 h-5 text-primary" />
        <h3 className="font-bold">AI Moderation Queue</h3>
        <span className="ml-auto text-xs text-muted-foreground">{flags.length} awaiting review</span>
      </div>
      {loading ? (
        <div className="flex justify-center py-10">
          <div className="w-7 h-7 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : flags.length === 0 ? (
        <div className="text-center py-10 text-sm text-muted-foreground flex flex-col items-center gap-2">
          <ShieldCheck className="w-8 h-8 text-emerald-400" />
          Nothing flagged — the community is clean ✨
        </div>
      ) : (
        flags.map(f => {
          const r = REASONS[f.reason] || REASONS.spam;
          return (
            <div key={f.id} className="border-b border-border last:border-0 py-3 first:pt-0">
              <div className="flex items-center gap-2 mb-1">
                <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full", r.color)}>{r.label}</span>
                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <CircleAlert className="w-3 h-3" /> {Math.round((f.confidence || 0) * 100)}% confidence
                </span>
                <span className="text-[10px] text-muted-foreground ml-auto">{f.target_type} · @{f.author_name}</span>
              </div>
              <p className="text-sm mb-2 line-clamp-2">{f.content_preview}</p>
              <div className="flex gap-2">
                <button onClick={() => remove(f)} className="px-3 py-1.5 rounded-lg bg-rose-500/10 text-rose-400 text-xs font-semibold flex items-center gap-1">
                  <Trash2 className="w-3.5 h-3.5" /> Remove content
                </button>
                <button onClick={() => approve(f)} className="px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold">
                  Approve
                </button>
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}