import React, { useEffect, useState } from "react";
import { BadgeCheck, Search, ShieldCheck, ShieldOff } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getMe } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

// Verification Management — restricted to Bixgram administrators.
//
// Verification is entirely separate from Premium. Only an administrator can grant
// or revoke it, and a verified account is not monetized by that fact alone.
export default function VerificationPanel() {
  const [users, setUsers] = useState([]);
  const [verifications, setVerifications] = useState([]);
  const [query, setQuery] = useState("");
  const [adminName, setAdminName] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);
  const { toast } = useToast();

  const load = async () => {
    const [u, v] = await Promise.all([
      base44.entities.User.list(200).catch(() => []),
      base44.entities.UserVerification.list(500).catch(() => []),
    ]);
    setUsers(u);
    setVerifications(v);
    setLoading(false);
  };

  useEffect(() => {
    (async () => {
      try { setAdminName((await getMe()).name); } catch {}
      await load();
    })();
  }, []);

  const recordFor = (userName) => verifications.find(v => v.user_name === userName);

  const audit = (entry) =>
    base44.entities.ChannelAudit.create({
      target_type: "verification",
      administrator: adminName || "admin",
      ...entry,
    }).catch(() => {});

  const grant = async (u) => {
    const name = u.full_name || u.username || u.email;
    setBusy(u.id);
    try {
      const existing = recordFor(name);
      const payload = {
        user_name: name,
        user_id: u.id,
        is_verified: true,
        verified_by: adminName || "admin",
        verified_at: new Date().toISOString(),
      };
      if (existing) await base44.entities.UserVerification.update(existing.id, payload);
      else await base44.entities.UserVerification.create(payload);
      await audit({ owner_id: u.id, action: "Granted verification", new_status: "verified" });
      toast({ title: `${name} is now verified` });
      await load();
    } catch {
      toast({ title: "Could not update verification", variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  const revoke = async (u) => {
    const name = u.full_name || u.username || u.email;
    setBusy(u.id);
    try {
      const existing = recordFor(name);
      if (existing) {
        await base44.entities.UserVerification.update(existing.id, {
          is_verified: false,
          revoked_at: new Date().toISOString(),
        });
      }
      await audit({ owner_id: u.id, action: "Revoked verification", previous_status: "verified", new_status: "unverified" });
      toast({ title: `Verification removed from ${name}` });
      await load();
    } catch {
      toast({ title: "Could not update verification", variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  if (loading) return <div className="h-40 rounded-2xl bix-skeleton" />;

  const q = query.trim().toLowerCase();
  const filtered = users.filter(u => {
    const name = `${u.full_name || ""} ${u.username || ""} ${u.email || ""}`.toLowerCase();
    return !q || name.includes(q);
  });

  return (
    <div className="space-y-4">
      <div className="bix-card p-4">
        <div className="flex items-center gap-2 mb-1">
          <BadgeCheck className="w-5 h-5 text-primary" />
          <h3 className="font-bold">Verification Management</h3>
          <span className="ml-auto text-xs text-muted-foreground">
            {verifications.filter(v => v.is_verified).length} verified
          </span>
        </div>
        <p className="text-xs text-muted-foreground mb-3">
          Verification is granted here and nowhere else. Premium plans don't confer it, and users can't assign it to
          themselves. Verified status is required before a channel can apply for monetization.
        </p>
        <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-4 py-2.5">
          <Search className="w-[18px] h-[18px] text-muted-foreground shrink-0" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search accounts"
            className="flex-1 min-w-0 bg-transparent outline-none text-sm"
          />
        </div>
      </div>

      <div className="bix-card p-4">
        {filtered.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground">No accounts match</div>
        ) : filtered.map(u => {
          const name = u.full_name || u.username || u.email;
          const rec = recordFor(name);
          const verified = !!rec?.is_verified;
          return (
            <div key={u.id} className="flex items-center gap-3 border-b border-border last:border-0 py-3 first:pt-0">
              <div className="w-9 h-9 rounded-full bix-gradient flex items-center justify-center text-white text-xs font-bold shrink-0">
                {String(name || "?").charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1 min-w-0">
                  <span className="text-sm font-semibold truncate">{name}</span>
                  {verified && <BadgeCheck className="w-3.5 h-3.5 text-primary shrink-0" />}
                </div>
                <p className="text-[11px] text-muted-foreground truncate">{u.email}</p>
              </div>
              {verified ? (
                <button
                  disabled={busy === u.id}
                  onClick={() => revoke(u)}
                  className="px-3 py-1.5 rounded-lg bg-rose-500/10 text-rose-400 text-xs font-semibold flex items-center gap-1 shrink-0 disabled:opacity-50"
                >
                  <ShieldOff className="w-3.5 h-3.5" /> Revoke
                </button>
              ) : (
                <button
                  disabled={busy === u.id}
                  onClick={() => grant(u)}
                  className={cn("px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold flex items-center gap-1 shrink-0 disabled:opacity-50")}
                >
                  <ShieldCheck className="w-3.5 h-3.5" /> Verify
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}