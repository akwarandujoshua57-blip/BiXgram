import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BadgeCheck, Check, Plus, Users } from "lucide-react";
import { isSubscribed, toggleChannelSubscription } from "@/lib/channels";
import { formatCount } from "@/lib/bixgram-data";
import { cn } from "@/lib/utils";

// One channel in search results. Only real channels appear — the query filters
// records that already exist, nothing is suggested to fill the list.
export default function ChannelResultRow({ channel, verified }) {
  const [subscribed, setSubscribed] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    isSubscribed(channel.id).then(s => { if (alive) setSubscribed(s); }).catch(() => {});
    return () => { alive = false; };
  }, [channel.id]);

  const toggle = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (busy) return;
    setBusy(true);
    try {
      setSubscribed(await toggleChannelSubscription(channel));
    } catch {}
    setBusy(false);
  };

  return (
    <Link to={`/channels/${channel.id}`} className="flex items-center gap-3 p-2 min-w-0">
      {channel.avatar_url ? (
        <img src={channel.avatar_url} alt="" className="w-11 h-11 rounded-2xl object-cover shrink-0" />
      ) : (
        <div className="w-11 h-11 rounded-2xl bix-gradient flex items-center justify-center text-white font-bold shrink-0">
          {String(channel.name || "?").charAt(0).toUpperCase()}
        </div>
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1 min-w-0">
          <span className="font-semibold text-sm truncate">{channel.name}</span>
          {verified && <BadgeCheck className="w-3.5 h-3.5 text-primary shrink-0" />}
        </div>
        <div className="text-xs text-muted-foreground truncate">@{channel.username}</div>
        <div className="text-[11px] text-muted-foreground flex items-center gap-1 truncate">
          <Users className="w-3 h-3 shrink-0" />
          {formatCount(channel.subscribers_count || 0)} subscribers
        </div>
        {channel.description && (
          <p className="text-[11px] text-muted-foreground truncate mt-0.5">{channel.description}</p>
        )}
      </div>
      <button
        onClick={toggle}
        disabled={busy}
        aria-label={subscribed ? `Unsubscribe from ${channel.name}` : `Subscribe to ${channel.name}`}
        className={cn(
          "shrink-0 px-3.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1 bix-press",
          subscribed ? "bg-secondary text-muted-foreground" : "bix-gradient text-white"
        )}
      >
        {subscribed ? <><Check className="w-3 h-3" /> Subscribed</> : <><Plus className="w-3 h-3" /> Subscribe</>}
      </button>
    </Link>
  );
}