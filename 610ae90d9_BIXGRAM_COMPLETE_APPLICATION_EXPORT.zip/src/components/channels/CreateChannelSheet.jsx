import React, { useState } from "react";
import { X, Loader2, Image as ImageIcon, ShieldCheck } from "lucide-react";
import { getMe, getProfile, uploadFile } from "@/lib/social";
import { base44 } from "@/api/base44Client";
import {
  CHANNEL_CATEGORIES, validateHandle, normalizeHandle, isHandleTaken, getMyChannelAllowance,
} from "@/lib/channels";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export default function CreateChannelSheet({ open, onClose, onCreated }) {
  const [form, setForm] = useState({ name: "", username: "", description: "", category: "General", rules: "" });
  const [avatar, setAvatar] = useState(null);
  const [cover, setCover] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState("form");
  const { toast } = useToast();

  if (!open) return null;

  const reset = () => {
    setForm({ name: "", username: "", description: "", category: "General", rules: "" });
    setAvatar(null);
    setCover(null);
    setError("");
    setStep("form");
  };

  const pick = async (e, setter) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be 5MB or smaller");
      return;
    }
    setError("");
    setUploading(true);
    try {
      setter(await uploadFile(file));
    } catch {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const validate = () => {
    const name = form.name.trim();
    const handle = normalizeHandle(form.username);
    if (!name) return "Channel name is required";
    if (name.length > 50) return "Channel name must be 50 characters or fewer";
    const handleError = validateHandle(handle);
    if (handleError) return handleError;
    if (form.description.length > 300) return "Description must be 300 characters or fewer";
    return null;
  };

  // The preview step shows exactly what will be created, from the values
  // entered — a brand new channel genuinely has no subscribers yet.
  const goPreview = () => {
    const problem = validate();
    if (problem) return setError(problem);
    setError("");
    setStep("preview");
  };

  const submit = async () => {
    setError("");
    const name = form.name.trim();
    const handle = normalizeHandle(form.username);

    const problem = validate();
    if (problem) { setStep("form"); return setError(problem); }

    setSaving(true);
    try {
      // Channel limits are checked against real stored channels, not the form.
      const allowance = await getMyChannelAllowance();
      if (allowance.remaining <= 0) {
        setError("You've reached your Channel limit. Free accounts can create up to 2 Channels — upgrade to Premium for unlimited Channels.");
        return;
      }
      if (await isHandleTaken(handle)) {
        setError("That handle is already taken");
        return;
      }

      const me = await getMe();
      let avatarUrl = avatar;
      if (!avatarUrl) {
        try { avatarUrl = (await getProfile(me.name)).avatar_url || null; } catch {}
      }

      const created = await base44.entities.Channel.create({
        owner_id: me.id,
        owner_name: me.name,
        name,
        username: handle,
        description: form.description.trim(),
        rules: form.rules.trim(),
        category: form.category,
        avatar_url: avatarUrl || undefined,
        cover_url: cover || undefined,
        privacy: "public",
        status: "active",
        subscribers_count: 0,
        content_count: 0,
        views_count: 0,
      });

      toast({ title: `${name} created`, description: "You're the channel owner." });
      reset();
      onCreated?.(created);
      onClose?.();
    } catch {
      setError("Could not create the channel. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const field = "w-full bg-secondary/50 rounded-xl px-3.5 py-2.5 outline-none text-sm mt-1 focus:ring-1 focus:ring-primary/40";

  return (
    <div className="fixed inset-0 z-[70] bg-black/60 flex items-end" onClick={onClose}>
      <div
        className="w-full max-w-2xl mx-auto bg-card border-t border-border rounded-t-2xl max-h-[90vh] overflow-y-auto overscroll-contain p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold">Create channel</h3>
          <button onClick={onClose} aria-label="Close" className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex gap-3 mb-4">
          <label className="cursor-pointer shrink-0">
            {avatar ? (
              <img src={avatar} alt="" className="w-16 h-16 rounded-2xl object-cover" />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-secondary/60 flex items-center justify-center">
                {uploading ? <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /> : <ImageIcon className="w-5 h-5 text-muted-foreground" />}
              </div>
            )}
            <span className="block text-[10px] text-muted-foreground text-center mt-1">Profile</span>
            <input type="file" accept="image/*" hidden onChange={e => pick(e, setAvatar)} />
          </label>
          <label className="cursor-pointer flex-1 min-w-0">
            {cover ? (
              <img src={cover} alt="" className="w-full h-16 rounded-2xl object-cover" />
            ) : (
              <div className="w-full h-16 rounded-2xl bg-secondary/60 flex items-center justify-center">
                <ImageIcon className="w-5 h-5 text-muted-foreground" />
              </div>
            )}
            <span className="block text-[10px] text-muted-foreground text-center mt-1">Cover (optional)</span>
            <input type="file" accept="image/*" hidden onChange={e => pick(e, setCover)} />
          </label>
        </div>

        <label className="text-xs font-semibold text-muted-foreground">Channel name</label>
        <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Bixgram News" className={field} />

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Handle</label>
        <div className="flex items-center gap-2 bg-secondary/50 rounded-xl px-3.5 mt-1">
          <span className="text-sm text-muted-foreground">@</span>
          <input
            value={form.username}
            onChange={e => setForm(f => ({ ...f, username: normalizeHandle(e.target.value) }))}
            placeholder="yourchannel"
            className="flex-1 min-w-0 bg-transparent py-2.5 outline-none text-sm"
          />
        </div>
        <p className="text-[11px] text-muted-foreground mt-1">3–20 characters · letters, numbers and underscores</p>

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Description</label>
        <textarea
          value={form.description}
          onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
          rows={3}
          placeholder="What is this channel about?"
          className={cn(field, "resize-none")}
        />

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Category</label>
        <div className="flex gap-2 overflow-x-auto no-scrollbar py-2">
          {CHANNEL_CATEGORIES.map(c => (
            <button
              key={c}
              onClick={() => setForm(f => ({ ...f, category: c }))}
              className={cn("px-3.5 py-1.5 rounded-full text-xs font-medium shrink-0 border transition",
                form.category === c ? "bix-gradient text-white border-transparent" : "border-border text-muted-foreground")}
            >
              {c}
            </button>
          ))}
        </div>

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Channel rules / about (optional)</label>
        <textarea
          value={form.rules}
          onChange={e => setForm(f => ({ ...f, rules: e.target.value }))}
          rows={2}
          placeholder="Guidelines for your subscribers"
          className={cn(field, "resize-none")}
        />

        <div className="flex items-start gap-2 mt-4 p-3 rounded-xl bg-secondary/50">
          <ShieldCheck className="w-4 h-4 text-primary shrink-0 mt-0.5" />
          <p className="text-[11px] text-muted-foreground">
            New channels are public. Monetization is a separate privilege that only verified accounts can apply for,
            and it's approved manually by Bixgram — never automatically.
          </p>
        </div>

        {step === "preview" && (
          <div className="mt-4 bix-card p-3">
            <p className="text-[11px] font-semibold text-muted-foreground mb-2">Preview</p>
            <div className="flex items-center gap-3 min-w-0">
              {avatar ? (
                <img src={avatar} alt="" className="w-12 h-12 rounded-2xl object-cover shrink-0" />
              ) : (
                <div className="w-12 h-12 rounded-2xl bix-gradient flex items-center justify-center text-white font-bold shrink-0">
                  {String(form.name || "?").charAt(0).toUpperCase()}
                </div>
              )}
              <div className="min-w-0">
                <div className="font-semibold text-sm truncate">{form.name || "Channel name"}</div>
                <div className="text-xs text-muted-foreground truncate">@{normalizeHandle(form.username) || "handle"}</div>
                <div className="text-[11px] text-muted-foreground truncate">No subscribers yet · {form.category}</div>
              </div>
            </div>
            {form.description && (
              <p className="text-xs text-muted-foreground mt-2 break-words">{form.description}</p>
            )}
          </div>
        )}

        {error && <p className="text-xs text-rose-400 mt-3">{error}</p>}

        {step === "form" ? (
          <button
            onClick={goPreview}
            disabled={uploading}
            className="w-full py-3 mt-4 rounded-full bix-gradient text-white text-sm font-semibold disabled:opacity-40 bix-press"
          >
            Preview channel
          </button>
        ) : (
          <div className="flex gap-2 mt-3">
            <button
              onClick={() => { setStep("form"); setError(""); }}
              className="flex-1 min-w-0 py-3 rounded-full bg-secondary text-sm font-semibold bix-press"
            >
              Back
            </button>
            <button
              onClick={submit}
              disabled={saving || uploading}
              className="flex-1 min-w-0 py-3 rounded-full bix-gradient text-white text-sm font-semibold disabled:opacity-40 bix-press"
            >
              {saving ? "Creating…" : "Create channel"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}