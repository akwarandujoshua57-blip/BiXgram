import React from "react";
import { BadgeCheck, Check, Plus, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatCount } from "@/lib/bixgram-data";

export default function ChannelCard({ channel, verified, subscribed, onToggle, onOpen }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-2xl bix-card">
      <button onClick={onOpen} className="shrink-0">
        {channel.avatar_url ? (
          <img src={channel.avatar_url} alt="" className="w-12 h-12 rounded-2xl object-cover" />
        ) : (
          <div className="w-12 h-12 rounded-2xl bix-gradient flex items-center justify-center text-white font-bold">
            {String(channel.name || "?").charAt(0).toUpperCase()}
          </div>
        )}
      </button>

      <button onClick={onOpen} className="flex-1 min-w-0 text-left">
        <div className="flex items-center gap-1 min-w-0">
          <span className="font-semibold text-sm truncate">{channel.name}</span>
          {verified && <BadgeCheck className="w-3.5 h-3.5 text-primary shrink-0" />}
        </div>
        <p className="text-xs text-muted-foreground truncate">@{channel.username}</p>
        <p className="text-[11px] text-muted-foreground flex items-center gap-1 mt-0.5">
          <Users className="w-3 h-3 shrink-0" />
          {formatCount(channel.subscribers_count || 0)} subscriber{(channel.subscribers_count || 0) === 1 ? "" : "s"}
          {channel.category ? ` · ${channel.category}` : ""}
        </p>
        {channel.description && (
          <p className="text-[11px] text-muted-foreground truncate mt-0.5">{channel.description}</p>
        )}
      </button>

      {onToggle && (
        <button
          onClick={() => onToggle(channel)}
          className={cn(
            "shrink-0 px-3.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1 transition bix-press",
            subscribed ? "bg-secondary text-muted-foreground" : "bix-gradient text-white"
          )}
        >
          {subscribed ? <><Check className="w-3 h-3" /> Subscribed</> : <><Plus className="w-3 h-3" /> Subscribe</>}
        </button>
      )}
    </div>
  );
}