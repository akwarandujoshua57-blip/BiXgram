import React from "react";
import moment from "moment";
import { AtSign, Tag, CalendarDays, ScrollText, Info } from "lucide-react";
import { formatCount } from "@/lib/bixgram-data";

// Public channel information. Every value is read from the channel record —
// nothing is inferred or invented.
export default function ChannelAbout({ channel }) {
  const rows = [
    { icon: AtSign, label: "Handle", value: `@${channel.username}` },
    { icon: Tag, label: "Category", value: channel.category || "General" },
    {
      icon: CalendarDays,
      label: "Created",
      value: channel.created_date ? moment(channel.created_date).format("D MMMM YYYY") : "—",
    },
    { icon: Info, label: "Visibility", value: channel.privacy === "private" ? "Private" : "Public" },
  ];

  return (
    <div className="px-4 mt-4 space-y-3">
      <div className="bix-card p-4">
        <h3 className="text-sm font-bold mb-3">About this channel</h3>
        <div className="space-y-2.5">
          {rows.map(r => (
            <div key={r.label} className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-secondary/60 flex items-center justify-center shrink-0">
                <r.icon className="w-4 h-4 text-muted-foreground" />
              </div>
              <span className="text-xs text-muted-foreground shrink-0">{r.label}</span>
              <span className="text-xs font-medium ml-auto truncate min-w-0">{r.value}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bix-card p-4">
        <h3 className="text-sm font-bold mb-2">Description</h3>
        {channel.description ? (
          <p className="text-sm whitespace-pre-wrap break-words">{channel.description}</p>
        ) : (
          <p className="text-xs text-muted-foreground">No description has been added yet.</p>
        )}
      </div>

      {channel.rules && (
        <div className="bix-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <ScrollText className="w-4 h-4 text-primary shrink-0" />
            <h3 className="text-sm font-bold">Channel rules</h3>
          </div>
          <p className="text-xs text-muted-foreground whitespace-pre-wrap break-words">{channel.rules}</p>
        </div>
      )}

      <div className="bix-card p-4">
        <h3 className="text-sm font-bold mb-2">At a glance</h3>
        <div className="grid grid-cols-2 gap-2">
          {[
            ["Subscribers", formatCount(channel.subscribers_count || 0)],
            ["Updates", formatCount(channel.content_count || 0)],
            ["Views", formatCount(channel.views_count || 0)],
          ].map(([label, value]) => (
            <div key={label} className="rounded-xl bg-secondary/40 p-3">
              <div className="text-lg font-extrabold">{value}</div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}