import React, { useEffect, useState } from "react";
import { Users, Loader2, UserMinus } from "lucide-react";
import { getChannelSubscribers, removeSubscriber } from "@/lib/channels";
import { defaultAvatar } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const LEVELS = [
  { key: "all", label: "All" },
  { key: "important", label: "Important" },
  { key: "muted", label: "Off" },
];

// The channel owner's audience. Reads real subscriber records only — an empty
// channel shows an empty state rather than invented followers.
export default function ChannelSubscribers({ channelId }) {
  const [rows, setRows] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    let alive = true;
    getChannelSubscribers(channelId).then(r => { if (alive) setRows(r); });
    return () => { alive = false; };
  }, [channelId]);

  const remove = async (s) => {
    await removeSubscriber(s.id);
    setRows(list => (list || []).filter(x => x.id !== s.id));
    toast({ title: `${s.user_name} removed from your subscribers` });
  };

  if (rows === null) {
    return (
      <div className="bix-card p-4 flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="w-4 h-4 animate-spin" /> Loading subscribers…
      </div>
    );
  }

  return (
    <div className="bix-card p-4">
      <div className="flex items-center gap-2 mb-3">
        <Users className="w-4 h-4 text-primary shrink-0" />
        <h3 className="font-bold text-sm">Subscribers</h3>
        <span className="ml-auto text-xs text-muted-foreground">{rows.length}</span>
      </div>

      {rows.length === 0 ? (
        <p className="text-xs text-muted-foreground py-4 text-center">
          No subscribers yet — they'll appear here as people subscribe.
        </p>
      ) : (
        <div className="space-y-1">
          {rows.map(s => (
            <div key={s.id} className="flex items-center gap-2.5 py-1.5 min-w-0">
              <img src={defaultAvatar(s.user_name)} alt="" className="w-8 h-8 rounded-full object-cover shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{s.user_name}</div>
                <div className="text-[10px] text-muted-foreground">
                  {LEVELS.find(l => l.key === s.notify_level)?.label || "All"} notifications
                </div>
              </div>
              <button
                onClick={() => remove(s)}
                aria-label={`Remove ${s.user_name}`}
                className={cn("w-8 h-8 rounded-full flex items-center justify-center shrink-0 hover:bg-secondary")}
              >
                <UserMinus className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}