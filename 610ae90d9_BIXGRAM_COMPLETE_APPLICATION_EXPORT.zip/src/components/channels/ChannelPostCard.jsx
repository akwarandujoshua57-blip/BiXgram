import React from "react";
import { BadgeCheck, Trash2, Link2, Megaphone } from "lucide-react";
import moment from "moment";
import { cn } from "@/lib/utils";

// One channel update. Rendered from the stored record — the author shown is
// always the channel this post belongs to.
export default function ChannelPostCard({ post, channel, verified, isOwner, onDelete }) {
  return (
    <article className="bix-card p-3.5">
      <div className="flex items-center gap-2.5 mb-2">
        {channel.avatar_url ? (
          <img src={channel.avatar_url} alt="" className="w-9 h-9 rounded-full object-cover shrink-0" />
        ) : (
          <div className="w-9 h-9 rounded-full bix-gradient flex items-center justify-center text-white text-xs font-bold shrink-0">
            {String(channel.name).charAt(0).toUpperCase()}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1 min-w-0">
            <span className="text-sm font-semibold truncate">{channel.name}</span>
            {verified && <BadgeCheck className="w-3.5 h-3.5 text-primary shrink-0" />}
          </div>
          <span className="text-[10px] text-muted-foreground">
            {post.created_date ? moment(post.created_date).format("DD MMM, HH:mm") : ""}
          </span>
        </div>
        {post.is_announcement && (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 shrink-0 flex items-center gap-1">
            <Megaphone className="w-3 h-3" /> Announcement
          </span>
        )}
        {isOwner && (
          <button
            onClick={() => onDelete(post)}
            aria-label="Delete update"
            className="w-8 h-8 rounded-full hover:bg-secondary flex items-center justify-center shrink-0"
          >
            <Trash2 className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        )}
      </div>

      {post.text && <p className="text-sm whitespace-pre-wrap break-words">{post.text}</p>}

      {post.media_urls?.length > 0 && (
        <div className={cn("grid gap-1.5 mt-2", post.media_urls.length === 1 ? "grid-cols-1" : "grid-cols-2")}>
          {post.media_urls.map((u, i) => (
            <img
              key={i}
              src={u}
              alt={`Photo shared by ${channel.name}`}
              loading="lazy"
              className={cn("w-full object-cover rounded-xl", post.media_urls.length === 1 ? "max-h-72" : "h-32")}
            />
          ))}
        </div>
      )}

      {post.video_url && (
        <video
          src={post.video_url}
          controls
          preload="metadata"
          playsInline
          className="w-full max-h-72 rounded-xl bg-black mt-2"
        />
      )}

      {post.link_url && (
        <a
          href={post.link_url}
          target="_blank"
          rel="noreferrer"
          className="flex items-center gap-2 mt-2 p-2.5 rounded-xl bg-secondary/50 min-w-0"
        >
          <Link2 className="w-4 h-4 text-primary shrink-0" />
          <span className="text-xs text-primary truncate">{post.link_url}</span>
        </a>
      )}
    </article>
  );
}