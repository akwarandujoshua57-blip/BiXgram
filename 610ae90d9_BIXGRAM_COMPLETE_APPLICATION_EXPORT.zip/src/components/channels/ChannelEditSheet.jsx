import React, { useState } from "react";
import { X, Loader2, Image as ImageIcon, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { uploadFile } from "@/lib/social";
import { CHANNEL_CATEGORIES, validateHandle, normalizeHandle, isHandleTaken } from "@/lib/channels";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

// Owner-facing channel editor. The channel record being updated is always the
// one the page loaded — the caller passes it in, and ownership is checked
// before this sheet is ever rendered.
export default function ChannelEditSheet({ open, onClose, channel, onSaved }) {
  const [form, setForm] = useState(() => ({
    name: channel?.name || "",
    username: channel?.username || "",
    description: channel?.description || "",
    category: channel?.category || "General",
    rules: channel?.rules || "",
    privacy: channel?.privacy || "public",
  }));
  const [avatar, setAvatar] = useState(channel?.avatar_url || null);
  const [cover, setCover] = useState(channel?.cover_url || null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const { toast } = useToast();

  if (!open || !channel) return null;

  const pick = async (e, setter) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be 5MB or smaller");
      return;
    }
    setError("");
    setUploading(true);
    try {
      setter(await uploadFile(file));
    } catch {
      setError("Couldn't upload that image. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const save = async () => {
    setError("");
    const name = form.name.trim();
    const handle = normalizeHandle(form.username);

    if (!name) return setError("Channel name is required");
    if (name.length > 50) return setError("Channel name must be 50 characters or fewer");
    const handleError = validateHandle(handle);
    if (handleError) return setError(handleError);
    if (form.description.length > 300) return setError("Description must be 300 characters or fewer");

    setSaving(true);
    try {
      // Uniqueness only needs checking when the handle actually changed.
      if (handle !== channel.username && await isHandleTaken(handle)) {
        setError("That handle is already taken");
        return;
      }
      await base44.entities.Channel.update(channel.id, {
        name,
        username: handle,
        description: form.description.trim(),
        category: form.category,
        rules: form.rules.trim(),
        privacy: form.privacy,
        avatar_url: avatar || undefined,
        cover_url: cover || undefined,
      });
      toast({ title: "Channel updated" });
      onSaved?.();
      onClose?.();
    } catch {
      setError("Couldn't save your changes. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const field = "w-full bg-secondary/50 rounded-xl px-3.5 py-2.5 outline-none text-sm mt-1 focus:ring-1 focus:ring-primary/40";

  return (
    <div className="fixed inset-0 z-[80] bg-black/60 flex items-end" onClick={onClose}>
      <div
        className="w-full max-w-2xl mx-auto bg-card border-t border-border rounded-t-2xl max-h-[90vh] overflow-y-auto overscroll-contain p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold">Edit channel</h3>
          <button onClick={onClose} aria-label="Close" className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex gap-3 mb-4">
          <label className="cursor-pointer shrink-0">
            {avatar ? (
              <img src={avatar} alt="Channel profile image" className="w-16 h-16 rounded-2xl object-cover" />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-secondary/60 flex items-center justify-center">
                {uploading ? <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /> : <ImageIcon className="w-5 h-5 text-muted-foreground" />}
              </div>
            )}
            <span className="block text-[10px] text-muted-foreground text-center mt-1">Profile</span>
            <input type="file" accept="image/*" hidden onChange={e => pick(e, setAvatar)} />
          </label>
          <label className="cursor-pointer flex-1 min-w-0">
            {cover ? (
              <img src={cover} alt="Channel cover image" className="w-full h-16 rounded-2xl object-cover" />
            ) : (
              <div className="w-full h-16 rounded-2xl bg-secondary/60 flex items-center justify-center">
                <ImageIcon className="w-5 h-5 text-muted-foreground" />
              </div>
            )}
            <span className="block text-[10px] text-muted-foreground text-center mt-1">Cover (optional)</span>
            <input type="file" accept="image/*" hidden onChange={e => pick(e, setCover)} />
          </label>
        </div>

        <label className="text-xs font-semibold text-muted-foreground">Channel name</label>
        <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className={field} />

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Handle</label>
        <div className="flex items-center gap-2 bg-secondary/50 rounded-xl px-3.5 mt-1">
          <span className="text-sm text-muted-foreground">@</span>
          <input
            value={form.username}
            onChange={e => setForm(f => ({ ...f, username: normalizeHandle(e.target.value) }))}
            className="flex-1 min-w-0 bg-transparent py-2.5 outline-none text-sm"
          />
        </div>
        <p className="text-[11px] text-muted-foreground mt-1">3–20 characters · letters, numbers and underscores</p>

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Description</label>
        <textarea
          value={form.description}
          onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
          rows={3}
          className={cn(field, "resize-none")}
        />

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Category</label>
        <div className="flex gap-2 overflow-x-auto no-scrollbar py-2">
          {CHANNEL_CATEGORIES.map(c => (
            <button
              key={c}
              onClick={() => setForm(f => ({ ...f, category: c }))}
              className={cn("px-3.5 py-1.5 rounded-full text-xs font-medium shrink-0 border transition",
                form.category === c ? "bix-gradient text-white border-transparent" : "border-border text-muted-foreground")}
            >
              {c}
            </button>
          ))}
        </div>

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Channel rules / about (optional)</label>
        <textarea
          value={form.rules}
          onChange={e => setForm(f => ({ ...f, rules: e.target.value }))}
          rows={2}
          className={cn(field, "resize-none")}
        />

        <label className="text-xs font-semibold text-muted-foreground mt-3 block">Visibility</label>
        <div className="flex gap-2 mt-1">
          {[
            { key: "public", label: "Public" },
            { key: "private", label: "Private" },
          ].map(o => (
            <button
              key={o.key}
              onClick={() => setForm(f => ({ ...f, privacy: o.key }))}
              className={cn("flex-1 min-w-0 py-2.5 rounded-xl text-xs font-semibold border transition flex items-center justify-center gap-1.5",
                form.privacy === o.key ? "bix-gradient text-white border-transparent" : "border-border text-muted-foreground")}
            >
              {form.privacy === o.key && <Check className="w-3.5 h-3.5" />} {o.label}
            </button>
          ))}
        </div>
        <p className="text-[11px] text-muted-foreground mt-1">
          Private channels don't appear in discovery or search.
        </p>

        {error && <p className="text-xs text-rose-400 mt-3">{error}</p>}

        <button
          onClick={save}
          disabled={saving || uploading}
          className="w-full py-3 mt-4 rounded-full bix-gradient text-white text-sm font-semibold disabled:opacity-40 bix-press"
        >
          {saving ? "Saving…" : "Save changes"}
        </button>
      </div>
    </div>
  );
}