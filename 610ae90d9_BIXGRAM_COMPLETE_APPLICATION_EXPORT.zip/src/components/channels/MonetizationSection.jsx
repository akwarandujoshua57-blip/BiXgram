import React, { useEffect, useState } from "react";
import { BadgeCheck, ShieldCheck, Clock, XCircle, PauseCircle, CheckCircle2, Info } from "lucide-react";
import { getMe } from "@/lib/social";
import {
  computeEligibility, getMonetizationApproval, getMyApplication,
  submitMonetizationApplication, monetizationLabel,
} from "@/lib/channels";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";
import { formatCount } from "@/lib/bixgram-data";

// Owner-facing monetization panel.
//
// Submitting an application never monetizes anything — it only puts the channel
// in a review queue. The decision itself lives in an admin-only record, so no
// action here can approve a channel.
export default function MonetizationSection({ channel, isOwner }) {
  const [eligibility, setEligibility] = useState(null);
  const [approval, setApproval] = useState(null);
  const [application, setApplication] = useState(null);
  const [accepted, setAccepted] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const load = async () => {
    if (!isOwner || !channel?.id) { setLoading(false); return; }
    try {
      const [app, mon, me] = await Promise.all([
        getMyApplication(channel.id),
        getMonetizationApproval(channel.id),
        getMe(),
      ]);
      setApplication(app);
      setApproval(mon);
      // This section only renders for the channel owner, so eligibility is
      // always measured against the signed-in account's real activity.
      setEligibility(await computeEligibility(channel, app?.owner_name || me.name));
    } catch {}
    setLoading(false);
  };

  useEffect(() => { load(); }, [channel?.id, isOwner]);

  if (!isOwner || loading) return null;

  const status = monetizationLabel(approval, application);
  const toneClass = {
    ok: "bg-emerald-500/10 text-emerald-400",
    warn: "bg-amber-500/10 text-amber-400",
    bad: "bg-rose-500/10 text-rose-400",
  };

  // An approved/active decision is final until an administrator changes it.
  if (status) {
    const Icon = status.tone === "ok" ? CheckCircle2 : status.tone === "warn" ? PauseCircle : XCircle;
    return (
      <div className="rounded-2xl bix-card p-4">
        <div className="flex items-center gap-2">
          <Icon className={cn("w-4 h-4", status.tone === "ok" ? "text-emerald-400" : status.tone === "warn" ? "text-amber-400" : "text-rose-400")} />
          <span className="text-sm font-semibold">{status.label}</span>
        </div>
        <p className="text-xs text-muted-foreground mt-1.5">
          {status.tone === "ok"
            ? "Bixgram approved monetization for this channel. Earnings tools arrive in a later phase."
            : approval?.status === "rejected"
              ? "This channel wasn't approved for monetization."
              : approval?.status === "revoked"
                ? "Monetization for this channel has been revoked by Bixgram."
                : approval?.status === "suspended"
                  ? "Monetization for this channel is currently suspended."
                  : "Your application is with the Bixgram team. You'll be notified once it's reviewed."}
        </p>
      </div>
    );
  }

  const unmet = (eligibility?.checks || []).filter(c => !c.met);

  return (
    <div className="rounded-2xl bix-card p-4">
      <div className="flex items-center gap-2 mb-2">
        <ShieldCheck className="w-4 h-4 text-primary" />
        <span className="text-sm font-semibold">Channel monetization</span>
      </div>

      <div className="rounded-xl bg-secondary/50 p-3 mb-3">
        <p className="text-[11px] font-semibold mb-1.5">Subscriber pricing</p>
        <div className="space-y-1 text-[11px]">
          <div className="flex justify-between gap-2">
            <span className="text-muted-foreground min-w-0">First 1,000 subscribers</span>
            <span className="font-semibold shrink-0">$2 / subscriber / month</span>
          </div>
          <div className="flex justify-between gap-2">
            <span className="text-muted-foreground min-w-0">Subscribers 1,001 and above</span>
            <span className="font-semibold shrink-0">$5 / subscriber / month</span>
          </div>
        </div>
        <p className="text-[10px] text-muted-foreground mt-2">
          Billed monthly and renewed each month until cancelled. Subscribers may cancel at any time and keep access
          until the end of the period already paid for. Billing is not connected yet — nothing is charged today, and
          this section is a foundation only.
        </p>
      </div>

      {!eligibility?.verified ? (
        <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-500/10">
          <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="text-xs text-amber-300">
            Monetized channels are available only to <strong>verified</strong> users. Verification is granted by
            Bixgram — a premium plan alone doesn't qualify, and it can't be self-assigned.
          </p>
        </div>
      ) : (
        <>
          <p className="text-xs text-muted-foreground mb-3">
            Meeting these requirements makes your channel eligible to <strong>apply</strong>. Every application is
            reviewed and approved manually by Bixgram.
          </p>
          <div className="space-y-1.5 mb-3">
            {(eligibility?.checks || []).map(c => (
              <div key={c.key} className="flex items-center justify-between gap-2 text-xs">
                <span className="text-muted-foreground truncate">{c.label}</span>
                <span className={cn("shrink-0 font-medium", c.met ? "text-emerald-400" : "text-muted-foreground")}>
                  {typeof c.have === "number" ? formatCount(c.have) : c.have}
                  {!c.met && typeof c.need === "number" ? ` / ${formatCount(c.need)}` : ""}
                </span>
              </div>
            ))}
          </div>

          {eligibility?.eligible ? (
            <>
              <label className="flex items-start gap-2 p-3 rounded-xl bg-secondary/50 mb-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={accepted}
                  onChange={e => setAccepted(e.target.checked)}
                  className="mt-0.5 w-4 h-4 accent-[hsl(var(--primary))] shrink-0"
                />
                <span className="text-[11px] text-muted-foreground">
                  I confirm this channel follows Bixgram's policies, that its audience is genuine, and I accept the
                  monetization terms. I understand approval is at Bixgram's discretion.
                </span>
              </label>
              <button
                onClick={async () => {
                  setSaving(true);
                  try {
                    await submitMonetizationApplication(channel, eligibility, accepted);
                    toast({ title: "Application submitted", description: "It's now pending review." });
                    await load();
                  } catch {
                    toast({ title: "Could not submit application", variant: "destructive" });
                  } finally {
                    setSaving(false);
                  }
                }}
                disabled={!accepted || saving}
                className="w-full py-2.5 rounded-full bix-gradient text-white text-sm font-semibold disabled:opacity-40 bix-press"
              >
                {saving ? "Submitting…" : "Apply for channel monetization"}
              </button>
            </>
          ) : (
            <div className="flex items-start gap-2 p-3 rounded-xl bg-secondary/50">
              <Clock className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
              <p className="text-[11px] text-muted-foreground">
                {unmet.length} requirement{unmet.length === 1 ? "" : "s"} still to meet before you can apply.
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}