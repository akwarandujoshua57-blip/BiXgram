import React from "react";
import { cn } from "@/lib/utils";

// Channel content tabs. Only tabs the channel can actually fill are shown —
// nothing is added just to make the bar look busier.
export default function ChannelTabs({ tabs, value, onChange }) {
  return (
    <div className="sticky top-0 z-30 bg-background/85 backdrop-blur-xl border-b border-border">
      <div className="flex overflow-x-auto no-scrollbar px-2">
        {tabs.map(t => {
          const active = value === t.key;
          return (
            <button
              key={t.key}
              onClick={() => onChange(t.key)}
              aria-current={active ? "page" : undefined}
              className={cn(
                "relative shrink-0 px-4 py-3 text-sm font-semibold transition-colors whitespace-nowrap",
                active ? "text-foreground" : "text-muted-foreground"
              )}
            >
              {t.label}
              {t.count > 0 && <span className="ml-1.5 text-[11px] opacity-60">{t.count}</span>}
              {active && <span className="absolute bottom-0 left-3 right-3 h-[2.5px] rounded-full bix-gradient" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}