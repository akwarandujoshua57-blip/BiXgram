import React, { useEffect, useState } from "react";
import { Loader2, BarChart3 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { formatCount } from "@/lib/bixgram-data";

// Owner analytics, measured from the channel's real stored content only.
// Nothing here is estimated, projected or filled in — a brand new channel
// genuinely shows zeroes and the "No activity yet" line.
export default function ChannelAnalytics({ channel }) {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      const posts = await base44.entities.ChannelPost
        .filter({ channel_id: String(channel.id) }, "-created_date", 200)
        .catch(() => []);
      if (!alive) return;
      const sum = (key) => posts.reduce((s, p) => s + (p[key] || 0), 0);
      setStats({
        posts: posts.length,
        videos: posts.filter(p => p.video_url).length,
        photos: posts.filter(p => p.media_urls?.length).length,
        announcements: posts.filter(p => p.is_announcement).length,
        views: sum("views_count"),
        likes: sum("likes_count"),
        comments: sum("comments_count"),
      });
    })();
    return () => { alive = false; };
  }, [channel.id]);

  if (!stats) {
    return (
      <div className="bix-card p-4 flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="w-4 h-4 animate-spin" /> Loading activity…
      </div>
    );
  }

  const metrics = [
    ["Subscribers", channel.subscribers_count || 0],
    ["Posts", stats.posts],
    ["Videos", stats.videos],
    ["Photos", stats.photos],
    ["Views", stats.views],
    ["Likes", stats.likes],
    ["Comments", stats.comments],
    ["Announcements", stats.announcements],
  ];

  const noActivity = metrics.every(([, v]) => !v);

  return (
    <div className="bix-card p-4">
      <div className="flex items-center gap-2 mb-3">
        <BarChart3 className="w-4 h-4 text-primary shrink-0" />
        <h3 className="text-sm font-bold">Channel analytics</h3>
      </div>

      {noActivity ? (
        <div className="text-center py-6">
          <p className="text-sm font-semibold">No activity yet</p>
          <p className="text-xs text-muted-foreground mt-1">
            Stats appear here once your channel has real subscribers and content.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          {metrics.map(([label, value]) => (
            <div key={label} className="rounded-xl bg-secondary/40 p-3 min-w-0">
              <div className="text-lg font-extrabold truncate">{formatCount(value)}</div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground truncate">{label}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}