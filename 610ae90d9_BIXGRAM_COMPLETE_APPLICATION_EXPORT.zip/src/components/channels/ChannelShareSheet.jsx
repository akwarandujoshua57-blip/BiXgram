import React from "react";
import { X, Send, Link2, Share2, Radio } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";

// Channel sharing. The link is always built from the channel record the page
// already loaded — never from a value supplied by the client — so a shared
// link always resolves to a real channel.
export default function ChannelShareSheet({ open, onClose, channel }) {
  const navigate = useNavigate();
  const { toast } = useToast();
  if (!open || !channel) return null;

  const link = `${window.location.origin}/channels/${channel.id}`;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(link);
      toast({ title: "Channel link copied" });
    } catch {
      toast({ title: "Could not copy the link", variant: "destructive" });
    }
    onClose();
  };

  const shareExternally = async () => {
    try {
      if (navigator.share) await navigator.share({ title: channel.name, url: link });
      else await copyLink();
    } catch {}
    onClose();
  };

  const sendInMessenger = () => {
    onClose();
    navigate("/messenger");
  };

  const options = [
    { label: "Send in Messenger", hint: "Share this channel with a friend", icon: Send, color: "from-purple-500 to-indigo-600", action: sendInMessenger },
    { label: "Copy Link", hint: "Copy a direct link to this channel", icon: Link2, color: "from-slate-400 to-slate-600", action: copyLink },
    { label: "Share Externally", hint: "Share outside Bixgram", icon: Share2, color: "from-cyan-500 to-blue-600", action: shareExternally },
  ];

  return (
    <div className="fixed inset-0 z-[80] bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
      <div
        className="w-full max-w-md bg-card rounded-t-3xl p-4 pb-6 safe-bottom"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-base">Share channel</h3>
          <button onClick={onClose} aria-label="Close" className="bix-icon-btn w-8 h-8">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-3 p-3 rounded-2xl bg-secondary/40 mb-3 min-w-0">
          <Radio className="w-4 h-4 text-muted-foreground shrink-0" />
          <p className="text-xs text-muted-foreground truncate">
            {channel.name} — @{channel.username}
          </p>
        </div>

        <div className="space-y-1">
          {options.map(o => (
            <button
              key={o.label}
              onClick={o.action}
              className="w-full flex items-center gap-3 p-2.5 rounded-2xl hover:bg-secondary/50 transition text-left bix-press"
            >
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${o.color} flex items-center justify-center shrink-0`}>
                <o.icon className="w-5 h-5 text-white" />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-semibold">{o.label}</div>
                <div className="text-[11px] text-muted-foreground truncate">{o.hint}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}