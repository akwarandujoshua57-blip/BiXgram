import React, { useEffect, useRef, useState } from "react";
import { Plus, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getMe, getProfile, defaultAvatar, uploadFile } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import StoryViewer from "@/components/feed/StoryViewer";

export default function StorySection() {
  const [stories, setStories] = useState([]);
  const [me, setMe] = useState({ name: "", avatar: "" });
  const [uploading, setUploading] = useState(false);
  const [viewerIndex, setViewerIndex] = useState(null);
  const [viewedIds, setViewedIds] = useState([]);
  const fileRef = useRef(null);
  const { toast } = useToast();

  useEffect(() => {
    (async () => {
      try {
        const m = await getMe();
        let avatar = defaultAvatar(m.name);
        try { avatar = (await getProfile(m.name)).avatar_url || avatar; } catch {}
        setMe({ name: m.name, avatar });
        setStories(await base44.entities.Story.list("-created_date", 20));
      } catch {}
    })();
  }, []);

  const onPick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast({ title: "Stories accept photos for now", variant: "destructive" });
      return;
    }
    setUploading(true);
    try {
      const url = await uploadFile(file);
      const created = await base44.entities.Story.create({
        user_name: me.name,
        user_avatar: me.avatar,
        media_url: url,
        is_viewed: false,
      });
      setStories(s => [created, ...s]);
      toast({ title: "Story added ✨" });
    } catch {
      toast({ title: "Could not add your story", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const markViewed = (id) => setViewedIds(v => (v.includes(id) ? v : [...v, id]));

  return (
    <div className="px-3 py-3 overflow-x-auto no-scrollbar">
      <div className="flex gap-3">
        <button onClick={() => fileRef.current?.click()} className="flex flex-col items-center gap-1.5 shrink-0 w-[72px]">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bix-ring p-[2.5px]">
              <img src={me.avatar || defaultAvatar(me.name)} alt="me" className="w-full h-full rounded-full object-cover border-2 border-background" />
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full bix-gradient flex items-center justify-center border-2 border-background">
              {uploading ? <Loader2 className="w-3 h-3 text-white animate-spin" /> : <Plus className="w-3 h-3 text-white" strokeWidth={3} />}
            </div>
          </div>
          <span className="text-[11px] text-muted-foreground truncate max-w-[68px]">Add Story</span>
        </button>

        {stories.map((s, i) => (
          <button
            key={s.id || i}
            onClick={() => setViewerIndex(i)}
            className="flex flex-col items-center gap-1.5 shrink-0 w-[72px]"
          >
            <div className={(s.is_viewed || viewedIds.includes(s.id)) ? "w-16 h-16 rounded-full bg-secondary p-[2.5px]" : "w-16 h-16 rounded-full bix-ring p-[2.5px]"}>
              <img src={s.user_avatar} alt={s.user_name} className="w-full h-full rounded-full object-cover border-2 border-background" />
            </div>
            <span className="text-[11px] text-muted-foreground truncate max-w-[68px]">
              {String(s.user_name || "").split(" ")[0]}
            </span>
          </button>
        ))}
      </div>

      <input ref={fileRef} type="file" accept="image/*" hidden onChange={onPick} />

      {viewerIndex !== null && (
        <StoryViewer
          stories={stories}
          startIndex={viewerIndex}
          onViewed={markViewed}
          onClose={() => setViewerIndex(null)}
        />
      )}
    </div>
  );
}