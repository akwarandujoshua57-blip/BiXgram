import React, { useState } from "react";
import { X, Trash2, Edit3, Flag, BadgeCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import ReportSheet from "@/components/shared/ReportSheet";
import { cn } from "@/lib/utils";

export default function PostMenuSheet({ post, isMine, open, onClose, onEdited, onDeleted }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(post.text || "");
  const [reporting, setReporting] = useState(false);
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();

  if (!open) return null;

  const saveEdit = async () => {
    if (!text.trim()) { toast({ title: "Post can't be empty", variant: "destructive" }); return; }
    setBusy(true);
    try {
      await base44.entities.Post.update(post.id, { text: text.trim() });
      toast({ title: "Post updated" });
      onEdited?.({ ...post, text: text.trim() });
      onClose?.();
    } catch {
      toast({ title: "Could not update post", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const del = async () => {
    setBusy(true);
    try {
      await base44.entities.Post.delete(post.id);
      toast({ title: "Post deleted" });
      onDeleted?.(post);
      onClose?.();
    } catch {
      toast({ title: "Could not delete post", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
        <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-1" onClick={e => e.stopPropagation()}>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-lg">Post</h3>
            <button onClick={onClose} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
              <X className="w-4 h-4" />
            </button>
          </div>

          {isMine ? (
            <>
              <button
                onClick={() => setEditing(true)}
                className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-secondary/50 transition text-left"
              >
                <Edit3 className="w-5 h-5 text-primary" />
                <span className="font-medium text-sm">Edit post</span>
              </button>
              <button
                onClick={del}
                disabled={busy}
                className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-rose-500/10 transition text-left disabled:opacity-50"
              >
                <Trash2 className="w-5 h-5 text-rose-400" />
                <span className="font-medium text-sm text-rose-400">Delete post</span>
              </button>
            </>
          ) : (
            <button
              onClick={() => setReporting(true)}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-rose-500/10 transition text-left"
            >
              <Flag className="w-5 h-5 text-rose-400" />
              <span className="font-medium text-sm text-rose-400">Report post</span>
            </button>
          )}

          <button onClick={onClose} className="w-full p-3 text-center text-sm text-muted-foreground">Cancel</button>
        </div>
      </div>

      {editing && (
        <div className="fixed inset-0 z-[70] bg-black/60 backdrop-blur flex items-end justify-center" onClick={() => setEditing(false)}>
          <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-3" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-2">
              <BadgeCheck className="w-5 h-5 text-primary" />
              <h3 className="font-bold text-lg">Edit post</h3>
            </div>
            <textarea
              value={text}
              onChange={e => setText(e.target.value)}
              rows={4}
              className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none resize-none"
            />
            <button
              onClick={saveEdit}
              disabled={busy || !text.trim()}
              className="w-full py-3 rounded-xl bix-gradient text-white font-semibold disabled:opacity-50"
            >
              {busy ? "Saving…" : "Save changes"}
            </button>
          </div>
        </div>
      )}

      <ReportSheet
        open={reporting}
        onClose={() => { setReporting(false); onClose?.(); }}
        targetType="post"
        targetId={post.id}
        targetLabel={post.text}
      />
    </>
  );
}