import React, { useState, useEffect, useRef } from "react";
import { X, Send, Trash2, Heart, BadgeCheck } from "lucide-react";
import moment from "moment";
import { base44 } from "@/api/base44Client";
import { addComment, setReaction, getMe } from "@/lib/social";
import { cn } from "@/lib/utils";

export default function CommentSheet({ open, onClose, targetType, targetId, entity, author, onCountChange }) {
  const [comments, setComments] = useState([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [me, setMe] = useState(null);
  const [myLikes, setMyLikes] = useState({});    // commentId -> liked by me
  const [likeDeltas, setLikeDeltas] = useState({}); // commentId -> count delta
  const inputRef = useRef(null);

  useEffect(() => {
    if (!open || !targetId) return;
    setLoading(true);
    (async () => {
      try {
        const [list, m] = await Promise.all([
          base44.entities.Comment.filter({ post_id: String(targetId) }, "-created_date", 50),
          getMe().catch(() => null),
        ]);
        setComments(list);
        setMe(m);
        if (m) {
          const mine = await base44.entities.Reaction.filter({
            target_type: "comment", user_name: m.name,
          }).catch(() => []);
          setMyLikes(Object.fromEntries(mine.map(r => [String(r.target_id), true])));
        }
      } catch {
        setComments([]);
      } finally {
        setLoading(false);
      }
    })();
    setTimeout(() => inputRef.current?.focus(), 150);
  }, [open, targetId]);

  if (!open) return null;

  const submit = async () => {
    const t = text.trim();
    if (!t) return;
    setText("");
    const c = await addComment({ targetType, targetId, text: t, entity, author }).catch(() => null);
    if (c) {
      setComments(cs => [c, ...cs]);
      onCountChange?.(1);
    }
  };

  const likeComment = async (c) => {
    const res = await setReaction("comment", c.id, "like", {
      entity: base44.entities.Comment,
      author: c.author_name,
      verb: "liked your comment",
    }).catch(() => null);
    if (res) {
      setMyLikes(m => {
        const next = { ...m };
        if (res.reaction) next[String(c.id)] = true;
        else delete next[String(c.id)];
        return next;
      });
      setLikeDeltas(d => ({ ...d, [c.id]: (d[c.id] || 0) + res.delta }));
    }
  };

  const deleteComment = async (c) => {
    try {
      await base44.entities.Comment.delete(c.id);
      await entity.updateMany({ id: targetId }, { $inc: { comments_count: -1 } });
      setComments(cs => cs.filter(x => x.id !== c.id));
      onCountChange?.(-1);
    } catch {}
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end justify-center" onClick={onClose}>
      <div
        className="w-full max-w-md bg-card rounded-t-3xl flex flex-col"
        style={{ maxHeight: "75vh" }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h3 className="font-bold">Comments {comments.length > 0 && <span className="text-muted-foreground text-sm">({comments.length})</span>}</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-3 min-h-[30vh]">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="w-7 h-7 border-4 border-secondary border-t-primary rounded-full animate-spin" />
            </div>
          ) : comments.length === 0 ? (
            <div className="text-center py-8 text-sm text-muted-foreground">No comments yet. Be the first! 💬</div>
          ) : (
            comments.map(c => {
              const liked = !!myLikes[String(c.id)];
              const likeCount = Math.max(0, (c.likes_count || 0) + (likeDeltas[c.id] || 0));
              return (
                <div key={c.id} className="flex gap-2.5">
                  <img src={c.author_avatar} alt="" className="w-9 h-9 rounded-full object-cover shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="bg-secondary/50 rounded-2xl rounded-tl-md px-3 py-2">
                      <div className="flex items-center gap-1">
                        <span className="font-semibold text-xs">{c.author_name}</span>
                        {c.author_verified && <BadgeCheck className="w-3.5 h-3.5 text-primary" />}
                      </div>
                      <p className="text-sm">{c.text}</p>
                    </div>
                    <div className="flex items-center gap-3 mt-1 px-1">
                      <span className="text-[10px] text-muted-foreground">
                        {c.created_date ? moment(c.created_date).fromNow() : "just now"}
                      </span>
                      <button
                        onClick={() => likeComment(c)}
                        className="flex items-center gap-1 text-[10px] font-medium"
                      >
                        <Heart className={cn("w-3.5 h-3.5", liked ? "fill-rose-500 text-rose-500" : "text-muted-foreground")} />
                        {likeCount > 0 && <span className={cn(liked ? "text-rose-400" : "text-muted-foreground")}>{likeCount}</span>}
                      </button>
                      {me && c.author_name === me.name && (
                        <button onClick={() => deleteComment(c)} className="text-[10px] font-medium text-muted-foreground hover:text-rose-400 transition flex items-center gap-0.5">
                          <Trash2 className="w-3 h-3" /> Delete
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="p-3 border-t border-border flex items-center gap-2 safe-bottom">
          <div className="flex-1 flex items-center bg-secondary/50 rounded-full px-4 py-2">
            <input
              ref={inputRef}
              value={text}
              onChange={e => setText(e.target.value)}
              onKeyDown={e => e.key === "Enter" && submit()}
              placeholder="Add a comment…"
              className="flex-1 bg-transparent outline-none text-sm"
            />
          </div>
          <button
            onClick={submit}
            disabled={!text.trim()}
            className="w-10 h-10 rounded-full bix-gradient flex items-center justify-center disabled:opacity-40"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}