import React, { useState, useEffect } from "react";
import { X, Zap, Rocket, TrendingUp } from "lucide-react";
import { formatCount } from "@/lib/bixgram-data";
import { PROMO_PACKAGES, PROMO_DURATIONS, promotePost, getPromotionsForPost } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export default function PromoteSheet({ post, onClose }) {
  const [pkg, setPkg] = useState(PROMO_PACKAGES[1]);
  const [duration, setDuration] = useState(7);
  const [active, setActive] = useState(null);
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    getPromotionsForPost(post.id).then(p => setActive(p[0] || null));
  }, [post.id]);

  const estimated = Math.round(pkg.views * (duration / 7));

  const start = async () => {
    setBusy(true);
    try {
      const promo = await promotePost({ postId: post.id, pkg, durationDays: duration });
      setActive(promo);
      toast({ title: "Promotion started 🚀", description: "Estimated views are targets, not guarantees." });
    } catch {
      toast({ title: "Could not start promotion", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
      <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-4 max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-lg flex items-center gap-2"><Rocket className="w-5 h-5 text-primary" /> Promote Post</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-muted-foreground -mt-2">Boost "{(post.text || "your post").slice(0, 40)}{post.text?.length > 40 ? "…" : ""}"</p>

        {active ? (
          <div className="bix-card p-4 bg-gradient-to-br from-card to-secondary/30">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Promotion Active
              </span>
              <span className="text-[10px] text-muted-foreground uppercase">{active.duration_days}-day plan</span>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              <span className="text-sm font-semibold">Estimated audience: {formatCount(active.estimated_views)} views</span>
            </div>
            <p className="text-[10px] text-muted-foreground mt-1.5">Estimates are promotional targets — not guaranteed results.</p>
          </div>
        ) : (
          <>
            <div>
              <label className="text-xs text-muted-foreground">Choose a package</label>
              <div className="grid grid-cols-3 gap-2 mt-1.5">
                {PROMO_PACKAGES.map(p => (
                  <button
                    key={p.key}
                    onClick={() => setPkg(p)}
                    className={cn(
                      "bix-card p-3 text-center transition",
                      pkg.key === p.key && "ring-2 ring-primary"
                    )}
                  >
                    <div className={cn("w-9 h-9 rounded-xl bg-gradient-to-br mx-auto mb-2 flex items-center justify-center", p.color)}>
                      <Zap className="w-4 h-4 text-white" />
                    </div>
                    <div className="font-extrabold">${p.price}</div>
                    <div className="text-[10px] text-muted-foreground">~{formatCount(p.views)} views</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs text-muted-foreground">Duration</label>
              <div className="flex gap-2 mt-1.5">
                {PROMO_DURATIONS.map(d => (
                  <button
                    key={d}
                    onClick={() => setDuration(d)}
                    className={cn(
                      "flex-1 py-2 rounded-xl text-xs font-semibold transition",
                      duration === d ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground"
                    )}
                  >
                    {d} days
                  </button>
                ))}
              </div>
            </div>

            <div className="bix-card p-3 flex items-center justify-between">
              <span className="text-xs text-muted-foreground">Estimated audience</span>
              <span className="font-bold text-sm bix-gradient-text">~{formatCount(estimated)} views</span>
            </div>
            <p className="text-[10px] text-muted-foreground -mt-2">Estimates are promotional targets — not guaranteed results.</p>

            <button
              onClick={start}
              disabled={busy}
              className="w-full py-3 rounded-xl bix-gradient text-white font-semibold disabled:opacity-50"
            >
              {busy ? "Starting…" : `Pay $${pkg.price} & Promote`}
            </button>
            <p className="text-[10px] text-muted-foreground text-center">Payment-ready structure — connects to a payment provider at checkout.</p>
          </>
        )}
      </div>
    </div>
  );
}