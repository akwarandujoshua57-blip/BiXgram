import React from "react";
import { X, Send, Link2, Share2, Bookmark } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { sharePost } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";

export default function ShareSheet({ open, onClose, post, onShared }) {
  const navigate = useNavigate();
  const { toast } = useToast();
  if (!open) return null;

  const link = `${window.location.origin}/post/${post.id}`;

  const shareToFeed = async () => {
    const res = await sharePost("post", post.id, {
      entity: base44.entities.Post,
      author: post.author_name,
    }).catch(() => null);
    if (res) onShared?.(1);
    onClose();
    toast({ title: res ? "Shared to your feed" : "Could not share right now", variant: res ? undefined : "destructive" });
  };

  const sendInMessenger = () => {
    onClose();
    navigate("/messenger");
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(link);
      toast({ title: "Link copied" });
    } catch {
      toast({ title: "Could not copy link", variant: "destructive" });
    }
    onClose();
  };

  const options = [
    { label: "Share to Feed", hint: "Post it to your timeline", icon: Share2, color: "from-cyan-500 to-blue-600", action: shareToFeed },
    { label: "Send in Messenger", hint: "Send this to a friend", icon: Send, color: "from-purple-500 to-indigo-600", action: sendInMessenger },
    { label: "Copy Link", hint: "Copy a direct link to this post", icon: Link2, color: "from-slate-400 to-slate-600", action: copyLink },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
      <div
        className="w-full max-w-md bg-card rounded-t-3xl p-4 pb-6 safe-bottom"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-base">Share post</h3>
          <button onClick={onClose} aria-label="Close" className="bix-icon-btn w-8 h-8">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-3 p-3 rounded-2xl bg-secondary/40 mb-3">
          <Bookmark className="w-4 h-4 text-muted-foreground shrink-0" />
          <p className="text-xs text-muted-foreground line-clamp-2">
            {(post.text || "Media post").slice(0, 100)} — @{post.author_name}
          </p>
        </div>

        <div className="space-y-1">
          {options.map(o => (
            <button
              key={o.label}
              onClick={o.action}
              className="w-full flex items-center gap-3 p-2.5 rounded-2xl hover:bg-secondary/50 transition text-left bix-press"
            >
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${o.color} flex items-center justify-center shrink-0`}>
                <o.icon className="w-5 h-5 text-white" />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-semibold">{o.label}</div>
                <div className="text-[11px] text-muted-foreground truncate">{o.hint}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}