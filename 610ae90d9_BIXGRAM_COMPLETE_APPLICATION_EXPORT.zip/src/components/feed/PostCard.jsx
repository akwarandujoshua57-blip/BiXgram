import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Heart, MessageCircle, Share2, Bookmark, Eye, BadgeCheck, Globe2, Globe, Megaphone } from "lucide-react";
import moment from "moment";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import { formatCount } from "@/lib/bixgram-data";
import { getMe, getMyReaction, setReaction, toggleSave, isSavedByMe } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import CommentSheet from "@/components/feed/CommentSheet";
import PromoteSheet from "@/components/feed/PromoteSheet";
import PostMenuSheet from "@/components/feed/PostMenuSheet";
import ShareSheet from "@/components/feed/ShareSheet";
import { cn } from "@/lib/utils";

const REACTIONS = { like: "👍", love: "❤️", haha: "😂", wow: "😮", sad: "😢", angry: "😡" };

export default function PostCard({ post }) {
  const [reaction, setLocalReaction] = useState(null);
  const [saved, setSaved] = useState(false);
  const [counts, setCounts] = useState({
    likes: post.likes_count || 0,
    comments: post.comments_count || 0,
    shares: post.shares_count || 0,
    saves: post.saves_count || 0,
  });
  const [showPicker, setShowPicker] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [isMine, setIsMine] = useState(false);
  const [promoteOpen, setPromoteOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [localText, setLocalText] = useState(null);
  const [deleted, setDeleted] = useState(false);
  const pressTimer = useRef(null);
  const { toast } = useToast();

  useEffect(() => {
    (async () => {
      setLocalReaction(await getMyReaction("post", post.id).catch(() => null));
      setSaved(await isSavedByMe("post", post.id).catch(() => false));
      try {
        const me = await getMe();
        setIsMine(me.name === post.author_name);
      } catch {}
    })();
  }, [post.id]);

  const react = async (key) => {
    setShowPicker(false);
    const res = await setReaction("post", post.id, key, {
      entity: base44.entities.Post,
      author: post.author_name,
      verb: "reacted to your post",
    }).catch(() => null);
    if (res) {
      setLocalReaction(res.reaction);
      setCounts(c => ({ ...c, likes: c.likes + res.delta }));
    }
  };

  const startPress = () => {
    pressTimer.current = setTimeout(() => setShowPicker(true), 450);
  };
  const endPress = () => clearTimeout(pressTimer.current);

  const onSave = async () => {
    const res = await toggleSave("post", post.id).catch(() => null);
    if (res) {
      setSaved(res.saved);
      setCounts(c => ({ ...c, saves: c.saves + res.delta }));
      toast({ title: res.saved ? "Saved to your collection" : "Removed from saved" });
    }
  };

  if (deleted) return null;

  const profilePath = `/profile/${encodeURIComponent(post.author_name)}`;
  const photos = post.media_urls?.length
    ? post.media_urls.slice(0, 4)
    : post.image_url ? [post.image_url] : [];

  return (
    <article className="mx-3 my-2 bix-card overflow-hidden">
      <div className="flex items-center gap-3 p-3">
        <Link to={profilePath}>
          <img src={post.author_avatar} alt={post.author_name} className="w-11 h-11 rounded-full object-cover" />
        </Link>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1 flex-wrap">
            <Link to={profilePath} className="font-semibold text-sm truncate hover:underline">{post.author_name}</Link>
            {post.author_verified && <BadgeCheck className="w-4 h-4 text-primary fill-primary/20 shrink-0" />}
            {post.collab_partner_name && (
              <>
                <span className="text-muted-foreground text-xs">+ </span>
                <span className="font-semibold text-sm truncate">{post.collab_partner_name}</span>
                {post.collab_partner_avatar && <img src={post.collab_partner_avatar} alt="" className="w-4 h-4 rounded-full" />}
              </>
            )}
          </div>
          <div className="text-xs text-muted-foreground flex items-center gap-1.5 flex-wrap">
            <span>{post.created_date ? moment(post.created_date).fromNow() : "now"}</span>
            <span title="Public post" className="flex items-center"><Globe className="w-3 h-3" /></span>
            {post.feeling && <span>· is feeling {post.feeling}</span>}
            {post.location && <span>· {post.location}</span>}
            {post.world_name && (
              <Link to={`/communities/${post.world_id}`} className="flex items-center gap-0.5 text-primary hover:underline">
                <Globe2 className="w-3 h-3" /> {post.world_name}
              </Link>
            )}
          </div>
        </div>
        <button onClick={() => setMenuOpen(true)} className="text-muted-foreground text-xl leading-none px-2">⋯</button>
      </div>

      {(localText ?? post.text) && <p className="px-3 pb-3 text-sm leading-relaxed whitespace-pre-wrap">{localText ?? post.text}</p>}

      {photos.length > 0 && (
        <div className={cn("grid gap-0.5", photos.length === 1 ? "grid-cols-1" : "grid-cols-2")}>
          {photos.map((u, i) => (
            <Image
              key={i}
              src={u}
              alt=""
              className={cn(
                "w-full object-cover",
                photos.length === 1 ? "max-h-[500px]" :
                photos.length === 2 ? "h-60" :
                photos.length === 3 && i === 0 ? "h-60 col-span-2" : "h-44"
              )}
            />
          ))}
        </div>
      )}
      <div className="relative border-t border-border px-1 py-1">
        {showPicker && (
          <div className="absolute -top-11 left-2 flex gap-1 bg-card border border-border rounded-full px-2 py-1.5 shadow-xl z-10">
            {Object.entries(REACTIONS).map(([key, emoji]) => (
              <button key={key} onClick={() => react(key)} aria-label={key} className="text-xl hover:scale-125 transition">
                {emoji}
              </button>
            ))}
          </div>
        )}
        <div className="flex items-center">
          <button
            onClick={() => react("like")}
            onTouchStart={startPress}
            onTouchEnd={endPress}
            onContextMenu={e => { e.preventDefault(); setShowPicker(true); }}
            aria-label="Like"
            className={cn(
              "flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg min-h-[44px] transition hover:bg-secondary/50",
              reaction && "text-rose-400"
            )}
          >
            {reaction ? <span className="text-base leading-none">{REACTIONS[reaction]}</span> : <Heart className="w-5 h-5" />}
            <span className="text-xs font-medium">{formatCount(counts.likes)}</span>
          </button>
          <button
            onClick={() => setShowComments(true)}
            aria-label="Comment"
            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg min-h-[44px] transition hover:bg-secondary/50 hover:text-primary"
          >
            <MessageCircle className="w-5 h-5" />
            <span className="text-xs font-medium">{formatCount(counts.comments)}</span>
          </button>
          <button
            onClick={() => setShareOpen(true)}
            aria-label="Share"
            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg min-h-[44px] transition hover:bg-secondary/50 hover:text-primary"
          >
            <Share2 className="w-5 h-5" />
            <span className="text-xs font-medium">{formatCount(counts.shares)}</span>
          </button>
          <button
            onClick={onSave}
            aria-label={saved ? "Remove from saved" : "Save post"}
            className="flex-1 flex items-center justify-center py-2.5 rounded-lg min-h-[44px] transition hover:bg-secondary/50"
          >
            <Bookmark className={cn("w-5 h-5 transition", saved ? "fill-primary text-primary" : "hover:text-primary")} />
          </button>
          <div className="flex items-center gap-1 px-2 shrink-0">
            {isMine && (
              <button onClick={() => setPromoteOpen(true)} aria-label="Promote post" className="p-1.5 text-amber-400">
                <Megaphone className="w-[18px] h-[18px]" />
              </button>
            )}
            <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <Eye className="w-3.5 h-3.5" />
              {formatCount(post.views_count || 0)}
            </span>
          </div>
        </div>
      </div>

      <CommentSheet
        open={showComments}
        onClose={() => setShowComments(false)}
        targetType="post"
        targetId={post.id}
        entity={base44.entities.Post}
        author={post.author_name}
        onCountChange={(d = 1) => setCounts(c => ({ ...c, comments: Math.max(0, c.comments + d) }))}
      />

      {promoteOpen && <PromoteSheet post={post} onClose={() => setPromoteOpen(false)} />}

      <ShareSheet
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        post={post}
        onShared={(d) => setCounts(c => ({ ...c, shares: c.shares + d }))}
      />

      <PostMenuSheet
        post={post}
        isMine={isMine}
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
        onEdited={(updated) => setLocalText(updated.text)}
        onDeleted={() => setDeleted(true)}
      />
    </article>
  );
}