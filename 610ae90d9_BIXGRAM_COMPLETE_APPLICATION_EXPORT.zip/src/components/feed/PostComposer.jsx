import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Image as ImageIcon, Smile, UserPlus, X, BadgeCheck, Globe2, Loader2, Save } from "lucide-react";
import { Image } from "@/components/ui/image";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { getMe, getProfile, defaultAvatar, uploadFile, notifyMentions, flagContent, notify } from "@/lib/social";
import { getVerifiedNameSet } from "@/lib/channels";
import { useToast } from "@/components/ui/use-toast";

const FEELINGS = ["😊 Happy", "❤️ Loved", "🔥 Motivated", "😎 Cool", "🙏 Grateful", "😂 Funny", "💪 Strong", "✨ Blessed"];

export default function PostComposer({ onPosted, world }) {
  const [text, setText] = useState("");
  const [posting, setPosting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [photos, setPhotos] = useState([]); // up to 4 uploaded photo urls
  const [collabUser, setCollabUser] = useState(null);
  const [profiles, setProfiles] = useState([]);
  const [verifiedNames, setVerifiedNames] = useState(new Set());
  const [drafts, setDrafts] = useState([]);
  const [activeDraftId, setActiveDraftId] = useState(null);
  const [showCollab, setShowCollab] = useState(false);
  const [feeling, setFeeling] = useState(null);
  const [showFeelings, setShowFeelings] = useState(false);
  const [me, setMe] = useState({ name: "You", avatar_url: defaultAvatar("You") });
  const { toast } = useToast();
  const navigate = useNavigate();
  const photoRef = useRef(null);

  useEffect(() => {
    getMe()
      .then(async m => {
        try {
          const p = await getProfile(m.name);
          setMe({ name: p.full_name || p.username, avatar_url: p.avatar_url || defaultAvatar(m.name) });
        } catch {
          setMe({ name: m.name, avatar_url: defaultAvatar(m.name) });
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    base44.entities.Profile.list(20).then(setProfiles).catch(() => {});
    base44.entities.Draft.list("-updated_date", 5).then(setDrafts).catch(() => {});
    getVerifiedNameSet().then(setVerifiedNames).catch(() => {});
  }, []);

  const onFile = async (e, type) => {
    const files = Array.from(e.target.files || []);
    e.target.value = "";
    let photoCount = photos.length;
    for (const file of files) {
      if (type === "image" && photoCount >= 4) {
        toast({ title: "Up to 4 photos per post" });
        break;
      }
      if (file.size > 50 * 1024 * 1024) {
        toast({ title: "File too large (max 50MB)", variant: "destructive" });
        continue;
      }
      setUploading(true);
      try {
        const url = await uploadFile(file);
        setPhotos(ps => [...ps, url]);
        photoCount++;
      } catch {
        toast({ title: "Upload failed — try again", variant: "destructive" });
      } finally {
        setUploading(false);
      }
    }
  };

  const saveDraft = async () => {
    if (!text.trim() && photos.length === 0) return;
    const payload = {
      text: text.trim(),
      image_url: photos[0],
      media_urls: photos.length > 1 ? photos.slice(0, 4) : undefined,
      world_id: world?.id,
      world_name: world?.name,
    };
    try {
      if (activeDraftId) {
        await base44.entities.Draft.update(activeDraftId, payload);
        setDrafts(ds => ds.map(d => (d.id === activeDraftId ? { ...d, ...payload } : d)));
      } else {
        const d = await base44.entities.Draft.create(payload);
        setActiveDraftId(d?.id || null);
        setDrafts(ds => [d, ...ds]);
      }
      toast({ title: "Draft saved" });
    } catch {
      toast({ title: "Could not save draft", variant: "destructive" });
    }
  };

  const loadDraft = (d) => {
    setActiveDraftId(d.id);
    setText(d.text || "");
    setPhotos(d.media_urls?.length > 1 ? d.media_urls : d.image_url ? [d.image_url] : []);
  };

  const removeDraft = async (d) => {
    await base44.entities.Draft.delete(d.id).catch(() => {});
    setDrafts(ds => ds.filter(x => x.id !== d.id));
    if (activeDraftId === d.id) setActiveDraftId(null);
  };

  const submit = async () => {
    if (!text.trim() && photos.length === 0) return;
    setPosting(true);
    try {
      const created = await base44.entities.Post.create({
        author_name: me.name,
        author_avatar: me.avatar_url,
        author_verified: false,
        text: text.trim(),
        image_url: photos[0],
        media_urls: photos.length > 1 ? photos.slice(0, 4) : undefined,
        feeling: feeling || undefined,
        feed_type: "for_you",
        world_id: world?.id,
        world_name: world?.name,
        likes_count: 0,
        comments_count: 0,
        shares_count: 0,
        views_count: 0,
        saves_count: 0,
        collab_partner_name: collabUser?.username,
        collab_partner_avatar: collabUser?.avatar_url,
      });
      if (created?.id) await flagContent({ targetType: "post", targetId: created.id, author: me.name, text: text.trim() });
      if (collabUser) await notify("collab", collabUser.username, "invited you to collaborate on a post");
      if (text.trim()) await notifyMentions(text);
      if (activeDraftId) {
        await base44.entities.Draft.delete(activeDraftId).catch(() => {});
        setActiveDraftId(null);
      }
      setText("");
      setPhotos([]);
      setCollabUser(null);
      setFeeling(null);
      setShowCollab(false);
      setShowFeelings(false);
      toast({ title: world ? `Posted in ${world.name}!` : "Posted to your feed!" });
      onPosted?.(created);
    } catch {
      toast({ title: "Could not post", variant: "destructive" });
    } finally {
      setPosting(false);
    }
  };

  const canPost = (text.trim() || photos.length > 0) && !posting && !uploading;

  const toolBtn = "flex items-center gap-1.5 px-2 py-2.5 rounded-lg hover:bg-secondary transition text-xs font-medium";

  return (
    <div className="mx-3 my-2 bix-card p-3">
      {world && (
        <div className="flex items-center gap-1.5 text-xs text-primary mb-2">
          <Globe2 className="w-3.5 h-3.5" />
          Posting in <span className="font-semibold">{world.name}</span>
        </div>
      )}
      {drafts.length > 0 && (
        <div className="flex gap-2 items-center overflow-x-auto no-scrollbar mb-2">
          <span className="text-[10px] font-bold text-muted-foreground uppercase shrink-0">Drafts</span>
          {drafts.map(d => (
            <span key={d.id} className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs shrink-0", activeDraftId === d.id ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground")}>
              <button onClick={() => loadDraft(d)} className="max-w-[140px] truncate">{d.text || "Media draft"}</button>
              <button onClick={() => removeDraft(d)} aria-label="Delete draft"><X className="w-3 h-3" /></button>
            </span>
          ))}
        </div>
      )}
      <div className="flex gap-3">
        <img src={me.avatar_url} alt="me" className="w-10 h-10 rounded-full object-cover shrink-0" />
        <textarea
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="What's happening?"
          rows={1}
          className="flex-1 bg-secondary/40 rounded-2xl px-3.5 py-2.5 resize-none outline-none text-sm placeholder:text-muted-foreground focus:ring-1 focus:ring-primary/40"
        />
      </div>

      {feeling && (
        <div className="flex items-center gap-1.5 mt-2 ml-[52px]">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-300 text-xs font-medium">
            is feeling {feeling}
            <button onClick={() => setFeeling(null)} aria-label="Remove feeling"><X className="w-3 h-3" /></button>
          </span>
        </div>
      )}

      {photos.length > 0 && (
        <div className={cn("mt-2 grid gap-1.5", photos.length === 1 ? "grid-cols-1" : "grid-cols-2")}>
          {photos.map((url, i) => (
            <div key={i} className="relative rounded-xl overflow-hidden">
              <Image src={url} alt="" className={cn("w-full object-cover", photos.length === 1 ? "h-48" : "h-32")} />
              <button
                onClick={() => setPhotos(ps => ps.filter(p => p !== url))}
                aria-label="Remove photo"
                className="absolute top-1.5 right-1.5 w-7 h-7 rounded-full bg-black/60 backdrop-blur flex items-center justify-center"
              >
                <X className="w-3.5 h-3.5 text-white" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between gap-1 mt-2 pt-2 border-t border-border">
        <div className="flex items-center gap-0.5 overflow-x-auto no-scrollbar">
          <button onClick={() => photoRef.current?.click()} title="Add photo" className={cn(toolBtn, "text-emerald-400")}>
            {uploading ? <Loader2 className="w-[18px] h-[18px] animate-spin" /> : <ImageIcon className="w-[18px] h-[18px]" />}
            <span className="hidden sm:inline">Photo</span>
          </button>
          <button
            onClick={() => { setShowFeelings(v => !v); setShowCollab(false); }}
            title="Feeling"
            className={cn(toolBtn, "text-amber-400", showFeelings && "bg-secondary")}
          >
            <Smile className="w-[18px] h-[18px]" />
            <span className="hidden sm:inline">Feeling</span>
          </button>
          <button
            onClick={() => { setShowCollab(v => !v); setShowFeelings(false); }}
            title="Collaborate"
            className={cn(toolBtn, "text-cyan-400", showCollab && "bg-secondary")}
          >
            <UserPlus className="w-[18px] h-[18px]" />
            <span className="hidden sm:inline">Collab</span>
          </button>
          <button onClick={saveDraft} title="Save draft" className={cn(toolBtn, "text-sky-400")}>
            <Save className="w-[18px] h-[18px]" />
            <span className="hidden sm:inline">Draft</span>
          </button>
        </div>
        <button
          onClick={submit}
          disabled={!canPost}
          className="shrink-0 px-5 py-2 rounded-full bix-gradient text-white text-sm font-semibold disabled:opacity-40 transition bix-press"
        >
          {posting ? "Posting…" : "Post"}
        </button>
      </div>

      <input ref={photoRef} type="file" accept="image/*" multiple hidden onChange={e => onFile(e, "image")} />

      {showFeelings && (
        <div className="mt-2 pt-2 border-t border-border">
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {FEELINGS.map(f => (
              <button
                key={f}
                onClick={() => { setFeeling(f); setShowFeelings(false); }}
                className={cn(
                  "shrink-0 px-3 py-1.5 rounded-full text-xs font-medium border transition",
                  feeling === f ? "bix-gradient text-white border-transparent" : "border-border text-muted-foreground hover:bg-secondary"
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      )}

      {showCollab && (
        <div className="mt-2 pt-2 border-t border-border">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-muted-foreground">
              {collabUser ? "Collaborating with" : "Invite a collaborator"}
            </span>
            {collabUser && (
              <button onClick={() => setCollabUser(null)} aria-label="Remove collaborator" className="text-muted-foreground">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
            {profiles.filter(p => p.username !== me.name).map((p) => (
              <button
                key={p.id}
                onClick={() => setCollabUser(collabUser?.id === p.id ? null : p)}
                className="flex flex-col items-center gap-1 shrink-0"
              >
                <img
                  src={p.avatar_url}
                  alt={p.username}
                  className={cn(
                    "w-12 h-12 rounded-full object-cover",
                    collabUser?.id === p.id ? "ring-2 ring-primary" : "opacity-70"
                  )}
                />
                <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground">
                  {p.full_name || p.username} {(verifiedNames.has(p.full_name) || verifiedNames.has(p.username)) && <BadgeCheck className="w-2.5 h-2.5 text-primary" />}
                </span>
              </button>
            ))}
            {profiles.filter(p => p.username !== me.name).length === 0 && (
              <span className="text-xs text-muted-foreground py-2">No other users yet — invite friends to BIXGRAM to collaborate!</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}