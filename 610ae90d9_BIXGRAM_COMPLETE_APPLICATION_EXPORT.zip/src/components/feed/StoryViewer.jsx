import React, { useState, useEffect, useRef } from "react";
import { X, Eye, Play, Pause, Volume2, VolumeX } from "lucide-react";
import { Image } from "@/components/ui/image";

const DURATION_MS = 5000;
const TICK_MS = 100;

const isVideoUrl = (url) => /\.(mp4|webm|mov|m4v|ogg)(\?|$)/i.test(String(url || ""));

export default function StoryViewer({ stories, startIndex = 0, onClose, onViewed }) {
  const [index, setIndex] = useState(startIndex);
  const [progress, setProgress] = useState(0);
  const [paused, setPaused] = useState(false);
  const [muted, setMuted] = useState(true);
  const videoRef = useRef(null);

  const story = stories[index];
  const isVideo = isVideoUrl(story?.media_url);

  // Photos advance on a timer; videos advance with their own playback.
  useEffect(() => {
    if (isVideo) return;
    setProgress(0);
    const t = setInterval(() => setProgress(p => Math.min(100, p + (TICK_MS / DURATION_MS) * 100)), TICK_MS);
    return () => clearInterval(t);
  }, [index, isVideo]);

  useEffect(() => {
    if (story?.id) onViewed?.(story.id);
  }, [index]);

  useEffect(() => {
    if (progress < 100) return;
    if (index < stories.length - 1) setIndex(i => i + 1);
    else onClose();
  }, [progress]);

  // Keep playback in step with the paused state.
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (paused) v.pause();
    else v.play().catch(() => {});
  }, [paused, index]);

  if (!story) return null;

  const next = () => (index < stories.length - 1 ? setIndex(i => i + 1) : onClose());
  const prev = () => (index > 0 ? setIndex(i => i - 1) : setProgress(0));

  const onVideoTime = () => {
    const v = videoRef.current;
    if (!v || !v.duration || !isFinite(v.duration)) return;
    setProgress((v.currentTime / v.duration) * 100);
  };

  return (
    <div className="fixed inset-0 z-[70] bg-black overflow-hidden">
      {story.media_url ? (
        isVideo ? (
          <video
            ref={videoRef}
            key={story.id}
            src={story.media_url}
            autoPlay
            playsInline
            muted={muted}
            onTimeUpdate={onVideoTime}
            onEnded={() => setProgress(100)}
            className="absolute inset-0 w-full h-full object-contain bg-black"
          />
        ) : (
          <Image src={story.media_url} alt="" fittingType="fit" className="absolute inset-0 w-full h-full" />
        )
      ) : (
        <div className="absolute inset-0 bix-gradient opacity-40" />
      )}
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-transparent to-black/70 pointer-events-none" />

      {/* Tap zones */}
      <button aria-label="Previous story" onClick={prev} className="absolute left-0 top-24 bottom-24 w-1/3" />
      <button aria-label="Next story" onClick={next} className="absolute right-0 top-24 bottom-24 w-2/3" />

      {/* Progress bars */}
      <div className="absolute top-0 left-0 right-0 flex gap-1 px-3 pt-3 safe-top">
        {stories.map((s, i) => (
          <div key={s.id || i} className="flex-1 h-[3px] rounded-full bg-white/30 overflow-hidden">
            <div
              className="h-full bg-white transition-[width] duration-100 ease-linear"
              style={{ width: i < index ? "100%" : i === index ? `${progress}%` : "0%" }}
            />
          </div>
        ))}
      </div>

      <div className="absolute top-6 left-3 right-3 flex items-center gap-2.5 pt-4">
        <img src={story.user_avatar} alt="" className="w-10 h-10 rounded-full object-cover ring-2 ring-white/40 shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="text-sm font-semibold text-white truncate">{story.user_name}</div>
          <div className="text-[11px] text-white/70">{isVideo ? "Video story" : "Photo story"}</div>
        </div>
        {isVideo && (
          <button
            onClick={() => setMuted(m => !m)}
            aria-label={muted ? "Unmute story" : "Mute story"}
            className="w-9 h-9 rounded-full bg-black/40 backdrop-blur flex items-center justify-center shrink-0"
          >
            {muted ? <VolumeX className="w-4 h-4 text-white" /> : <Volume2 className="w-4 h-4 text-white" />}
          </button>
        )}
        <button
          onClick={() => setPaused(p => !p)}
          aria-label={paused ? "Resume story" : "Pause story"}
          className="w-9 h-9 rounded-full bg-black/40 backdrop-blur flex items-center justify-center shrink-0"
        >
          {paused ? <Play className="w-4 h-4 text-white fill-white" /> : <Pause className="w-4 h-4 text-white fill-white" />}
        </button>
        <button onClick={onClose} aria-label="Close story" className="w-9 h-9 rounded-full bg-black/40 backdrop-blur flex items-center justify-center shrink-0">
          <X className="w-5 h-5 text-white" />
        </button>
      </div>

      <div className="absolute bottom-6 left-3 right-3 flex items-center justify-center gap-1.5 text-white/70 text-xs safe-bottom pointer-events-none">
        <Eye className="w-3.5 h-3.5" />
        <span>{index + 1} of {stories.length}</span>
      </div>
    </div>
  );
}