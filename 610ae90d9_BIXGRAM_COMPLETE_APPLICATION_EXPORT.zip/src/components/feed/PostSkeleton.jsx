import React from "react";

export default function PostSkeleton() {
  return (
    <div className="mx-3 my-2 bix-card p-3" aria-hidden="true">
      <div className="flex items-center gap-3">
        <div className="bix-skeleton w-11 h-11 rounded-full" />
        <div className="flex-1 space-y-2">
          <div className="bix-skeleton h-3 w-32" />
          <div className="bix-skeleton h-2.5 w-20" />
        </div>
      </div>
      <div className="mt-3 space-y-2">
        <div className="bix-skeleton h-3 w-full" />
        <div className="bix-skeleton h-3 w-3/5" />
      </div>
      <div className="bix-skeleton mt-3 h-40 rounded-xl" />
      <div className="flex gap-4 mt-3">
        <div className="bix-skeleton h-3 w-14" />
        <div className="bix-skeleton h-3 w-14" />
        <div className="bix-skeleton h-3 w-14" />
      </div>
    </div>
  );
}