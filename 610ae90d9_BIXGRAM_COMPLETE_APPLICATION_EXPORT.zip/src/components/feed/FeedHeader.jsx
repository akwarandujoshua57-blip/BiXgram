import React, { useState, useEffect } from "react";
import { Search, Bell, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";
import BixLogo from "@/components/BixLogo";
import { base44 } from "@/api/base44Client";
import { getMe, getProfile, defaultAvatar } from "@/lib/social";

function Badge({ count }) {
  if (!count) return null;
  return (
    <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-gradient-to-br from-pink-500 to-rose-600 text-[9px] font-bold text-white flex items-center justify-center ring-2 ring-background">
      {count > 9 ? "9+" : count}
    </span>
  );
}

export default function FeedHeader({ onSearch }) {
  const [me, setMe] = useState(null);
  const [unread, setUnread] = useState(0);
  const [unreadMsgs, setUnreadMsgs] = useState(0);

  useEffect(() => {
    (async () => {
      try {
        const m = await getMe();
        let avatar = defaultAvatar(m.name);
        try { avatar = (await getProfile(m.name)).avatar_url || avatar; } catch {}
        setMe({ name: m.name, avatar });
      } catch {}
      // Real counts — RLS scopes these to the signed-in account
      try {
        setUnread((await base44.entities.Notification.filter({ is_read: false })).length);
      } catch {}
      try {
        const convos = await base44.entities.Conversation.list("-updated_date", 50);
        setUnreadMsgs(convos.reduce((s, c) => s + (c.unread_count || 0), 0));
      } catch {}
    })();
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-background/85 backdrop-blur-xl border-b border-border">
      <div className="h-16 flex items-center justify-between gap-2 px-4 max-w-2xl mx-auto">
        <Link to="/" aria-label="BIXGRAM home" className="shrink-0">
          <BixLogo size={34} withText />
        </Link>
        <div className="flex items-center gap-1.5 shrink-0">
          <button onClick={onSearch} aria-label="Search" className="bix-icon-btn">
            <Search className="w-5 h-5 text-foreground" />
          </button>
          <Link to="/notifications" aria-label="Notifications" className="relative bix-icon-btn">
            <Bell className="w-5 h-5 text-foreground" />
            <Badge count={unread} />
          </Link>
          <Link to="/messenger" aria-label="Messenger" className="relative bix-icon-btn">
            <MessageCircle className="w-5 h-5 text-foreground" />
            <Badge count={unreadMsgs} />
          </Link>
          <Link to="/profile" aria-label="Your profile" className="ml-0.5 shrink-0">
            <img
              src={me?.avatar || defaultAvatar("You")}
              alt="me"
              className="w-9 h-9 rounded-full object-cover ring-2 ring-primary/50"
            />
          </Link>
        </div>
      </div>
    </header>
  );
}