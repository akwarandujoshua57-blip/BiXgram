import React, { useEffect, useState } from "react";
import { Home, Users, Video, MessageCircle, Menu as MenuIcon } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

// BIXGRAM primary navigation: Home · Community · Live · Messenger · More
const items = [
  { to: "/", label: "Home", icon: Home },
  { to: "/communities", label: "Community", icon: Users },
  { to: "/live", label: "Live", icon: Video },
  { to: "/messenger", label: "Messenger", icon: MessageCircle },
  { to: "/menu", label: "More", icon: MenuIcon },
];

export default function BottomNav() {
  const loc = useLocation();
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    let last = window.scrollY;
    const onScroll = () => {
      const y = window.scrollY;
      if (Math.abs(y - last) < 10) return;
      setHidden(y > last && y > 96);
      last = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      aria-label="Primary"
      className={cn(
        "fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-card/95 backdrop-blur-xl safe-bottom",
        "transition-transform duration-300 ease-out will-change-transform",
        hidden ? "translate-y-full" : "translate-y-0"
      )}
    >
      <div className="flex items-stretch justify-around max-w-md mx-auto px-1 pt-1 pb-0.5">
        {items.map(({ to, label, icon: Icon }) => {
          const active = to === "/" ? loc.pathname === "/" : loc.pathname.startsWith(to);
          return (
            <Link
              key={to}
              to={to}
              aria-label={label}
              aria-current={active ? "page" : undefined}
              className="flex flex-col items-center justify-center gap-0.5 flex-1 min-w-0 py-1 rounded-xl bix-press min-h-[56px]"
            >
              <div
                className={cn(
                  "flex items-center justify-center w-11 h-7 rounded-full transition-all duration-200",
                  active ? "bix-gradient bix-glow" : "bg-transparent"
                )}
              >
                <Icon
                  className={cn("w-[19px] h-[19px] transition-colors", active ? "text-white" : "text-muted-foreground")}
                  strokeWidth={active ? 2.5 : 2}
                />
              </div>
              <span
                className={cn(
                  "text-[10px] leading-none font-medium transition-colors truncate max-w-full",
                  active ? "text-primary" : "text-muted-foreground"
                )}
              >
                {label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}