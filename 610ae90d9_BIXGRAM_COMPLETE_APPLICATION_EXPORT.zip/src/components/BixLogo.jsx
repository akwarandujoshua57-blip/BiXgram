import React from "react";

export default function BixLogo({ size = 36, withText = false }) {
  return (
    <div className="flex items-center gap-2.5">
      <div
        className="relative flex items-center justify-center rounded-2xl bix-gradient bix-glow"
        style={{ width: size, height: size }}
      >
        <svg viewBox="0 0 40 40" className="w-3/5 h-3/5" fill="none">
          <path
            d="M8 6 L8 34 M8 20 L24 6 M8 20 L24 34 M28 10 Q34 20 28 30"
            stroke="white"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      {withText && (
        <span className="text-xl font-extrabold tracking-tight bix-gradient-text font-display">
          BIXGRAM
        </span>
      )}
    </div>
  );
}