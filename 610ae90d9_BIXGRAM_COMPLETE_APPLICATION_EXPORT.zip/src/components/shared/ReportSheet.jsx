import React, { useState } from "react";
import { X, Flag } from "lucide-react";
import { reportContent } from "@/lib/social";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const REASONS = ["spam", "scam", "harassment", "hate", "inappropriate", "fake_account", "other"];

export default function ReportSheet({ open, onClose, targetType, targetId, targetLabel }) {
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [sending, setSending] = useState(false);
  const { toast } = useToast();

  if (!open) return null;

  const submit = async () => {
    if (!reason) { toast({ title: "Pick a reason", variant: "destructive" }); return; }
    setSending(true);
    try {
      await reportContent({ targetType, targetId, reason, details, targetLabel });
      toast({ title: "Report sent — our team will review it" });
      setReason("");
      setDetails("");
      onClose?.();
    } catch {
      toast({ title: "Could not send report", variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] bg-black/60 backdrop-blur flex items-end justify-center" onClick={onClose}>
      <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-4" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-lg flex items-center gap-2"><Flag className="w-5 h-5 text-rose-400" /> Report</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>
        <p className="text-xs text-muted-foreground -mt-2">
          Reporting {targetType === "user" ? "this account" : `this ${targetType}`}{targetLabel ? `: "${targetLabel.slice(0, 50)}"` : ""}
        </p>
        <div>
          <label className="text-xs text-muted-foreground">Reason *</label>
          <div className="flex gap-2 flex-wrap mt-1.5">
            {REASONS.map(r => (
              <button
                key={r}
                onClick={() => setReason(r)}
                className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-semibold capitalize transition",
                  reason === r ? "bix-gradient text-white" : "bg-secondary/60 text-muted-foreground"
                )}
              >
                {r.replace("_", " ")}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Details (optional)</label>
          <textarea
            value={details}
            onChange={e => setDetails(e.target.value)}
            rows={2}
            placeholder="Tell us more…"
            className="w-full bg-secondary/50 rounded-xl px-3 py-2.5 text-sm outline-none mt-1 resize-none"
          />
        </div>
        <button
          onClick={submit}
          disabled={!reason || sending}
          className="w-full py-3 rounded-xl bg-rose-500 text-white font-semibold disabled:opacity-50"
        >
          {sending ? "Sending…" : "Submit Report"}
        </button>
      </div>
    </div>
  );
}