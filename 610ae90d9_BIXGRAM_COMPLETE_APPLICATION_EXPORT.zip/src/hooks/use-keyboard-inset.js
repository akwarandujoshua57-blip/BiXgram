import { useEffect, useState } from "react";

// Returns how many pixels of the viewport the on-screen keyboard currently covers.
//
// This exists so a chat layout can sit directly above the device's REAL system
// keyboard without ever reserving a permanent blank area for it. It reports 0
// whenever no keyboard is open, so nothing is held back in the resting state.
//
// On Android Chrome the layout viewport itself shrinks when the keyboard opens
// (see `interactive-widget=resizes-content` in index.html), so this reports 0 and
// the layout simply follows the smaller viewport. On iOS Safari the layout
// viewport does not shrink, so this reports the covered height and the chat is
// lifted by exactly that amount.
const MIN_KEYBOARD = 80; // ignore browser-chrome collapse, which is much smaller

export default function useKeyboardInset() {
  const [inset, setInset] = useState(0);

  useEffect(() => {
    const vv = window.visualViewport;
    if (!vv) return;

    const update = () => {
      const covered = window.innerHeight - vv.height - vv.offsetTop;
      setInset(covered > MIN_KEYBOARD ? Math.round(covered) : 0);
    };

    update();
    vv.addEventListener("resize", update);
    vv.addEventListener("scroll", update);
    window.addEventListener("orientationchange", update);
    return () => {
      vv.removeEventListener("resize", update);
      vv.removeEventListener("scroll", update);
      window.removeEventListener("orientationchange", update);
    };
  }, []);

  return inset;
}