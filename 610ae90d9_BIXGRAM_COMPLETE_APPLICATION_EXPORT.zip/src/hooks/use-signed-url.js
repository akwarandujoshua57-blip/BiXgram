import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

const isHttp = (v) => typeof v === "string" && /^https?:\/\//i.test(v);

// Turns a stored media reference into something the browser can load.
//
// Public http(s) URLs pass straight through. Private file URIs are exchanged
// for a short-lived signed link, so the underlying file is never reachable
// without authorization — swapping a message id or storage key gets you
// nothing, because the signature is what grants access.
export default function useSignedUrl(ref, expiresIn = 3600) {
  const [url, setUrl] = useState(() => (isHttp(ref) ? ref : null));

  useEffect(() => {
    if (!ref) { setUrl(null); return; }
    if (isHttp(ref)) { setUrl(ref); return; }

    let alive = true;
    base44.integrations.Core.CreateFileSignedUrl({ file_uri: ref, expires_in: expiresIn })
      .then((r) => { if (alive) setUrl(r?.signed_url || null); })
      .catch(() => { if (alive) setUrl(null); });

    return () => { alive = false; };
  }, [ref, expiresIn]);

  return url;
}